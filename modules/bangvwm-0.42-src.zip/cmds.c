/*------------------------------------------------------------------------------
	This is a Virtual Desktop Manager for use under Win32 Shells that
	support the LiteStep 0.24.5 module standard.

	Copyright (C) 2001-2003 Chris Rempel

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
------------------------------------------------------------------------------*/

/*---System Includes----------------------------------------------------------*/
#include <tchar.h>
#include <windows.h>
#include <ctype.h>

/*---Module Includes----------------------------------------------------------*/
#include "common.h"

/*----------------------------------------------------------------------------*/

/* From utility.c */
#ifdef _DEBUG
EXTERN_C VOID debugWindows( VOID );
#endif

EXTERN_C VOID focusLast( VOID );
EXTERN_C VOID shiftVD( BOOL const );
EXTERN_C BOOL switchToVD( UINT const );
EXTERN_C BOOL switchToVDEx( UINT const, BOOL const );
EXTERN_C VOID gatherToVD( UINT const, char const );
EXTERN_C VOID gatherLostToVD( UINT const );
EXTERN_C VOID gatherMatchedToVD( UINT const, PCCLASSANDTITLE const );
EXTERN_C VOID stretchWnd( HWND const, enum EbvdmStretchMode const );
EXTERN_C VOID alignWnd( HWND const, enum EbvdmAlignMode const );
EXTERN_C VOID setNumDesks( UINT const );
EXTERN_C VOID moveActiveWndToVD( UINT const );
EXTERN_C VOID loadSettings( VOID );
EXTERN_C VOID unloadSettings( VOID );
EXTERN_C VOID executeQuitCmd( VOID );

EXTERN_C UINT g_unCurVD;
EXTERN_C UINT g_unVDesks;
EXTERN_C BOOL g_bFocusLast;
EXTERN_C BOOL g_bIgnoreDesktopUpdate;

/*----------------------------------------------------------------------------*/

static STRINGIDMAP s_stretchMap[] = {
	 { _T("vertical"),   eBVDM_STRETCH__VERTICAL }
	,{ _T("horizontal"), eBVDM_STRETCH__HORIZONTAL }
	,{ _T("both"),       eBVDM_STRETCH__BOTH }
	,{ NULL, 0 }
};

static STRINGIDMAP s_alignMap[] = {
	 { _T("left"),   eBVDM_ALIGN__LEFT }
	,{ _T("right"),  eBVDM_ALIGN__RIGHT }
	,{ _T("top"),    eBVDM_ALIGN__TOP }
	,{ _T("bottom"), eBVDM_ALIGN__BOTTOM }
	,{ _T("center"), eBVDM_ALIGN__CENTER }
	,{ _T("middle"), eBVDM_ALIGN__MIDDLE }
	,{ NULL, 0 }
};

/*----------------------------------------------------------------------------*/
static UINT _getVD( LPCTSTR const pszArgs )
{
	UINT unVD = (UINT)-1;

	if(NULL != pszArgs)
	{
		if(_istdigit(*pszArgs))
		{
			unVD = _ttoi(pszArgs);
		}
		else
		{
			if(0 == _tcsicmp(_T("next"), pszArgs))
			{
				unVD = VD_NEXT;
			}
			else if(0 == _tcsicmp(_T("prev"), pszArgs))
			{
				unVD = VD_PREV;
			}
			else if(0 == _tcsicmp(_T("home"), pszArgs))
			{
				unVD = VD_FIRST;
			}
			else if(0 == _tcsicmp(_T("end"), pszArgs))
			{
				unVD = VD_LAST;
			}
			/* Compatibility checks */
			else if(0 == _tcsicmp(_T("up"), pszArgs))
			{
				unVD = VD_PREV;
			}
			else if(0 == _tcsicmp(_T("left"), pszArgs))
			{
				unVD = VD_PREV;
			}
			else if(0 == _tcsicmp(_T("down"), pszArgs))
			{
				unVD = VD_NEXT;
			}
			else if(0 == _tcsicmp(_T("right"), pszArgs))
			{
				unVD = VD_NEXT;
			}
		}
	}

	if(!VD_ISVALID(unVD))
	{
		unVD = g_unCurVD;
	}

	return(unVD);
}

/*------------------------------------------------------------------------------
 Bang Commands
------------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
VOID bVDMSwitchTo( HWND hCallerWnd, LPCTSTR pszArgs )
{
	switchToVD(_getVD(pszArgs));

	return;
	UNREFERENCED_PARAMETER( hCallerWnd );
}

/*----------------------------------------------------------------------------*/
VOID bVDMNext( HWND hCallerWnd, LPCTSTR pszArgs )
{
	switchToVD(VD_NEXT);

	return;
	UNREFERENCED_PARAMETER( hCallerWnd );
	UNREFERENCED_PARAMETER( pszArgs );
}

/*----------------------------------------------------------------------------*/
VOID bVDMPrev( HWND hCallerWnd, LPCTSTR pszArgs )
{
	switchToVD(VD_PREV);

	return;
	UNREFERENCED_PARAMETER( hCallerWnd );
	UNREFERENCED_PARAMETER( pszArgs );
}

/*----------------------------------------------------------------------------*/
VOID bVDMGather( HWND hCallerWnd, LPCTSTR pszArgs )
{
	gatherToVD(_getVD(pszArgs), VD_HORZVERT);

	return;
	UNREFERENCED_PARAMETER( hCallerWnd );
}

/*----------------------------------------------------------------------------*/
VOID bVDMGatherH( HWND hCallerWnd, LPCTSTR pszArgs )
{
	gatherToVD(_getVD(pszArgs), VD_HORIZONTAL);

	return;
	UNREFERENCED_PARAMETER( hCallerWnd );
}

/*----------------------------------------------------------------------------*/
VOID bVDMGatherV( HWND hCallerWnd, LPCTSTR pszArgs )
{
	gatherToVD(_getVD(pszArgs), VD_VERTICAL);

	return;
	UNREFERENCED_PARAMETER( hCallerWnd );
}

/*----------------------------------------------------------------------------*/
VOID bVDMGatherLost( HWND hCallerWnd, LPCTSTR pszArgs )
{
	gatherLostToVD(_getVD(pszArgs));

	return;
	UNREFERENCED_PARAMETER( hCallerWnd );
}

/*----------------------------------------------------------------------------*/
VOID bVDMGatherMatched( HWND hCallerWnd, LPCTSTR pszArgs )
{
	if(NULL != pszArgs && 0 != *pszArgs)
	{
		LPTSTR tokens[3];
		_TCHAR szDeskNum[4096];
		_TCHAR szClass[4096];
		_TCHAR szTitle[4096];
		INT nTokens;

		tokens[0] = szDeskNum;
		tokens[1] = szClass;
		tokens[2] = szTitle;

		nTokens = LCTokenize(pszArgs, tokens, 3, NULL);

		if(nTokens >= 2) /* VD and Class is mandatory, Title is optional */
		{
			CLASSANDTITLE cat;

			cat.pszClass = szClass;
			cat.pszTitle = szTitle;

			if(nTokens != 3) /* If a title wasn't supplied, match all */
			{
				_tcscpy(szTitle, _T("*"));
			}

			gatherMatchedToVD(_getVD(szDeskNum), &cat);
		}
	}

	return;
	UNREFERENCED_PARAMETER( hCallerWnd );
}

/*----------------------------------------------------------------------------*/
VOID bVDMDesks( HWND hCallerWnd, LPCTSTR pszArgs )
{
	if(NULL != pszArgs && _istdigit(*pszArgs))
	{
		const UINT uTmp = _ttoi(pszArgs);

		if(uTmp != g_unVDesks)
		{
			setNumDesks(uTmp);
		}
	}

	return;
	UNREFERENCED_PARAMETER( hCallerWnd );
}

/*----------------------------------------------------------------------------*/
VOID bVDMEnableFocusLast( HWND hCallerWnd, LPCTSTR pszArgs )
{
	g_bFocusLast = TRUE;

	return;
	UNREFERENCED_PARAMETER( hCallerWnd );
	UNREFERENCED_PARAMETER( pszArgs );
}

/*----------------------------------------------------------------------------*/
VOID bVDMDisableFocusLast( HWND hCallerWnd, LPCTSTR pszArgs )
{
	g_bFocusLast = FALSE;

	return;
	UNREFERENCED_PARAMETER( hCallerWnd );
	UNREFERENCED_PARAMETER( pszArgs );
}

/*----------------------------------------------------------------------------*/
VOID bVDMHandleDesktopUpdate( HWND hCallerWnd, LPCTSTR pszArgs )
{
	g_bIgnoreDesktopUpdate = TRUE;

	return;
	UNREFERENCED_PARAMETER( hCallerWnd );
	UNREFERENCED_PARAMETER( pszArgs );
}

/*----------------------------------------------------------------------------*/
VOID bVDMIgnoreDesktopUpdate( HWND hCallerWnd, LPCTSTR pszArgs )
{
	g_bIgnoreDesktopUpdate = FALSE;

	return;
	UNREFERENCED_PARAMETER( hCallerWnd );
	UNREFERENCED_PARAMETER( pszArgs );
}

/*----------------------------------------------------------------------------*/
VOID bVDMMoveWindow( HWND hCallerWnd, LPCTSTR pszArgs )
{
	moveActiveWndToVD(_getVD(pszArgs));

	return;
	UNREFERENCED_PARAMETER( hCallerWnd );
}

/*----------------------------------------------------------------------------*/
VOID bVDMExecute( HWND hCallerWnd, LPCTSTR pszArgs )
{
	if(NULL != pszArgs && 0 != *pszArgs)
	{
		LPTSTR tokens[1];
		_TCHAR szDeskNum[4096];
		_TCHAR szExtra[4096];
		INT nTokens;

		tokens[0] = szDeskNum;
		*szExtra = 0;

		nTokens = LCTokenize(pszArgs, tokens, 1, szExtra);

		if(1 == nTokens && 0 != *szExtra)
		{
			switchToVDEx(_getVD(szDeskNum), TRUE);

			LSExecute(NULL, szExtra, 0);
		}
	}

	return;
	UNREFERENCED_PARAMETER( hCallerWnd );
}

/*----------------------------------------------------------------------------*/
VOID bVDMRefresh( HWND hCallerWnd, LPCTSTR pszArgs )
{
	unloadSettings();
	loadSettings();

	return;
	UNREFERENCED_PARAMETER( hCallerWnd );
	UNREFERENCED_PARAMETER( pszArgs );
}

/*----------------------------------------------------------------------------*/
VOID bVDMShiftOrigin( HWND hCallerWnd, LPCTSTR pszArgs )
{
	if(NULL != pszArgs && 0 != *pszArgs)
	{
		if(0 == _tcsicmp(_T("+"), pszArgs))
		{
			shiftVD(TRUE);
		}
		else if (0 == _tcsicmp(_T("-"), pszArgs))
		{
			shiftVD(FALSE);
		}
	}

	return;
	UNREFERENCED_PARAMETER( hCallerWnd );
}

/*----------------------------------------------------------------------------*/
VOID bVDMWindowStretch( HWND hCallerWnd, LPCTSTR pszArgs )
{
	if(NULL != pszArgs && 0 != *pszArgs)
	{
		HWND hWnd1;
		HWND hWnd2;

		hWnd1 = GetForegroundWindow();
		hWnd2 = GetLastActivePopup(hWnd1);

		if(hWnd1 == hWnd2)
		{
			PSTRINGIDMAP pMap;

			for(pMap = s_stretchMap; NULL != pMap->pszStr; pMap++)
			{
				if(0 == _tcsicmp(pMap->pszStr, pszArgs))
				{
					stretchWnd(hWnd1, pMap->unID);
					break;
				}
			}
		}
	}

	return;
	UNREFERENCED_PARAMETER( hCallerWnd );
}

/*----------------------------------------------------------------------------*/
VOID bVDMWindowAlign( HWND hCallerWnd, LPCTSTR pszArgs )
{
	if(NULL != pszArgs && 0 != *pszArgs)
	{
		HWND hWnd1;
		HWND hWnd2;

		hWnd1 = GetForegroundWindow();
		hWnd2 = GetLastActivePopup(hWnd1);

		if(hWnd1 == hWnd2)
		{
			PSTRINGIDMAP pMap;

			for(pMap = s_alignMap; NULL != pMap->pszStr; pMap++)
			{
				if(0 == _tcsicmp(pMap->pszStr, pszArgs))
				{
					alignWnd(hWnd1, pMap->unID);
					break;
				}
			}
		}
	}

	return;
	UNREFERENCED_PARAMETER( hCallerWnd );
}

/*----------------------------------------------------------------------------*/
VOID bVDMWindowMaximize( HWND hCallerWnd, LPCTSTR pszArgs )
{
	HWND hWnd1;
	HWND hWnd2;

	hWnd1 = GetForegroundWindow();
	hWnd2 = GetLastActivePopup(hWnd1);

	if(hWnd1 == hWnd2)
	{
		ShowWindow(hWnd1, SW_MAXIMIZE);
	}

	return;
	UNREFERENCED_PARAMETER( hCallerWnd );
	UNREFERENCED_PARAMETER( pszArgs );
}

/*----------------------------------------------------------------------------*/
VOID bVDMWindowMinimize( HWND hCallerWnd, LPCTSTR pszArgs )
{
	HWND hWnd1;
	HWND hWnd2;

	hWnd1 = GetForegroundWindow();
	hWnd2 = GetLastActivePopup(hWnd1);

	if(hWnd1 == hWnd2)
	{
		ShowWindow(hWnd1, SW_SHOWMINNOACTIVE);
	}

	focusLast();

	return;
	UNREFERENCED_PARAMETER( hCallerWnd );
	UNREFERENCED_PARAMETER( pszArgs );
}

/*----------------------------------------------------------------------------*/
VOID bVDMWindowRestore( HWND hCallerWnd, LPCTSTR pszArgs )
{
	HWND hWnd1;
	HWND hWnd2;

	hWnd1 = GetForegroundWindow();
	hWnd2 = GetLastActivePopup(hWnd1);

	if(hWnd1 == hWnd2)
	{
		ShowWindow(hWnd1, SW_SHOWNOACTIVATE);
	}

	return;
	UNREFERENCED_PARAMETER( hCallerWnd );
	UNREFERENCED_PARAMETER( pszArgs );
}

#ifdef _DEBUG
/*----------------------------------------------------------------------------*/
VOID bVDMDebug( HWND hCallerWnd, LPCTSTR pszArgs )
{
	debugWindows();

	return;
	UNREFERENCED_PARAMETER( hCallerWnd );
	UNREFERENCED_PARAMETER( pszArgs );
}
#endif

/*----------------------------------------------------------------------------*/
VOID registerBangCmds( VOID )
{
	/* Virtual Desktop Management Commands */
	AddBangCommand(_T("!BVWMSWITCHTO"), bVDMSwitchTo);
	AddBangCommand(_T("!BVWMNEXT"), bVDMNext);
	AddBangCommand(_T("!BVWMPREV"), bVDMPrev);
	AddBangCommand(_T("!BVWMGATHER"), bVDMGather);
	AddBangCommand(_T("!BVWMGATHERH"), bVDMGatherH);
	AddBangCommand(_T("!BVWMGATHERV"), bVDMGatherV);
	AddBangCommand(_T("!BVWMGATHERLOST"), bVDMGatherLost);
	AddBangCommand(_T("!BVWMGATHERMATCHED"), bVDMGatherMatched);
	AddBangCommand(_T("!BVWMDESKS"), bVDMDesks);
	AddBangCommand(_T("!BVWMENABLEFOCUSLAST"), bVDMEnableFocusLast);
	AddBangCommand(_T("!BVWMDISABLEFOCUSLAST"), bVDMDisableFocusLast);
	AddBangCommand(_T("!BVWMMOVEWINDOW"), bVDMMoveWindow);
	AddBangCommand(_T("!BVWMEXECUTE"), bVDMExecute);
	AddBangCommand(_T("!BVWMREFRESH"), bVDMRefresh);
	AddBangCommand(_T("!BVWMSHIFTORIGIN"), bVDMShiftOrigin);

	/* Window Management Commands (maybe shouldn't be in this module?) */
	AddBangCommand(_T("!BVWMWINDOWSTRETCH"), bVDMWindowStretch);
	AddBangCommand(_T("!BVWMWINDOWALIGN"), bVDMWindowAlign);
	AddBangCommand(_T("!BVWMWINDOWMAXIMIZE"), bVDMWindowMaximize);
	AddBangCommand(_T("!BVWMWINDOWMINIMIZE"), bVDMWindowMinimize);
	AddBangCommand(_T("!BVWMWINDOWRESTORE"), bVDMWindowRestore);

	/* Wrapper Compatibility Commands */
	AddBangCommand(_T("!VWMDESK"), bVDMSwitchTo);
	AddBangCommand(_T("!VWMRIGHT"), bVDMNext);
	AddBangCommand(_T("!VWMDOWN"), bVDMNext);
	AddBangCommand(_T("!VWMLEFT"), bVDMPrev);
	AddBangCommand(_T("!VWMUP"), bVDMPrev);
	AddBangCommand(_T("!VWMGATHER"), bVDMGather);
	AddBangCommand(_T("!VWMMOVEAPP"), bVDMMoveWindow);
	AddBangCommand(_T("!VWMOPEN"), bVDMExecute);
	AddBangCommand(_T("!VWMRESET"), bVDMRefresh);

#ifdef _DEBUG
	AddBangCommand(_T("!VWMDEBUG"), bVDMDebug);
#endif
	return;
}

/*----------------------------------------------------------------------------*/
VOID unregisterBangCmds( VOID )
{
	RemoveBangCommand(_T("!BVWMSWITCHTO"));
	RemoveBangCommand(_T("!BVWMNEXT"));
	RemoveBangCommand(_T("!BVWMPREV"));
	RemoveBangCommand(_T("!BVWMGATHER"));
	RemoveBangCommand(_T("!BVWMGATHERH"));
	RemoveBangCommand(_T("!BVWMGATHERV"));
	RemoveBangCommand(_T("!BVWMGATHERLOST"));
	RemoveBangCommand(_T("!BVWMGATHERMATCHED"));
	RemoveBangCommand(_T("!BVWMDESKS"));
	RemoveBangCommand(_T("!BVWMENABLEFOCUSLAST"));
	RemoveBangCommand(_T("!BVWMDISABLEFOCUSLAST"));
	RemoveBangCommand(_T("!BVWMMOVEWINDOW"));
	RemoveBangCommand(_T("!BVWMEXECUTE"));
	RemoveBangCommand(_T("!BVWMREFRESH"));
	RemoveBangCommand(_T("!BVWMSHIFTORIGIN"));

	RemoveBangCommand(_T("!BVWMWINDOWSTRETCH"));
	RemoveBangCommand(_T("!BVWMWINDOWALIGN"));
	RemoveBangCommand(_T("!BVWMWINDOWMAXIMIZE"));
	RemoveBangCommand(_T("!BVWMWINDOWMINIMIZE"));
	RemoveBangCommand(_T("!BVWMWINDOWRESTORE"));

	RemoveBangCommand(_T("!VWMDESK"));
	RemoveBangCommand(_T("!VWMRIGHT"));
	RemoveBangCommand(_T("!VWMDOWN"));
	RemoveBangCommand(_T("!VWMLEFT"));
	RemoveBangCommand(_T("!VWMUP"));
	RemoveBangCommand(_T("!VWMGATHER"));
	RemoveBangCommand(_T("!VWMMOVEAPP"));
	RemoveBangCommand(_T("!VWMOPEN"));
	RemoveBangCommand(_T("!VWMRESET"));

#ifdef _DEBUG
	RemoveBangCommand(_T("!VWMDEBUG"));
#endif
	return;
}

/*----------------------------------------------------------------------------*/
