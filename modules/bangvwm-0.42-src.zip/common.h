/*------------------------------------------------------------------------------
	This is a Virtual Desktop Manager for use under Win32 Shells that
	support the LiteStep 0.24.5 module standard.

	Copyright (C) 2001-2003 Chris Rempel

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
------------------------------------------------------------------------------*/


/*----------------------------------------------------------------------------*/
#define SHELL_WINDOW_ID  (0x49474541)

/* BangVWM specific implementations */
#define GDO_MASK__DESKTOP           (0x00FFFFFF)
#define GDO_MASK__STATES            (0xFF000000)

#define GDO_STATE__CURRENT          (0x01000000)

#define GDO_FLAG__RETURN_SUPPORTED  (0xFFFFFFFF)
#define GDO_FLAG__RETURN_CURRENT    (0x00000001)

#define GDO_MASK__SUPPORTED_FLAGS   (GDO_STATE__CURRENT/*|others*/)

/* macro helpers */
#define VD_ISVALID(x)    ((UINT)(x) < g_unVDesks)
#define VD_NEXT          (g_unCurVD < VD_LAST ? (g_unCurVD + 1) : VD_FIRST)
#define VD_PREV          (VD_FIRST != g_unCurVD ? (g_unCurVD - 1) : VD_LAST)
#define VD_FIRST         (0)
#define VD_LAST          (g_unVDesks - 1)

#define VD_HORIZONTAL    (0x01)
#define VD_VERTICAL      (0x02)
#define VD_HORZVERT      (VD_HORIZONTAL|VD_VERTICAL)

/*----------------------------------------------------------------------------*/
enum EbvdmStretchMode
{
	 eBVDM_STRETCH__NONE = 0
	,eBVDM_STRETCH__VERTICAL
	,eBVDM_STRETCH__HORIZONTAL
	,eBVDM_STRETCH__BOTH
};

enum EbvdmAlignMode
{
	 eBVDM_ALIGN__NONE = 0
	,eBVDM_ALIGN__LEFT
	,eBVDM_ALIGN__RIGHT
	,eBVDM_ALIGN__TOP
	,eBVDM_ALIGN__BOTTOM
	,eBVDM_ALIGN__CENTER
	,eBVDM_ALIGN__MIDDLE
};

/*----------------------------------------------------------------------------*/
typedef void (__cdecl *FUNC_VOID__HWND_LPCTSTR)(HWND, LPCTSTR);
typedef void (WINAPI *FUNC_VOID__HWND_BOOL)(HWND, BOOL);
typedef BOOL (WINAPI *FUNC_BOOL__HWND_PTITLEBARINFO)(HWND, PTITLEBARINFO);
typedef BOOL (WINAPI *FUNC_BOOL__HWND_PWINDOWINFO)(HWND, PWINDOWINFO);

typedef struct _STRINGIDMAP
{
	LPCTSTR const pszStr;
	UINT const unID;
	//
} STRINGIDMAP, *PSTRINGIDMAP;
typedef const STRINGIDMAP * PCSTRINGIDMAP;

typedef struct _CLASSANDTITLE
{
	LPCTSTR pszClass;
	LPCTSTR pszTitle;
	//
} CLASSANDTITLE, *PCLASSANDTITLE;
typedef const CLASSANDTITLE * PCCLASSANDTITLE;

typedef struct _STICKYITEM
{
	_TCHAR szClass[256];
	_TCHAR szTitle[256];
	//
	struct _STICKYITEM *pNext;
	//
} STICKYITEM, *PSTICKYITEM;
typedef const STICKYITEM * PCSTICKYITEM;

/*----------------------------------------------------------------------------*/
#define EXPORT __declspec( dllexport )

#ifndef EXTERN_C
#ifdef __cplusplus
#define EXTERN_C extern "C"
#else
#define EXTERN_C extern
#endif /* __cplusplus */
#endif /* EXTERN_C */


/*----------------------------------------------------------------------------*/
/* Litestep API mess - because I'm wierd like that */

#if 0 /* Use PureLS headers */

#define DEFINEUNSUPPORTEDLSMSGS
#include "../../PureLS/purels/sdk/include/lsapi.h"

#elif 0 /* Use Litestep 0.24.7 SDK */

#include "../../litestep/sdk/include/lsapi.h"

#elif 0 /* Use Litestep 0.24.5 headers */

#include "../../litestep/ls-11-23-99/lsapi/lsapi.h"

#define LM_WINDOWACTIVATED              9504
#define LM_GETDESKTOPOF                 9361

#else /* Use our own declarations */

EXTERN_C BOOL AddBangCommand( LPCTSTR, FUNC_VOID__HWND_LPCTSTR );
EXTERN_C BOOL RemoveBangCommand( LPCTSTR );
EXTERN_C HWND GetLitestepWnd();
EXTERN_C BOOL GetRCBool( LPCTSTR, BOOL );
EXTERN_C INT GetRCInt( LPCTSTR, INT );
EXTERN_C BOOL GetRCLine( LPCTSTR, LPTSTR, size_t, LPCTSTR );
EXTERN_C LPVOID LCOpen( LPCTSTR );
EXTERN_C BOOL LCClose( LPVOID );
EXTERN_C BOOL LCReadNextConfig( LPVOID, LPCTSTR, LPTSTR, DWORD );
EXTERN_C INT LCTokenize( LPCTSTR, LPTSTR*, DWORD, LPTSTR );
EXTERN_C HINSTANCE LSExecute( HWND, LPCTSTR, INT );
EXTERN_C BOOL match( LPCTSTR, LPCTSTR );

#define LM_BRINGTOFRONT                 8891

#define LM_REGISTERMESSAGE              9263
#define LM_UNREGISTERMESSAGE            9264
#define LM_GETREVID                     9265

#define LM_REFRESH                      9305

#define LM_VWMUP                        9350
#define LM_VWMDOWN                      9351
#define LM_VWMLEFT                      9352
#define LM_VWMRIGHT                     9353
//#define LM_VWMNAV                       9354
#define LM_SWITCHTON                    9355
//#define LM_ISSTICKY                     9356
//#define LM_STICK                        9357
//#define LM_UNSTICK                      9358
//#define LM_LISTDESKTOPS                 9359
//#define LM_DESKTOPINFO                  9360
#define LM_GETDESKTOPOF                 9361

#define LM_WINDOWACTIVATED              9504

#endif /* Litestep header includes */

/* New define, no shells currently define it */
#ifndef LM_VWMNOTIFYCHANGE
#define LM_VWMNOTIFYCHANGE   (9370)
#endif



/*----------------------------------------------------------------------------*\
  BUILD INSTRUCTIONS
    Update the path above to point to your "lsapi.h".

    In the Project settings under the "Link" tab in the "Input" category drop
    down list, change the "additional include paths" to point to where your
    lsapi.lib file is located.  Do so for both debug and release builds.

  GENERAL NOTES
    main.c contains module init/quit functions and the window procedure.
    cmds.c contains all !bang command wrapper functions.
    utility.c contains the guts.

    Line wrap is 80 characters.  Tab size of 4 spaces.  A general formatting
    tip: Only use tabs to indent, not to align, use spaces to align.

    DeferWindowPos functionality is used throughout, and the HDWP is stored in
    a global handle.  It is first initiliazed in a "control" function then used
    in an EnumWindowsCallback procedure, then shutdown in the same function
    that initialized it after the callback returns.  Its fairly basic.

    The only thing I consider a 'hack' is my use of a global HWND to store
    the "active" window when "moving" it to another window.  This is actually
    achieved just by ignoring the HWND, since you need to remember that the
    desktop is not what moves.  The windows move, which creates the appearance
    that the desktop is moving to the user.  So anytime you want to keep a
    window on the screen, you simply don't move it.  That is why I found it
    easier to always make the desktop I'm working with to be the "active" one.

  BUGS, WORKING NOTES and SUGGESTED FEATURES
    !Move all Wnds on specifed VW to other specified VW.  (Seems pointless)

    !Fix PhotoShop tools and similiar.  (HIGH PRIORITY)

    !Need to repostion windows on resolution change.  (in progress)
     - Issue with this is that when going to a smaller resolution, this involves
       resizing windows, and I really don't want to do that.  However, MS Window
       manager does resize any minimized or visible window inside the desktop
       boundaries automatically.  But any window outside of the visible desktop
       is not auto resized.  This leaves me perplexed at what the solution
       should be. I suppose I could implement several and let the user decide
       which they want to use through settings.
     - Update: Implemented, except for handling maximized windows.  Currently I
       am just restoring the window, then updating its position.  Seems to work.

    !Bug when gathering windows, window contents is lost(???). (can't reproduce)
     - Perhaps the wrong HWND is being used?  Don't see how... Strange stuff.

    !When moving windows, all related windows need to be moved as well. (meaning
     a window has a popup window, and we move the popup window, we should move
     the main window as well.  Also the reverse case.
\*----------------------------------------------------------------------------*/


/*----------------------------------------------------------------------------*/
