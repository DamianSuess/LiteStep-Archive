/*------------------------------------------------------------------------------
	This is a Virtual Desktop Manager for use under Win32 Shells that
	support the LiteStep 0.24.5 module standard.

	Copyright (C) 2001-2003 Chris Rempel

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
------------------------------------------------------------------------------*/

/*---System Includes----------------------------------------------------------*/
#include <tchar.h>
#include <windows.h>

/*---Module Includes----------------------------------------------------------*/
#include "common.h"

/*----------------------------------------------------------------------------*/
/* From cmds.c */
EXTERN_C VOID registerBangCmds( VOID );
EXTERN_C VOID unregisterBangCmds( VOID );

/* From utility.c */
EXTERN_C VOID loadSettings( VOID );
EXTERN_C VOID unloadSettings( VOID );
EXTERN_C VOID onInit( VOID );
EXTERN_C VOID onQuit( VOID );
EXTERN_C VOID onDesktopUpdate( VOID );
EXTERN_C BOOL switchToVD( UINT const );
EXTERN_C BOOL switchToAndActivate( HWND const );
EXTERN_C UINT vdFromWindow( HWND const );
EXTERN_C BOOL isWindowInCurrentVD( HWND const );
EXTERN_C BOOL ignoreWindow( HWND const );
EXTERN_C VOID repositionWindows( LPCRECT const );
EXTERN_C VOID initVDSize( VOID );

EXTERN_C UINT g_unCurVD;
EXTERN_C UINT g_unVDesks;
EXTERN_C BOOL g_bSwitchOnFocus;
EXTERN_C BOOL g_bIgnoreDesktopUpdate;
EXTERN_C BOOL g_bAllowControl;

/*---Local Variables----------------------------------------------------------*/
static const INT s_nMsgs[] = \
{
	 LM_WINDOWACTIVATED
	,LM_BRINGTOFRONT
	,LM_SWITCHTON
	,LM_GETDESKTOPOF
	,LM_VWMUP
	,LM_VWMDOWN
	,LM_VWMLEFT
	,LM_VWMRIGHT
	,LM_GETREVID
	,0
};

static ATOM s_ClassAtom;
static HWND s_hMainWnd;
static HWND s_hShellWnd;

/*----------------------------------------------------------------------------*/
LRESULT WINAPI WndProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	switch(uMsg)
	{
	case WM_SETTINGCHANGE:
		if(SPI_SETWORKAREA != wParam)
		{
			break;
		}

		/* FALL THROUGH */

	case WM_DISPLAYCHANGE:
		if(!g_bIgnoreDesktopUpdate)
		{
			RECT r;

			if(!SystemParametersInfo(SPI_GETWORKAREA, 0, &r, 0))
			{
				GetWindowRect(GetDesktopWindow(), &r);
			}

			repositionWindows(&r);

			initVDSize();
		}

		onDesktopUpdate();
		break;

	case LM_WINDOWACTIVATED:
		if(g_bSwitchOnFocus && IsWindow((HWND)wParam))
		{
			switchToVD(vdFromWindow((HWND)wParam));
		}
		break;

	case LM_BRINGTOFRONT:
		if(g_bAllowControl && IsWindow((HWND)lParam))
		{
			return(switchToAndActivate((HWND)lParam));
		}
		break;

	case LM_SWITCHTON:
		if(g_bAllowControl)
		{
			return(switchToVD(wParam));
		}
		break;

	case LM_GETDESKTOPOF:
#if 0
		if(IsWindow((HWND)wParam))
		{
			UINT unVD = g_unCurVD;

			if(!ignoreWindow((HWND)wParam))
			{
				unVD = vdFromWindow((HWND)wParam);
			}

			if(0x00000001 == lParam)
			{
				unVD = (0x00FFFFFF & unVD) | 0x01000000;
			}

			return(unVD);
		}
		return(-1);

#else
		if(0 == wParam)
		{
			if(GDO_FLAG__RETURN_SUPPORTED == lParam)
			{
				return(GDO_MASK__SUPPORTED_FLAGS);
			}
		}
		else if(IsWindow((HWND)wParam))
		{
			UINT unVD = g_unCurVD;

			if(!ignoreWindow((HWND)wParam))
			{
				unVD = vdFromWindow((HWND)wParam);
			}

			if(0 != lParam)
			{
				unVD &= GDO_MASK__DESKTOP;

				if(
					unVD == g_unCurVD
					&&
					GDO_FLAG__RETURN_CURRENT==(GDO_FLAG__RETURN_CURRENT&lParam)
				)
				{
					unVD |= GDO_STATE__CURRENT;
				}
			}

			return(unVD);
		}
		return(-1);
#endif

	case LM_VWMLEFT:
	case LM_VWMUP:
		if(g_bAllowControl)
		{
			return(switchToVD(VD_PREV));
		}
		break;

	case LM_VWMRIGHT:
	case LM_VWMDOWN:
		if(g_bAllowControl)
		{
			return(switchToVD(VD_NEXT));
		}
		break;

	case LM_REFRESH:
		unloadSettings();
		loadSettings();
		break;

	case LM_GETREVID:
#if 1
		_tcscpy((LPTSTR)lParam, _T("BangVWM 0.42 (jugg)"));
#else
		_tcscpy(
			 (LPTSTR)lParam
			,_T("BangVWM ")
			 _T(__DATE__)
			 _T(" (jugg)")
		);
#endif
		return(_tcslen((LPTSTR)lParam));

	default:
		return(DefWindowProc(hWnd, uMsg, wParam, lParam));
	}

	return(0);
}

/*----------------------------------------------------------------------------*/
EXPORT VOID quitModule( HINSTANCE hInst )
{
	if(0 != s_ClassAtom)
	{
		if(NULL != s_hMainWnd)
		{
			onQuit();

			SendMessage(
				 s_hShellWnd
				,LM_UNREGISTERMESSAGE
				,(WPARAM)s_hMainWnd
				,(LPARAM)s_nMsgs
			);

			unregisterBangCmds();
			unloadSettings();

			DestroyWindow(s_hMainWnd);
			s_hMainWnd = NULL;
		}

		UnregisterClass(MAKEINTATOM(s_ClassAtom), hInst);
		s_ClassAtom = 0;
	}

	return;
}

/*----------------------------------------------------------------------------*/
EXPORT INT initModuleEx( HWND hWnd, HINSTANCE hInst, LPCTSTR pszPath )
{
	WNDCLASS wc;
	INT nRetVal = -1;

	s_hShellWnd = hWnd;

	/* register communication window class */
	memset(&wc, 0, sizeof(wc));

	wc.hInstance = hInst;
	wc.lpfnWndProc = WndProc;
	wc.lpszClassName = _T("BangVWMClass");
	wc.style = CS_NOCLOSE;

	s_ClassAtom = RegisterClass(&wc);

	if(0 != s_ClassAtom)
	{
		/*
		 * Can't make communication window a child of the shell, because it
		 * will not receive a WM_DISPLAYCHANGE message from the OS.  Only top
		 * level windows receive said message.
		 */
		s_hMainWnd = CreateWindowEx(
			 WS_EX_TOOLWINDOW
			,MAKEINTATOM(s_ClassAtom)
			,_T("")
			,WS_POPUP//WS_CHILD
			,0,0,0,0
			,NULL//s_hShellWnd
			,(HMENU)NULL
			,hInst
			,NULL
		);

		if(NULL == s_hMainWnd)
		{
			quitModule(hInst);
		}
		else
		{
			loadSettings();
			registerBangCmds();

			SendMessage(
				 s_hShellWnd
				,LM_REGISTERMESSAGE
				,(WPARAM)s_hMainWnd
				,(LPARAM)s_nMsgs
			);

			onInit();

			nRetVal = 0;
		}
	}

	return(nRetVal);
	UNREFERENCED_PARAMETER( pszPath );
}


/*----------------------------------------------------------------------------*/
