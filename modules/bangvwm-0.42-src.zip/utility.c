/*------------------------------------------------------------------------------
	This is a Virtual Desktop Manager for use under Win32 Shells that
	support the LiteStep 0.24.5 module standard.

	Copyright (C) 2001-2003 Chris Rempel

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
------------------------------------------------------------------------------*/

/*---System Includes----------------------------------------------------------*/
#include <tchar.h>
#include <stdio.h>
#include <windows.h>

/*---Module Includes----------------------------------------------------------*/
#include "common.h"

/*---Global Variables---------------------------------------------------------*/
UINT g_unCurVD, g_unVDesks;
BOOL g_bFocusLast, g_bSwitchOnFocus, g_bIgnoreDesktopUpdate;
BOOL g_bAllowControl;

/*---Local Variables----------------------------------------------------------*/
static HDWP s_hDwp;
static HWND s_hIgnoreWnd;
static RECT s_DTRect, s_WARect;
static INT s_nDTWidth, s_nDTHeight, s_nDTSpacing;
static INT s_nWAWidth, s_nWAHeight;
static BOOL s_bKeepMaximized, s_bVertical;
static BOOL s_bStrictGather, s_bNoWindowReposition;
static LPTSTR* s_pCmdList;
static LPTSTR s_pszOnInit, s_pszOnQuit, s_pszOnDesktopUpdate;
static PSTICKYITEM s_pStickyList;

FUNC_VOID__HWND_BOOL fpSwitchToThisWindow;
FUNC_BOOL__HWND_PTITLEBARINFO fpGetTitleBarInfo;
FUNC_BOOL__HWND_PWINDOWINFO fpGetWindowInfo;

/*---Local Defines/Macros-----------------------------------------------------*/
#define VD_SPACING   (s_nDTSpacing)
#define VD_WIDTH     (s_nDTWidth + VD_SPACING)
#define VD_HEIGHT    (s_nDTHeight + VD_SPACING)
#define VD_SIZE      (s_bVertical ? VD_HEIGHT : VD_WIDTH)

#define VD_MINCOUNT  (2)
#define VD_MINSPACE  (10)

#define VD_OFFSET(x) ((INT)(((x) - g_unCurVD) * VD_SIZE))

/*----------------------------------------------------------------------------*/


/*----------executeCmd----------------------------------------------------------
 Purpose:
 - To execute the command associated with the specified Virtual Desktop when
   switching to that VD.
------------------------------------------------------------------------------*/
VOID executeCmd( UINT const unVD )
{
	/*--------------------------------------------------------------------------
	 If the specified VD Is valid, and we have populated a command list, and
	 a command was defined for the specified desktop, then execute it.
	--------------------------------------------------------------------------*/
	if(VD_ISVALID(unVD) && NULL != s_pCmdList && NULL != s_pCmdList[unVD])
	{
		LSExecute(NULL, s_pCmdList[unVD], 0);
	}

	return;
}

VOID focusWindow( HWND const hWnd )
{
	if(NULL != fpSwitchToThisWindow)
	{
		fpSwitchToThisWindow(hWnd, TRUE);
	}
	else
	{
		SetForegroundWindow(GetLastActivePopup(hWnd));
		//BringWindowToTop(GetLastActivePopup(hWnd));
	}

	return;
}

/*----------------------------------------------------------------------------*/
BOOL matchWndToClassTitle( HWND const hWnd, PCCLASSANDTITLE const pcat )
{
	_TCHAR text[256];
	BOOL bRet;

	bRet = FALSE;

	/*--------------------------------------------------------------------------
	 Check to see if we were able to get the Class Name.  If so, match it
	 against the defined class name pattern.  If it matches, get the
	 Window Title and if successful, match it against the defined window
	 title pattern.  If it matched both Class and Title, then flag the
	 window as Sticky.

	 NOTE: GetClassName & GetWindowText always NULL terminates the buffers.
	--------------------------------------------------------------------------*/
	*text = 0;
	if(GetClassName(hWnd, text, 256))
	{
		if(match(pcat->pszClass, text))
		{
			*text = 0;
			GetWindowText(hWnd, text, 256);

			if(match(pcat->pszTitle, text))
			{
				bRet = TRUE;
			}
		}
	}

	return(bRet);
}

/*----------isSticky------------------------------------------------------------
 Purpose:
 - To determine whether the specified window has been defined by the user to
   stay on the current desktop at all times.
------------------------------------------------------------------------------*/
BOOL isSticky( HWND const hWnd )
{
	_TCHAR szClass[256] = {0};
	_TCHAR szTitle[256] = {0};
	PSTICKYITEM psi;

	GetClassName(hWnd, szClass, 256);
	GetWindowText(hWnd, szTitle, 256);

	/*--------------------------------------------------------------------------
	 Itterate through the sticky list until it is found, or we reach the end
	 of the list.
	--------------------------------------------------------------------------*/
	for(psi = s_pStickyList; NULL != psi; psi = psi->pNext)
	{
		if(match(psi->szClass, szClass) && match(psi->szTitle, szTitle))
		{
			break;
		}
	}

	return(NULL != psi);
}

/*----------ignoreWindow--------------------------------------------------------
 Purpose:
 - To determine whether the specified window is to be ignored by our code.
   Basically, this is a base check.  We do not care about minimized windows or
   hidden windows (duh!) or Shell Windows.
------------------------------------------------------------------------------*/
BOOL ignoreWindow( HWND const hWnd )
{
	//LONG lStyle = GetWindowLong(hWnd, GWL_STYLE);

	/*--------------------------------------------------------------------------
	 Check to see if it is minimized, or not visible, or a shell window.
	--------------------------------------------------------------------------*/
	return(
		IsIconic(hWnd) //WS_MINIMIZE == (lStyle & WS_MINIMIZE)
		||
		!IsWindowVisible(hWnd) //WS_VISIBLE != (lStyle & WS_VISIBLE)
		||
		SHELL_WINDOW_ID == GetWindowLong(hWnd, GWL_USERDATA)
	);
}

//
// I'm thinking about something like this for specifying an array of HWNDs to
// ignore instead of my single s_hIgnoreWnd HWND.  And adding this check to
// isOmniWindow().  It's sorta like a dynamic sticky window list of HWNDs.
//
//BOOL skipWindow( HWND const hWnd )
//{
//	HWND *phFound = s_phSkipWndArray;
//
//	if(NULL != phFound)
//	{
//		while(NULL != *phFound)
//		{
//			if(hWnd == *phFound)
//			{
//				break;
//			}
//
//			phFound++;
//		}
//	}
//
//	return(NULL != phFound && NULL != *phFound);
//}

/*----------isOmniWindow--------------------------------------------------------
 Purpose:
 - To determine whether the specified window is to stay on the current desktop
   at all times (or in other words, we simply do not modify it's position).
   This happens if it is minimized, not visible, a shell window, or the user
   specified the window as "Sticky".
------------------------------------------------------------------------------*/
BOOL isOmniWindow( HWND const hWnd )
{
	return(ignoreWindow(hWnd) || isSticky(hWnd));
}

/*----------------------------------------------------------------------------*/
INT deskDifH( HWND const hWnd )
{
	INT nDeskDif, nSize;
	RECT rWnd, rFinal;

	/*--------------------------------------------------------------------------
	 Get the specified window's rectangle.
	--------------------------------------------------------------------------*/
	GetWindowRect(hWnd, &rWnd);

	nSize = rWnd.right - rWnd.left;

	nDeskDif = rWnd.left / VD_WIDTH;

	rWnd.left %= VD_WIDTH;
	rWnd.right = rWnd.left + nSize;
	/*
	 The vertical offset doesn't affect anything, but we want to always
	 check to see if our horizontal offset intersects the s_DTRect, so we
	 need the vertical position to be overlapping.
	*/
	rWnd.top = s_DTRect.top;
	rWnd.bottom = s_DTRect.bottom;

	/*
	 If we do not intersect, or if we do and we are not completely on the
	 desktop, then we need to check what specific desktop we are actually
	 on.
	*/
	if(
		!IntersectRect(&rFinal, &rWnd, &s_DTRect)
		||
		(rFinal.right - rFinal.left) != nSize
	)
	{
		/*
		 If the left of the window is off the desktop, then it may be on
		 the previous desktop.
		*/
		if(rWnd.left < -(VD_SPACING))
		{
			/*
			 If less than 1/2 of the window is visible then we consider it
			 on the previous desktop.
			*/
			if((rFinal.right - rFinal.left) < ((nSize - VD_SPACING) / 2))
			{
				/*
				 If we are on the first VD, and part of the window is
				 visible, then we should just accept it as the current VD,
				 otherwise, we'd return an invalid VD.  But if the window is
				 not visible, then go ahead and return the invalid VD, so
				 that we know that it is a "lost" window.
				*/
				if(
					VD_FIRST != (g_unCurVD + nDeskDif)
					||
					0 == (rFinal.right - rFinal.left)
				)
				{
					nDeskDif -= 1;
				}
			}
			/* 
			 Special case, when the height is so small, that the result of
			 (nSize - VD_SPACING) is negative.
			*/
			else if(nSize <= VD_SPACING)
			{
				nDeskDif -= 1;
			}
		}
		/*
		 Otherwise, if the right of the window is off the desktop, then
		 the window may be considered to be on the next desktop.
		*/
		else if(rWnd.right > VD_WIDTH)
		{
			/*
			 Same as above, but '<=' because one or the other has to get
			 the extra pixel otherwise, depending if you were on a VD to
			 the left or the right of the window you would get a different
			 VD value for that window.
			*/
			if((rFinal.right - rFinal.left) <= ((nSize - VD_SPACING) / 2))
			{
				/* See similiar block above for comment. */
				if(
					VD_LAST != (g_unCurVD + nDeskDif)
					||
					0 == (rFinal.right - rFinal.left)
				)
				{
					nDeskDif += 1;
				}
			}
		}
	}

	return(nDeskDif);
}

/*----------------------------------------------------------------------------*/
INT deskDifV( HWND const hWnd )
{
	TITLEBARINFO tb;
	INT nDeskDif, nSize;
	RECT rWnd, rFinal;

	/*--------------------------------------------------------------------------
	 Get the specified window's rectangle.
	--------------------------------------------------------------------------*/
	GetWindowRect(hWnd, &rWnd);

	nSize = 0;

	/* Use the window's title bar as the RECT that we want to work with. */
	memset(&tb, 0, sizeof(TITLEBARINFO));
	tb.cbSize = sizeof(TITLEBARINFO);

	/*
	 * NOTE: This block of code needs more testing to determine whether it is
	 * working on all types of windows.
	 */
	if(NULL != fpGetTitleBarInfo && fpGetTitleBarInfo(hWnd, &tb))
	{
		WINDOWINFO wi;

		memset(&wi, 0, sizeof(WINDOWINFO));
		wi.cbSize = sizeof(WINDOWINFO);

		nSize = tb.rcTitleBar.bottom - tb.rcTitleBar.top;

		/* We need to add on the window top border height to our size. */
		if(0 != nSize)
		{
			if(NULL != fpGetWindowInfo && fpGetWindowInfo(hWnd, &wi))
			{
				nSize += wi.cyWindowBorders;
			}
			else
			{
				nSize += 3; // Hardcode a typical border size
			}
		}
	}

	/*
	 If we were not able to get a title bar size, then use the whole
	 window height instead.
	*/
	if(0 == nSize)
	{
		nSize = rWnd.bottom - rWnd.top;
	}

	nDeskDif = rWnd.top / VD_HEIGHT;

	rWnd.top %= VD_HEIGHT;
	rWnd.bottom = rWnd.top + nSize;
	/*
	 The horizontal offset doesn't affect anything, but we want to always
	 check to see if our vertical offset intersects the s_DTRect, so we
	 need the horizontal position to be overlapping.
	*/
	rWnd.left = s_DTRect.left;
	rWnd.right = s_DTRect.right;

	/*
	 If we do not intersect, or if we do and we are not completely on the
	 desktop, then we need to check what specific desktop we are actually
	 on.
	*/
	if(
		!IntersectRect(&rFinal, &rWnd, &s_DTRect)
		||
		(rFinal.bottom - rFinal.top) != nSize
	)
	{
		/*
		 If the top of the window is above the desktop, then it may be on
		 the previous desktop.
		*/
		if(rWnd.top < -(VD_SPACING))
		{
			/*
			 If less than 1/2 of the window is visible then we consider it
			 on the previous desktop.
			*/
			if((rFinal.bottom - rFinal.top) < ((nSize - VD_SPACING) / 2))
			{
				/*
				 If we are on the first VD, and part of the window is
				 visible, then we should just accept it as the current VD,
				 otherwise, we'd return an invalid VD.  But if the window is
				 not visible, then go ahead and return the invalid VD, so
				 that we know that it is a "lost" window.
				*/
				if(
					VD_FIRST != (g_unCurVD + nDeskDif)
					||
					0 == (rFinal.bottom - rFinal.top)
				)
				{
					nDeskDif -= 1;
				}
			}
			/* 
			 Special case, when the height is so small, that the result of
			 (nSize - VD_SPACING) is negative.
			*/
			else if(nSize < VD_SPACING)
			{
				nDeskDif -= 1;
			}
		}
		/*
		 Otherwise, if the bottom of the window is below the desktop, then
		 the window may be considered to be on the next desktop.
		*/
		else if(rWnd.bottom > VD_HEIGHT)
		{
			if((rFinal.bottom - rFinal.top) <= ((nSize - VD_SPACING) / 2))
			{
				if(
					VD_LAST != (g_unCurVD + nDeskDif)
					||
					0 == (rFinal.bottom - rFinal.top)
				)
				{
					nDeskDif += 1;
				}
			}
		}
	}

	return(nDeskDif);
}

/*----------vdFromWindow--------------------------------------------------------
 Purpose:
 - To get the Virtual Desktop that a window is located on.

 If we are in "vertical" layout mode, then we need to use the title bar of the
 window as the determinate rectangle for which virtual desktop the window is
 located on, this is so that a user can always have access to the window's title
 bar.

 If we are in the default "horizontal" layout mode, then we simply do a 50/50
 split to determine which desktop a window is on.  See deskDifV and deskDivH.
------------------------------------------------------------------------------*/
UINT vdFromWindow( HWND const hWnd )
{
	return(g_unCurVD + (s_bVertical ? deskDifV(hWnd):deskDifH(hWnd)));
}

/*----------isWindowInVD--------------------------------------------------------
 Purpose:
 - To determine whether the specified window is located on the specified
   Virtual Desktop.
------------------------------------------------------------------------------*/
BOOL isWindowInVD( HWND const hWnd, UINT const unVD )
{
	return(unVD == vdFromWindow(hWnd));
}

/*----------isWindowInCurrentVD-------------------------------------------------
 Purpose:
 - To determine whether the specified window is located on the current Virtual
   Desktop.
------------------------------------------------------------------------------*/
BOOL isWindowInCurrentVD( HWND const hWnd )
{
	/*--------------------------------------------------------------------------
	 Simply make this function a wrapper to isWindowInVD and pass in the
	 current desktop number.
	--------------------------------------------------------------------------*/
	return(isWindowInVD(hWnd, g_unCurVD));
}

/*----------------------------------------------------------------------------*/
BOOL updateRectH( HWND const hWnd, PRECT const pWndRect )
{
	INT nSize;
	INT nDeskDif;
	BOOL bRetVal = FALSE;

	nDeskDif = deskDifH(hWnd);

	if(0 != nDeskDif)
	{
		nSize = pWndRect->right - pWndRect->left;

		pWndRect->left -= nDeskDif * VD_WIDTH;
		pWndRect->right = pWndRect->left + nSize;

		bRetVal = TRUE;
	}

	return(bRetVal);
}

/*----------------------------------------------------------------------------*/
BOOL updateRectV( HWND const hWnd, PRECT const pWndRect )
{
	INT nSize;
	INT nDeskDif;
	BOOL bRetVal = FALSE;

	nDeskDif = deskDifV(hWnd);

	if(0 != nDeskDif)
	{
		nSize = pWndRect->bottom - pWndRect->top;

		pWndRect->top -= nDeskDif * VD_HEIGHT;
		pWndRect->bottom = pWndRect->top + nSize;

		bRetVal = TRUE;
	}

	return(bRetVal);
}


#ifdef _DEBUG
/************************* DEBUG **********************************************/
VOID debugPrintf(LPCTSTR szCaption, LPCTSTR szFormat, ...)
{
	_TCHAR szBuffer [2048];
	va_list pArgList;

	if(szCaption != NULL && szFormat != NULL && 0 != *szFormat)
	{
		va_start (pArgList, szFormat);
		_vsntprintf (szBuffer, sizeof(szBuffer) / sizeof(_TCHAR), szFormat, pArgList);
		va_end (pArgList);

		OutputDebugString(szCaption);
		OutputDebugString(_T(": "));
		OutputDebugString(szBuffer);
		OutputDebugString(_T("\n\r"));
	}

	return;
}

VOID printWindowInfo( HWND hWnd, INT nVD )
{
	_TCHAR szBuffer[2048] = {0};
	_TCHAR szBuffer1[512] = {0};
	_TCHAR szBuffer2[512] = {0};
	RECT r = {0,0,0,0};

	GetWindowText(hWnd, szBuffer1, 512);
	GetClassName(hWnd, szBuffer2, 512);
	GetWindowRect(hWnd, &r);

	_stprintf(szBuffer, _T("- HWND(0x%08X) - Desktop %d\r\n  CLASS(%s)\r\n  TITLE(%s)\r\n  RECT(%d,%d,%d,%d) - width(%d) height(%d)"), hWnd, nVD, szBuffer2, szBuffer1, r.left, r.top, r.right, r.bottom, r.right - r.left, r.bottom - r.top);
	OutputDebugString(szBuffer);
	//OutputDebugString(szBuffer1);
	OutputDebugString(_T("\r\n"));
	//debugPrintf(_T("WindowInfo"), _T("HWND(0x%08) - CLASS(%s) - TITLE(%s)\r\n   RECT(%d,%d,%d,%d)"), hWnd, szBuffer2, szBuffer1, r.left, r.top, r.right, r.bottom);
	return;
}

BOOL CALLBACK EnumProcDebug( HWND hWnd, LPARAM lParam )
{
	if( !isOmniWindow(hWnd) )
	{
#if 0
		_TCHAR szClass[256] = {0};
		_TCHAR szTitle[256] = {0};

		GetClassName(hWnd, szClass, 256);
		GetWindowText(hWNd, szTitle, 256);

		if(match(_T("Notepad"), szClass) && match(_T("*"), szTitle))
		{
			vdFromWindow(hWnd);
			return(FALSE);
		}
#else
		printWindowInfo(hWnd, vdFromWindow(hWnd));
#endif
	}

	return(TRUE);
        UNREFERENCED_PARAMETER(lParam);
}

VOID debugWindows( VOID )
{
	EnumWindows(EnumProcDebug, 0);
	return;
}
/************************* END DEBUG ******************************************/
#endif /* _DEBUG */



/*----------------------------------------------------------------------------*/
BOOL CALLBACK EnumProcSwitchTo( HWND hWnd, LPARAM lParam )
{
	if( !isOmniWindow(hWnd) && s_hIgnoreWnd != hWnd )
	{
		RECT r;

		if( !s_bKeepMaximized && IsZoomed(hWnd) )
		{
			ShowWindow(hWnd, SW_SHOWNOACTIVATE);
		}

		GetWindowRect(hWnd, &r);
		if( s_bVertical )
		{
			r.top -= (INT)lParam;
		}
		else
		{
			r.left -= (INT)lParam;
		}

		s_hDwp = DeferWindowPos(
			 s_hDwp
			,hWnd
			,NULL
			,r.left
			,r.top
			,0
			,0
			,SWP_NOZORDER|SWP_NOACTIVATE|SWP_NOSIZE
		);
	}

	return(TRUE);
}

/*----------------------------------------------------------------------------*/
BOOL CALLBACK EnumProcGatherTo( HWND hWnd, LPARAM lParam )
{
	if(!isOmniWindow(hWnd))
	{
		RECT r;
		BOOL bUpdated = FALSE;
		char const cType = (char const)lParam;

		if(!s_bKeepMaximized && IsZoomed(hWnd))
		{
			ShowWindow(hWnd, SW_SHOWNOACTIVATE);
		}

		GetWindowRect(hWnd, &r);

		if(0x00 != (cType & VD_HORIZONTAL) && updateRectH(hWnd, &r))
		{
			bUpdated = TRUE;
		}
		if(0x00 != (cType & VD_VERTICAL) && updateRectV(hWnd, &r))
		{
			bUpdated = TRUE;
		}

		if(bUpdated)
		{
			s_hDwp = DeferWindowPos(
				 s_hDwp
				,hWnd
				,NULL
				,r.left
				,r.top
				,0
				,0
				,SWP_NOZORDER|SWP_NOACTIVATE|SWP_NOSIZE
			);
		}
	}

	return(TRUE);
}

/*----------------------------------------------------------------------------*/
BOOL CALLBACK EnumProcGatherLostTo( HWND hWnd, LPARAM lParam )
{
	if(!isOmniWindow(hWnd) && !VD_ISVALID(vdFromWindow(hWnd)))
	{
		RECT r;
		BOOL bUpdated = FALSE;

		if(!s_bKeepMaximized && IsZoomed(hWnd))
		{
			ShowWindow(hWnd, SW_SHOWNOACTIVATE);
		}

		GetWindowRect(hWnd, &r);

		if(updateRectH(hWnd, &r))
		{
			bUpdated = TRUE;
		}
		if(updateRectV(hWnd, &r))
		{
			bUpdated = TRUE;
		}

		if(bUpdated)
		{
			s_hDwp = DeferWindowPos(
				 s_hDwp
				,hWnd
				,NULL
				,r.left
				,r.top
				,0
				,0
				,SWP_NOZORDER|SWP_NOACTIVATE|SWP_NOSIZE
			);
		}
	}

	return(TRUE);
	UNREFERENCED_PARAMETER( lParam );
}

/*----------------------------------------------------------------------------*/
BOOL CALLBACK EnumProcGatherMatchedTo( HWND hWnd, LPARAM lParam )
{
	PCCLASSANDTITLE const pcat = (PCCLASSANDTITLE)lParam;

	if(!isOmniWindow(hWnd) && matchWndToClassTitle(hWnd, pcat))
	{
		RECT r;
		BOOL bUpdated = FALSE;

		if(!s_bKeepMaximized && IsZoomed(hWnd))
		{
			ShowWindow(hWnd, SW_SHOWNOACTIVATE);
		}

		GetWindowRect(hWnd, &r);

		if(updateRectH(hWnd, &r))
		{
			bUpdated = TRUE;
		}
		if(updateRectV(hWnd, &r))
		{
			bUpdated = TRUE;
		}

		if(bUpdated)
		{
			s_hDwp = DeferWindowPos(
				 s_hDwp
				,hWnd
				,NULL
				,r.left
				,r.top
				,0
				,0
				,SWP_NOZORDER|SWP_NOACTIVATE|SWP_NOSIZE
			);
		}
	}

	return(TRUE);
	UNREFERENCED_PARAMETER( lParam );
}

/*----------------------------------------------------------------------------*/
BOOL CALLBACK EnumProcFocusLast( HWND hWnd, LPARAM lParam )
{
	if(WS_EX_TOPMOST != (GetWindowLong(hWnd, GWL_EXSTYLE) & WS_EX_TOPMOST))
	{
		if(!ignoreWindow(hWnd) && isWindowInVD(hWnd, lParam))
		{
			focusWindow(hWnd);

			return(FALSE);
		}
	}

	return(TRUE);
	UNREFERENCED_PARAMETER( lParam );
}

/*----------------------------------------------------------------------------*/
VOID focusLast( VOID )
{
	if(g_bFocusLast)
	{
		HWND hWnd;

		hWnd = GetForegroundWindow();

		if(ignoreWindow(hWnd) || !isWindowInCurrentVD(hWnd))
		{
			EnumWindows(EnumProcFocusLast, (LPARAM)g_unCurVD);
		}
	}

	return;
}

/*----------------------------------------------------------------------------*/
VOID shiftVD( BOOL const bPositive )
{
	INT nAdd;

	nAdd = VD_SIZE;

	if(!bPositive)
	{
		nAdd *= -1;
	}

	s_hDwp = BeginDeferWindowPos(1);

	EnumWindows(EnumProcSwitchTo, (LPARAM)nAdd);

	EndDeferWindowPos(s_hDwp);

	return;
}

/*----------------------------------------------------------------------------*/
BOOL switchToVDEx( UINT const unVD, BOOL const bNoFocus )
{
	BOOL bRet = FALSE;

	if(unVD != g_unCurVD && VD_ISVALID(unVD))
	{
		s_hDwp = BeginDeferWindowPos(1);

		EnumWindows(EnumProcSwitchTo, (LPARAM)VD_OFFSET(unVD));

		EndDeferWindowPos(s_hDwp);

		g_unCurVD = unVD;

		if(!bNoFocus)
		{
			focusLast();
		}

		executeCmd(g_unCurVD);

		SendMessage(
			 GetLitestepWnd()
			,LM_VWMNOTIFYCHANGE
			,(WPARAM)g_unCurVD
			,(LPARAM)0
		);

		bRet = TRUE;
	}

	return(bRet);
}

/*----------------------------------------------------------------------------*/
BOOL switchToVD( UINT const unVD )
{
	return(switchToVDEx(unVD, FALSE));
}

/*----------------------------------------------------------------------------*/
BOOL switchToAndActivate( HWND const hWnd )
{
	UINT unVD;
	BOOL bRet = FALSE;

	unVD = vdFromWindow(hWnd);

	if(VD_ISVALID(unVD))
	{
		if(unVD != g_unCurVD)
		{
			s_hDwp = BeginDeferWindowPos(1);

			EnumWindows(EnumProcSwitchTo, (LPARAM)VD_OFFSET(unVD));

			EndDeferWindowPos(s_hDwp);
		}

		focusWindow(hWnd);

		if(unVD != g_unCurVD)
		{
			g_unCurVD = unVD;

			executeCmd(g_unCurVD);

			SendMessage(
				 GetLitestepWnd()
				,LM_VWMNOTIFYCHANGE
				,(WPARAM)g_unCurVD
				,(LPARAM)0
			);
		}

		bRet = TRUE;
	}

	return(bRet);
}

/*----------------------------------------------------------------------------*/
VOID gatherToVD( UINT const unVD, char const cType )
{
	if(VD_ISVALID(unVD))
	{
		s_hDwp = BeginDeferWindowPos(1);

		EnumWindows(EnumProcGatherTo, (LPARAM)cType);

		EndDeferWindowPos(s_hDwp);

		if(unVD != g_unCurVD)
		{
			g_unCurVD = unVD;

			focusLast();

			executeCmd(g_unCurVD);

			SendMessage(
				 GetLitestepWnd()
				,LM_VWMNOTIFYCHANGE
				,(WPARAM)g_unCurVD
				,(LPARAM)0
			);
		}
	}

	return;
}

/*----------------------------------------------------------------------------*/
VOID gatherLostToVD( UINT const unVD )
{
	if(VD_ISVALID(unVD))
	{
		s_hDwp = BeginDeferWindowPos(1);

		if(unVD != g_unCurVD)
		{
			EnumWindows(EnumProcSwitchTo, (LPARAM)VD_OFFSET(unVD));
		}

		EnumWindows(EnumProcGatherLostTo, 0);

		EndDeferWindowPos(s_hDwp);

		if(unVD != g_unCurVD)
		{
			g_unCurVD = unVD;

			focusLast();

			executeCmd(g_unCurVD);

			SendMessage(
				 GetLitestepWnd()
				,LM_VWMNOTIFYCHANGE
				,(WPARAM)g_unCurVD
				,(LPARAM)0
			);
		}
	}

	return;
}

/*----------------------------------------------------------------------------*/
VOID gatherMatchedToVD( UINT const unVD, PCCLASSANDTITLE const pcat )
{
	if(VD_ISVALID(unVD))
	{
		s_hDwp = BeginDeferWindowPos(1);

		if(unVD != g_unCurVD)
		{
			EnumWindows(EnumProcSwitchTo, (LPARAM)VD_OFFSET(unVD));
		}

		EnumWindows(EnumProcGatherMatchedTo, (LPARAM)pcat);

		EndDeferWindowPos(s_hDwp);

		if(unVD != g_unCurVD)
		{
			g_unCurVD = unVD;

			focusLast();

			executeCmd(g_unCurVD);

			SendMessage(
				 GetLitestepWnd()
				,LM_VWMNOTIFYCHANGE
				,(WPARAM)g_unCurVD
				,(LPARAM)0
			);
		}
	}

	return;
}

/*----------------------------------------------------------------------------*/
VOID moveWndToVD( HWND const hWnd, UINT const unVD )
{
	if(VD_ISVALID(unVD) && unVD != vdFromWindow(hWnd))
	{
		s_hIgnoreWnd = hWnd;

		s_hDwp = BeginDeferWindowPos(1);

		if(unVD != g_unCurVD)
		{
			EnumWindows(EnumProcSwitchTo, (LPARAM)VD_OFFSET(unVD));
		}

		EnumProcGatherTo(hWnd, (LPARAM)(char const)VD_HORZVERT);

		EndDeferWindowPos(s_hDwp);

		s_hIgnoreWnd = NULL;

		if(unVD != g_unCurVD)
		{
			g_unCurVD = unVD;

			executeCmd(g_unCurVD);

			SendMessage(
				 GetLitestepWnd()
				,LM_VWMNOTIFYCHANGE
				,(WPARAM)g_unCurVD
				,(LPARAM)0
			);
		}
	}

	return;
}

/*----------------------------------------------------------------------------*/
VOID moveActiveWndToVD( UINT const unVD )
{
	/*
	 THIS NEEDS TO BE UPDATED TO MOVE ALL WINDOWS
	 OF THE ACTIVE THREAD (and/or?) PROCESS (and/or/only?) window heirarchy
	*/
	moveWndToVD(GetForegroundWindow(), unVD);

	return;
}

/*----------------------------------------------------------------------------*/
/* NOTE:
 *   This function is a special case, that is executed before any global values
 *   have been updated.  This allows us to use our other functions to determine
 *   what desktop, and positions a window had before the resolution/ work area
 *   changed.  Then, we used the new work area rectangle that was passed in to
 *   determine the new position on the windows desktop.
 *
 *   The quick run down is, that the MS window manager will resize/position all
 *   windows that are visible on the current desktop, and that are minimized.
 *   Any window that is off the desktop are not automatically resized.  So, this
 *   leaves the responsibility to us to move/resize windows.  I don't like it,
 *   but it seems like there isn't much choice.  I'd like to figure out a neater
 *   way to handle this, but have come up with nothing so far.
 *
 *   TODO: Fix off screen maximized windows, so they can stay maximized, and
 *         their restored rect size is valid.
 *
 *         Fix the repositioning code so that we move windows by percentages, so
 *         that a window that was centered previously, is still centered.  Right
 *         now a window is just brought inside of the desktop borders without
 *         regards to previous screen location.
 */
BOOL CALLBACK EnumProcReposition( HWND hWnd, LPARAM lParam )
{
	if(!ignoreWindow(hWnd))
	{
		INT nWAWidth, nWAHeight;
		INT nWndWidth, nWndHeight;
		UINT uWndVD;
		RECT rWnd;
		LPCRECT pWARect = (LPCRECT)lParam;

		uWndVD = vdFromWindow(hWnd);

		if(uWndVD == g_unCurVD)
		{
			return(TRUE);
		}

		nWAWidth = pWARect->right - pWARect->left;
		nWAHeight = pWARect->bottom - pWARect->top;

		/*
		 * I'd like to be able to figure out how to make a maximized window
		 * reposition itself to the new workarea, but at this point, I haven't
		 * come up with anything.  Besides, that would also require using
		 * Set/GetWindowPlacement() and converting between workarea and screen
		 * coordinates depending if the window is WS_EX_TOOLWINDOW or not. That
		 * just seems to be getting messy.  So for now, we simply restore all
		 * windows that are maximized. :(
		 */
		if(IsZoomed(hWnd))
		{
			ShowWindow(hWnd, SW_SHOWNOACTIVATE);
		}

		GetWindowRect(hWnd, &rWnd);

		nWndWidth = rWnd.right - rWnd.left;
		nWndHeight = rWnd.bottom - rWnd.top;

		/* Restore the window to 'useable' coordinates. */
		if(s_bVertical)
		{
			updateRectV(hWnd, &rWnd);
		}
		else
		{
			updateRectH(hWnd, &rWnd);
		}

		/* Update the window position on the desktop vertically if needed. */
		if(nWndHeight > nWAHeight)
		{
			rWnd.top = pWARect->top;
			nWndHeight = nWAHeight;
		}
		else if(rWnd.top < pWARect->top)
		{
			rWnd.top = pWARect->top;
		}
		else if(rWnd.bottom > pWARect->bottom)
		{
			//rWnd.top = (INT)((float)rWnd.top / s_nWAHeight * nWAHeight);
			rWnd.top = pWARect->bottom - nWndHeight;
		}

		/* Update the window position on the desktop horizontally if needed. */
		if(nWndWidth > nWAWidth)
		{
			rWnd.left = pWARect->left;
			nWndWidth = nWAWidth;
		}
		else if(rWnd.left < pWARect->left)
		{
			rWnd.left = pWARect->left;
		}
		else if(rWnd.right > pWARect->right)
		{
			//rWnd.left = (INT)((float)rWnd.left / s_nWAWidth * nWAWidth);
			rWnd.left = pWARect->right - nWndWidth;
		}

		/* Put the window back on the desktop it came from. */
		if(s_bVertical)
		{
			rWnd.top += (INT)((uWndVD - g_unCurVD) * (nWAHeight + VD_SPACING));
		}
		else
		{
			rWnd.left += (INT)((uWndVD - g_unCurVD) * (nWAWidth + VD_SPACING));
		}

		/* Now finally reposition and size the window */
		s_hDwp = DeferWindowPos(
			 s_hDwp
			,hWnd
			,NULL
			,rWnd.left
			,rWnd.top
			,nWndWidth
			,nWndHeight
			,SWP_NOZORDER|SWP_NOACTIVATE
		);
	}

	return(TRUE);
}

/*----------------------------------------------------------------------------*/
VOID repositionWindows( LPCRECT const pRect )
{
	if(!s_bNoWindowReposition && !EqualRect(pRect, &s_WARect))
	{
		s_hDwp = BeginDeferWindowPos(1);

		EnumWindows(EnumProcReposition, (LPARAM)pRect);

		EndDeferWindowPos(s_hDwp);
	}

	return;
}

/*----------------------------------------------------------------------------*/
VOID stretchWnd( HWND const hWnd, enum EbvdmStretchMode const enStretch )
{
	if(!IsZoomed(hWnd))
	{
		UINT unWndVD;
		RECT rWnd;

		unWndVD = vdFromWindow(hWnd);

		GetWindowRect(hWnd, &rWnd);

		switch( enStretch )
		{
		case eBVDM_STRETCH__VERTICAL:
			SetWindowPos(
				 hWnd
				,NULL
				,rWnd.left
				,s_WARect.top
				,rWnd.right - rWnd.left
				,s_nWAHeight
				,SWP_NOACTIVATE|SWP_NOOWNERZORDER|SWP_NOZORDER
			);
			break;

		case eBVDM_STRETCH__HORIZONTAL:
			SetWindowPos(
				 hWnd
				,NULL
				,s_WARect.left
				,rWnd.top
				,s_nWAWidth
				,rWnd.bottom - rWnd.top
				,SWP_NOACTIVATE|SWP_NOOWNERZORDER|SWP_NOZORDER
			);
			break;

		case eBVDM_STRETCH__BOTH:
			SetWindowPos(
				 hWnd
				,NULL
				,s_WARect.left
				,s_WARect.top
				,s_nWAWidth
				,s_nWAHeight
				,SWP_NOACTIVATE|SWP_NOOWNERZORDER|SWP_NOZORDER
			);
			break;
		}

		if(unWndVD != g_unCurVD && g_unCurVD == vdFromWindow(hWnd))
		{
			SendMessage(
				 GetLitestepWnd()
				,LM_VWMNOTIFYCHANGE
				,(WPARAM)g_unCurVD
				,(LPARAM)0
			);
		}
	}

	return;
}

/*----------------------------------------------------------------------------*/
VOID alignWnd( HWND const hWnd, enum EbvdmAlignMode const enAlign )
{
	if(!IsZoomed(hWnd))
	{
		UINT unWndVD;
		RECT rWnd;
		INT nX, nY;

		unWndVD = vdFromWindow(hWnd);

		GetWindowRect(hWnd, &rWnd);

		switch( enAlign )
		{
		case eBVDM_ALIGN__LEFT:
			nX = s_WARect.left;
			nY = rWnd.top;
			break;

		case eBVDM_ALIGN__RIGHT:
			nX = s_WARect.right - (rWnd.right - rWnd.left);
			nY = rWnd.top;
			break;

		case eBVDM_ALIGN__TOP:
			nX = rWnd.left;
			nY = s_WARect.top;
			break;

		case eBVDM_ALIGN__BOTTOM:
			nX = rWnd.left;
			nY = s_WARect.bottom - (rWnd.bottom - rWnd.top);
			break;

		case eBVDM_ALIGN__CENTER:
			nX = s_WARect.left + ((s_nWAWidth - (rWnd.right - rWnd.left)) / 2);
			nY = rWnd.top;
			break;

		case eBVDM_ALIGN__MIDDLE:
			nX = rWnd.left;
			nY = s_WARect.top + ((s_nWAHeight - (rWnd.bottom - rWnd.top)) / 2);
			break;

		default:
			return;
		}

		SetWindowPos(
			 hWnd
			,NULL
			,nX
			,nY
			,0
			,0
			,SWP_NOACTIVATE|SWP_NOOWNERZORDER|SWP_NOZORDER|SWP_NOSIZE
		);

		if(unWndVD != g_unCurVD && g_unCurVD == vdFromWindow(hWnd))
		{
			SendMessage(
				 GetLitestepWnd()
				,LM_VWMNOTIFYCHANGE
				,(WPARAM)g_unCurVD
				,(LPARAM)0
			);
		}
	}

	return;
}

/*----------------------------------------------------------------------------*/
VOID freeOnXCmds( VOID )
{
	if(NULL != s_pszOnInit)
	{
		free(s_pszOnInit);
		s_pszOnInit = NULL;
	}

	if(NULL != s_pszOnQuit)
	{
		free(s_pszOnQuit);
		s_pszOnQuit = NULL;
	}

	if(NULL != s_pszOnDesktopUpdate)
	{
		free(s_pszOnDesktopUpdate);
		s_pszOnDesktopUpdate = NULL;
	}

	return;
}

/*----------------------------------------------------------------------------*/
VOID readOnXCmds( VOID )
{
	_TCHAR buffer[4096];

	freeOnXCmds();

	*buffer = 0;
	GetRCLine( _T("bVWMOnInit"), buffer, 4096, _T("") );

	if(0 != *buffer)
	{
		s_pszOnInit = (LPTSTR)malloc((_tcslen(buffer) + 1) * sizeof(_TCHAR));

		if(NULL != s_pszOnInit)
		{
			_tcscpy(s_pszOnInit, buffer);
		}
	}

	*buffer = 0;
	GetRCLine( _T("bVWMOnQuit"), buffer, 4096, _T("") );

	if(0 != *buffer)
	{
		s_pszOnQuit = (LPTSTR)malloc((_tcslen(buffer) + 1) * sizeof(_TCHAR));

		if(NULL != s_pszOnQuit)
		{
			_tcscpy(s_pszOnQuit, buffer);
		}
	}

	*buffer = 0;
	GetRCLine( _T("bVWMOnDesktopUpdate"), buffer, 4096, _T("") );

	if(0 != *buffer)
	{
		s_pszOnDesktopUpdate = (LPTSTR)malloc(
			(_tcslen(buffer) + 1) * sizeof(_TCHAR)
		);

		if(NULL != s_pszOnDesktopUpdate)
		{
			_tcscpy(s_pszOnDesktopUpdate, buffer);
		}
	}

	return;
}

/*----------------------------------------------------------------------------*/
VOID freeCommands( VOID )
{
	if(NULL != s_pCmdList)
	{
		UINT i;

		for(i = 0; i < g_unVDesks; i++)
		{
			if(NULL != s_pCmdList[i])
			{
				free(s_pCmdList[i]);
			}
		}

		free(s_pCmdList);
		s_pCmdList = NULL;
	}

	return;
}

/*----------------------------------------------------------------------------*/
VOID readCommands( VOID )
{
	LPTSTR tokens[2];
	_TCHAR buffer[4096];
	_TCHAR token[128];
	_TCHAR cmd[4096];
	LPVOID fLCHandle;
	INT nCount;

	fLCHandle = LCOpen(NULL);

	if(NULL == fLCHandle)
	{
		return;
	}

	freeCommands();

	tokens[0] = token;
	tokens[1] = token;

	while(LCReadNextConfig(fLCHandle, _T("*bVWMExec"), buffer, 4096))
	{
		*cmd = 0;
		nCount = LCTokenize(buffer, tokens, 2, cmd);

		if(nCount >= 2 && 0 != *cmd)
		{
			nCount = _ttoi(tokens[1]);

			if(!VD_ISVALID(nCount))
			{
				continue;
			}

			if(NULL == s_pCmdList)
			{
				s_pCmdList = (LPTSTR*)calloc(g_unVDesks, sizeof(LPTSTR));
			}

			if(NULL != s_pCmdList && NULL == s_pCmdList[nCount])
			{
				s_pCmdList[nCount] = (LPTSTR)malloc(
					(_tcslen(cmd) + 1) * sizeof(_TCHAR)
				);

				if(NULL != s_pCmdList[nCount])
				{
					_tcscpy(s_pCmdList[nCount], cmd);
				}
			}
		}
	}

	LCClose(fLCHandle);

	return;
}

/*----------------------------------------------------------------------------*/
VOID freeSticky( VOID )
{
	PSTICKYITEM pNext;

	while(NULL != s_pStickyList)
	{
		pNext = s_pStickyList->pNext;
		free(s_pStickyList);
		s_pStickyList = pNext;
	}

	return;
}

/*----------------------------------------------------------------------------*/
VOID readSticky( VOID )
{
	PSTICKYITEM pItem, pLast;
	LPTSTR tokens[3];
	_TCHAR buffer[4096];
	_TCHAR szTitle[256];
	_TCHAR szClass[256];
	LPVOID fLCHandle;
	INT nCount;

	fLCHandle = LCOpen(NULL);

	if(NULL == fLCHandle)
	{
		return;
	}

	freeSticky();
	/* Not necessary, but gets rid of compiler warning */
	pLast = NULL;

	tokens[0] = szClass;
	tokens[1] = szClass;
	tokens[2] = szTitle;

	while(LCReadNextConfig(fLCHandle, _T("*bVWMSticky"), buffer, 4096))
	{
		nCount = LCTokenize(buffer, tokens, 3, NULL);

		if(nCount >= 2)
		{
			pItem = malloc(sizeof(STICKYITEM));
			memset(pItem, 0, sizeof(STICKYITEM));

			_tcsncpy(pItem->szClass, szClass, 256);
			pItem->szClass[255] = 0;

			if(nCount > 2)
			{
				_tcsncpy(pItem->szTitle, szTitle, 256);
				pItem->szTitle[255] = 0;
			}
			else
			{
				_tcscpy(pItem->szTitle, _T("*"));
			}

			if(NULL == s_pStickyList)
			{
				pLast = s_pStickyList = pItem;
			}
			else
			{
				while(NULL != pLast->pNext)
				{
					pLast = pLast->pNext;
				}

				pLast = pLast->pNext = pItem;
			}
		}
	}

	LCClose(fLCHandle);

	return;
}

/*----------------------------------------------------------------------------*/
VOID setNumDesks( UINT const unVDesks )
{
	g_unVDesks = (VD_MINCOUNT > unVDesks) ? VD_MINCOUNT : unVDesks;

	freeCommands();
	readCommands();

	/* Call gather command for windows outside of new space */
	gatherLostToVD(VD_ISVALID(g_unCurVD) ? g_unCurVD : VD_LAST);

	return;
}

/*----------------------------------------------------------------------------*/
VOID initVDSize( VOID )
{
	RECT r;

	//s_nDTWidth = GetSystemMetrics(SM_CXSCREEN);
	//s_nDTHeight = GetSystemMetrics(SM_CYSCREEN);

	GetWindowRect(GetDesktopWindow(), &r);

	s_nDTWidth = s_nWAWidth = r.right - r.left;
	s_nDTHeight = s_nWAHeight = r.bottom - r.top;

	CopyRect(&s_DTRect, &r);
	CopyRect(&s_WARect, &r);

	if(SystemParametersInfo(SPI_GETWORKAREA, 0, &r, 0))
	{
		s_nWAWidth = r.right - r.left;
		s_nWAHeight = r.bottom - r.top;

		CopyRect(&s_WARect, &r);
	}

	return;
}

/*----------------------------------------------------------------------------*/
VOID loadSettings( VOID )
{
	fpSwitchToThisWindow = (FUNC_VOID__HWND_BOOL)GetProcAddress(
		 GetModuleHandle(_T("USER32"))
		,"SwitchToThisWindow"
	);

	fpGetTitleBarInfo = (FUNC_BOOL__HWND_PTITLEBARINFO)GetProcAddress(
		 GetModuleHandle(_T("USER32"))
		,"GetTitleBarInfo"
	);

	fpGetWindowInfo = (FUNC_BOOL__HWND_PWINDOWINFO)GetProcAddress(
		 GetModuleHandle(_T("USER32"))
		,"GetWindowInfo"
	);

	initVDSize();

	g_bFocusLast = (BOOL)GetRCBool(_T("bVWMFocusLast"), TRUE);
	g_bSwitchOnFocus = (BOOL)GetRCBool(_T("bVWMSwitchOnFocus"), TRUE);
	s_bKeepMaximized = (BOOL)GetRCBool(_T("bVWMKeepMaximized"), TRUE);
	s_bStrictGather = GetRCBool(_T("bVWMStrictGather"), TRUE);
	s_bNoWindowReposition = GetRCBool(_T("bVWMNoWindowReposition"), TRUE);
	s_bVertical = GetRCBool(_T("bVWMVertical"), TRUE);
	g_bIgnoreDesktopUpdate = GetRCBool(_T("bVWMIgnoreDesktopUpdate"), TRUE);
	g_bAllowControl = GetRCBool(_T("bVWMAllowModuleControl"), TRUE);
	s_nDTSpacing = VD_MINSPACE;// GetRCInt(_T("bVWMSpacing"), VD_MINSPACE);

	setNumDesks((UINT)GetRCInt(_T("bVWMDesks"), VD_MINCOUNT));

	//readCommands(); <- done above in setNumDesks()
	readSticky();
	readOnXCmds();

	return;
}

/*----------------------------------------------------------------------------*/
VOID unloadSettings( VOID )
{
	freeOnXCmds();
	freeSticky();
	freeCommands();

	return;
}

/*----------------------------------------------------------------------------*/
VOID onInit( VOID )
{
	if(NULL != s_pszOnInit)
	{
		LSExecute(NULL, s_pszOnInit, 0);
	}

	return;
}

/*----------------------------------------------------------------------------*/
VOID onQuit( VOID )
{
	if(NULL != s_pszOnQuit)
	{
		LSExecute(NULL, s_pszOnQuit, 0);
	}
	else /* Default quit command */
	{
		switchToVD(0);
	}

	return;
}

/*----------------------------------------------------------------------------*/
VOID onDesktopUpdate( VOID )
{
	if(NULL != s_pszOnDesktopUpdate)
	{
		LSExecute(NULL, s_pszOnDesktopUpdate, 0);
	}

	return;
}

/*----------------------------------------------------------------------------*/
