===================================================
===================================================
=================== Date & Time ===================
===================================================
== datetime.exe - a win32 local and iTime clock ===
===================================================
===================================================
====== Written by: ================================
================== Chris Rempel (jugg) ============
===================================================
================== http://aster.omega2.com/jugg/ ==
===================================================
===================================================
== Version: 1.00 = Release Date: 06.08.99 =========
===================================================
===================================================


-=ToC=-
I. Introduction
II. Installation
III. Information
IV. Tips & Tricks
V. Disclaimer


=====================
== I. Introduction ==
=====================
===================================================
Welcome, and thank you for deciding to try out this
highly customizable win32 clock. It offers features
such as the popular iTime (internet time) and date,
as well as toggling your display to local time with
the ability to synchronize your system clock from
NTP servers. This keeps you on time and in touch.


=====================
== II. Istallation ==
=====================
===================================================
If you are reading this, you have probably already
gotten Date & Time installed. If not, you will need
to download the installer, which is available from
http://aster.omega2.com/jugg/software/datetime/

When the download is complete, just extract the
dtinstal.zip to a temporary directory and run the
setup.exe and follow the on screen instructions.

If you downloaded the datetime.zip which does not
contain all of the necessary libraries to run Date
& Time, you will need to make sure you have the
necessary files already on your computer. If you
do, then simply extract the datetime.exe file to a
directory of your choice, and create a shortcut
link to it on your desktop.

======================
== III. Information ==
======================
===================================================
General use of Date & Time consists of simple point
and click of the mouse. A left-click-drag will drag
the clock display around the screen, if the option
is not disabled in the Settings box. (Tip: to dock
it to the side of the screen, drag it passed the
visible edge of the desktop and release. It will
snap back to the edge of the screen) A right-click
will open up the clocks menu from which you will
have several different quick options to toggle the
display of your clock. For more in-depth
configuration, choose the "Settings" option from
the menu.

Date & Time is very customizable. To start with you
can create multiple configuration files for
different looks, and switch between them on the
fly. Date&Time stores the path and file name to the
current configuration file inside of an INI file
named "datetime.ini" located in the same directory
as datetime.exe. The contents of "datetime.ini"
looks like the following.

[DateTime]
iniPath=C:\Program Files\DateTime\
iniFile=settings.ini

While those settings can be changed from within
the program itself, I give them to you for a 
reference for whatever reason you may need.

Now, Date&Time reads its actual configuration
settings from whatever INI file is specified in the
above line "iniFile=settings.ini" and defaults to
"settings.ini" if there is not one specified. The
following is a complete list of commands used in
"settings.ini". While it seems a little cryptic,
that is because it was not designed to be hand
edited, but instead modified through the built in
configuration dialog. The following settings are
not guarenteed to work, and are not meant to be
used, but are only placed here for reference of the
configuration commands.

[Layout]
txtClkWidth=75
txtClkHeight=19
txtClkXPos=400
txtClkYPos=0
txtClkBorder=1

[Settings]
chkDateDisplay=0
chkDateDay=1
chkDateMonth=1
chkDateYear=1
chkTimeDisplay=1
chkTimeSeconds=1
chkTimeMinutes=1
chkTimeHours=1
lblDateLS0=0
lblDateLS1=0
lblDateLS2=0
chkClkDragging=1
chkClkAutoSize=0
txtBMTTime=-8

[Cosmetics]
lblTextAlign=2
lblDTOrder=0
lblBGColor=0
lblBdrColor=5127726
lblTextColor=8480848
lblTextFontName=MS Serif
lblTextFontBold=True
lblTextFontItalic=False
lblTextFontSize=12
imgBGImage=C:\Images\d&tskin.bmp

[Popups]
mnu12Hour=False
mnu24Hour=True
mnuAlwaysOnTop=True
mnuAlwaysOnBottom=False
mnuAltDate=True
mnuiTime=False
mnuUSDate=False
mnuSaveOnExit=False

[NTPSetup]
txtNTPServer=tick.ucla.edu
txtNTPPort=13
txtMaxDelta=3600
chkMaxDeltaWarn=1
chkClockSetNotify=1
chkSetDate=1
chkSetTime=1

It is entirely possible that if an invalid setting
is specified when manually configuring the settings
in this file, that it will cause Date&Time to crash
so do so at your own risk. However, if you use the
built in configuration dialog, you will not have
that problem.

You may not sell this program. You may not
distribute it on any media forum for any price,
regardless if it is only for the cost of media it
was distributed on. This program has been created
and released for free, and any distrobution of it
must be equally free.


=======================
== IV. Tips & Tricks ==
=======================
===================================================
To dock the clock display to the side of the screen
drag the clock passed the edge, and release it. It
then will automatically snap back flush with the
edge of the screen.

When specifying a background image, and you want to
center the clock display in the image, use the
Border Size in the Settings dialog, to move the
clock display around inside of the background
image. You can do the same without an image, but
would need to specify the same color for the border
as the background.

Make sure that your NTP Setup dialog points to a
server that is in your TimeZone. Otherwise it will
not correctly synchronize your local time. Also,
you need to check the BMT Time item in the Settings
dialog, to make sure it correctly specifies the
number of hours difference from the BMT Time Line.
The default setting "-8" is set for PDT (Pacific
Daylight Time) in the USA.

UnCheck both the "Always On Bottom" and "Always On
Top" items in the menu to have the clock act like
a normal window, being able to go both above and
below other applications.

If you change your settings often, and want them
to save whenever you exit the program, or reboot
your computer, check the "Save On Exit" option in
the menu. This will then automatically save any
changes when the program exits.

If you want to load the default settings, from the
Settings dialog, click on the "Load" button, and go
to the directory where you want the new INI file to
be created that will hold the new settings. Right
click and create a new text document, then rename
it to whatever you want. (mysetup.ini). Click the
"Open" button, and you can now either exit and 
reload the clock for the default settings to appear
or create your own new setup to save in this new
configuration file.


===================
== V. Disclaimer ==
===================
===================================================
Copyright (C) 1999, Chris Rempel

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT  WARRANTY
OF ANY KIND, EXPRESS OR  IMPLIED, INCLUDING BUT NOT
LIMITED  TO  THE   WARRANTIES  OF  MERCHANTABILITY,
FITNESS  FOR   A   PARTICULAR   PURPOSE   AND  NON-
INFRINGEMENT.  IN  NO  EVENT  SHALL THE  AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,  DAMAGES
OR  OTHER  LIABILITY,   WHETHER  IN  AN  ACTION  OF
CONTRACT,  TORT OR OTHERWISE,  ARISING FROM, OUT OF
OR IN CONNECTION  WITH  THE  SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.
