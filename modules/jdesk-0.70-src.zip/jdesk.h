#ifndef __JDESK_H
#define __JDESK_H

#define WM_MOUSEWHEEL 0x020A
#define WM_XBUTTONDOWN 0x020B
#define WM_XBUTTONUP 0x020C
#define WM_XBUTTONDBLCLK 0x020D

#define MK_XBUTTON1 0x0020
#define MK_XBUTTON2 0x0040
#define XBUTTON1 0x0001
#define XBUTTON2 0x0002

const int MAXLEN = 256;

struct jDeskSettings
{
	BOOL DisableDoubleClick, DisableMButton1, DisableMButton2, DisableMButton3, DisableMButtonX1, DisableMButtonX2, DisableMWheelScroll;
	BOOL ClearWorkAreaOnExit, RecycleOnRezChange, WorkArea;
	UINT DoubleClickTime;
	char DesktopFolder[MAX_PATH];
};

struct MDataList
{
	char *modKey;
	char *actionDown;
	char *actionUp;
	char *actionDblClk;
};

struct MBClickVal
{
	WPARAM wp;
	char dblclk;
};

#ifdef __cplusplus
extern "C" {
#endif

__declspec( dllexport ) int initModuleEx( HWND, HINSTANCE, LPCSTR );
__declspec( dllexport ) void quitModule( HINSTANCE );

#ifdef __cplusplus
}
#endif

#endif
