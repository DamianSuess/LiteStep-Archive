#include <tchar.h>
#include <windows.h>
#include <stdlib.h>
#include "../../litestep/lsapi/lsapi.h"
#include "jkey.h"

LPCTSTR szAppClass = _T("jKeyClass"); // Class Name
LPCTSTR szAppName = _T(""); // Window Name

LPCTSTR aboutStr = _T("jKey 0.36 (jugg)");

LRESULT CALLBACK WndProc( HWND, UINT, WPARAM, LPARAM );
VOID loadjKeys( VOID );
VOID loadVKTable( LPTSTR );
VOID freejKeys( VOID );
VOID freeVKTable( VOID );
BOOL stripWS ( LPTSTR );
BOOL isKeyInList( ATOM );
UINT getKeyById( ATOM );

HWND hMainWnd;
HWND hParentWnd;

ATOM LWinKey;
ATOM RWinKey;

UINT numvKeys;
UINT numjKeys;

tVKTable *vkTable;
jKeyType *jkeys;
jkSettings jks;

INT initModuleEx( HWND parent, HINSTANCE dllInst, LPCTSTR szPath )
{
	szPath=szPath;
	hParentWnd = parent;

	{	// Register the jKey window class
		WNDCLASS wc;
		memset(&wc, 0, sizeof(wc));
		wc.lpfnWndProc = (WNDPROC)WndProc;
		wc.hInstance = dllInst;
		wc.lpszClassName = szAppClass;
		if (!RegisterClass(&wc)){
			ERRORBOX(_T("Error registering jKey window class"));
			return 1;
		}
	}

		// Create jKey window
	hMainWnd = CreateWindowEx(WS_EX_TOOLWINDOW,szAppClass,szAppName,WS_CHILD,0,0,0,0,hParentWnd,NULL,dllInst,NULL);
	if (hMainWnd == NULL){
		ERRORBOX(_T("Error creating jKey window!"));
		UnregisterClass(szAppName, dllInst);
		return 1;
	}

		// Get jKey settings
	jks.bNoWarn = GetRCBool(_T("jKeyNoWarn"),TRUE);
	jks.bUseHotkeyDef = GetRCBool(_T("jKeyUseHotkeyDef"),TRUE);
	jks.nLWinKeyTimeout = (UINT)abs(GetRCInt(_T("jKeyLWinKeyTimeout"), 750));
	jks.nRWinKeyTimeout = (UINT)abs(GetRCInt(_T("jKeyRWinKeyTimeout"), 750));

	{	// Load extended key items
		_TCHAR tmp[4096];

		*tmp = 0;
		GetRCString(_T("jKeyVKTable"), tmp, _T(""), _MAX_PATH);
		if (*tmp)
			loadVKTable(tmp);

		*tmp = 0;
		GetRCLine(_T("jKeyLWinKey"), tmp, 4096, _T(""));
		if (*tmp){
			jks.pLWinKey = (LPTSTR)malloc((_tcslen(tmp)+1)*sizeof(_TCHAR));
			if (jks.pLWinKey != NULL){
				_tcscpy(jks.pLWinKey, tmp);
				if ((LWinKey=GlobalAddAtom(_T("LWIN_KEY"))) != 0){
					if (!RegisterHotKey(hMainWnd, LWinKey, MOD_WIN, VK_LWIN)){
						GlobalDeleteAtom(LWinKey);
						LWinKey = 0;
					}
				}
			}
			if (LWinKey == 0){
				if (jks.pLWinKey != NULL){
					free(jks.pLWinKey);
					jks.pLWinKey = NULL;
				}
				if(!jks.bNoWarn)
					ERRORBOX(_T("Error registering Left WinKey!"));
			}
		}else
			jks.pLWinKey = NULL;

		*tmp = 0;
		GetRCLine(_T("jKeyRWinKey"), tmp, 4096, _T(""));
		if (*tmp){
			jks.pRWinKey = (LPTSTR)malloc((_tcslen(tmp)+1)*sizeof(_TCHAR));
			if (jks.pRWinKey != NULL){
				_tcscpy(jks.pRWinKey, tmp);
				if ((RWinKey=GlobalAddAtom(_T("RWIN_KEY"))) != 0){
					if (!RegisterHotKey(hMainWnd, RWinKey, MOD_WIN, VK_RWIN)){
						GlobalDeleteAtom(RWinKey);
						RWinKey = 0;
					}
				}
			}
			if (RWinKey == 0){
				if (jks.pRWinKey != NULL){
					free(jks.pRWinKey);
					jks.pRWinKey = NULL;
				}
				if(!jks.bNoWarn)
					ERRORBOX(_T("Error registering Right WinKey!"));
			}
		}else
			jks.pRWinKey = NULL;
	}

		// Get jKey definitions
	loadjKeys();

	{	//register message for version info
		UINT Msgs[] = {LM_GETREVID, 0};
		SendMessage(hParentWnd, LM_REGISTERMESSAGE, (WPARAM)hMainWnd, (LPARAM)Msgs);
	}
	return 0;
}

VOID quitModule( HINSTANCE dllInst )
{

	{	//unregister message for version info
		UINT Msgs[] = {LM_GETREVID, 0};
		SendMessage(hParentWnd, LM_UNREGISTERMESSAGE, (WPARAM)hMainWnd, (LPARAM)Msgs);
	}

	if (LWinKey){
		KillTimer(hMainWnd, 1);
		UnregisterHotKey(hMainWnd, LWinKey);
		DeleteAtom(LWinKey);
		LWinKey = 0;
	}
	if (jks.pLWinKey != NULL){
		free(jks.pLWinKey);
		jks.pLWinKey = NULL;
	}

	if (RWinKey){
		KillTimer(hMainWnd, 2);
		UnregisterHotKey(hMainWnd, RWinKey);
		DeleteAtom(RWinKey);
		RWinKey = 0;
	}
	if (jks.pRWinKey != NULL){
		free(jks.pRWinKey);
		jks.pRWinKey = NULL;
	}

	freejKeys();
	freeVKTable();

	if (hMainWnd != NULL)
		DestroyWindow(hMainWnd);

	UnregisterClass(szAppClass, dllInst);
	return;
}

LRESULT CALLBACK WndProc( HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam )
{
	switch (message){
		case LM_GETREVID:
			_tcscpy((LPTSTR)lParam, aboutStr);
			return _tcslen((LPTSTR)lParam);

		case WM_CLOSE:
			return 0;

		case WM_SYSCOMMAND:
			switch (wParam){
				case SC_CLOSE:
					PostMessage(hParentWnd, LM_RECYCLE, 3, 0);
					return 0;
				default:
					break;
			}
			break;

		case WM_DESTROY:
			hMainWnd = NULL;
			return 0;

		case WM_HOTKEY:
			if (isKeyInList((ATOM)wParam)){
				if (LWinKey)
					KillTimer(hMainWnd, 1);
				if (RWinKey)
					KillTimer(hMainWnd, 2);
				LSExecute(hMainWnd, jkeys[getKeyById((ATOM)wParam)].cmd, 0);
			}
			else if (LWinKey && (ATOM)wParam == LWinKey)
				SetTimer(hMainWnd, 1, jks.nLWinKeyTimeout, (TIMERPROC)NULL);
			else if (RWinKey && (ATOM)wParam == RWinKey)
				SetTimer(hMainWnd, 2, jks.nRWinKeyTimeout, (TIMERPROC)NULL);
			break;

		case WM_TIMER:
			if (wParam == 1){
				KillTimer(hMainWnd, 1);
				LSExecute(hMainWnd, jks.pLWinKey, 0);
			}
			else if (wParam == 2){
				KillTimer(hMainWnd, 2);
				LSExecute(hMainWnd, jks.pRWinKey, 0);
			}
			return 0;

		default:
			break;
	}
	return DefWindowProc(hwnd,message,wParam,lParam);
}

VOID loadjKeys()
{
	FILE *f = LCOpen(NULL);
	if (f){
		_TCHAR buffer[4096];
		_TCHAR token0[128], token1[128], token2[128], cmdstr[4096];
		_TCHAR idstr[13];
		LPTSTR tokens[3];
		UINT count;
		BOOL error;
		jKeyType tmpjKey;

		tokens[0] = token0;
		tokens[1] = token1;
		tokens[2] = token2;

		*buffer = 0;
		while (LCReadNextConfig(f, jks.bUseHotkeyDef ? _T("*HotKey"):_T("*jKey"), buffer, 4096)){
			*token0 = *token1 = *token2 = 0;
			*cmdstr = 0;
			*idstr = 0;
			count = 0;
			error = FALSE;

			if ((count = LCTokenize(buffer, tokens, 3, cmdstr)) != 3 || *cmdstr == 0)
				error = TRUE;
			else if (!(stripWS(token1) && stripWS(token2) && stripWS(cmdstr)))
				error = TRUE;
			
			if (error){
				if (!jks.bNoWarn){
					_stprintf(cmdstr, _T("Invalid format. Contains too few (or empty) parameters.\n\nError in definition:\n%s"), buffer);
					ERRORBOX(cmdstr);
				}
				continue;
			}

			memset(&tmpjKey, 0, sizeof(jKeyType));

			tokens[1] = _tcstok(token1, _T("+"));
			while (!error && tokens[1] != NULL){
				if (!_tcsicmp(tokens[1], _T("win")))
					tmpjKey.modkey |= MOD_WIN;
				else if (!_tcsicmp(tokens[1], _T("ctrl")))
					tmpjKey.modkey |= MOD_CONTROL;
				else if (!_tcsicmp(tokens[1], _T("alt")))
					tmpjKey.modkey |= MOD_ALT;
				else if (!_tcsicmp(tokens[1], _T("shift")))
					tmpjKey.modkey |= MOD_SHIFT;
				else{
					if (!jks.bNoWarn){
						_stprintf(cmdstr, _T("Invalid <modkey> parameter: %s\n\nError in definition:\n%s"), tokens[1], buffer);
						ERRORBOX(cmdstr);
					}
					error = TRUE;
					continue;
				}
				tokens[1] = _tcstok(NULL, _T("+"));
			}
			tokens[1] = token1; // move pointer back to beginning of token1

			if (error)
				continue;

			if (_tcslen(token2) == 1){
				tmpjKey.ckey = (0x000000FF & VkKeyScan(*token2));
				if (tmpjKey.ckey == 0xFF) /* Error occured */
					tmpjKey.ckey = 0;
			}else{
				for (count=0; count<numvKeys && !tmpjKey.ckey; count++){
					if (!_tcsicmp(vkTable[count].key, token2))
						tmpjKey.ckey = vkTable[count].vkey;
				}
			}

			if (!tmpjKey.ckey){
				if (!jks.bNoWarn){
					_stprintf(cmdstr, _T("Invalid <hotkey> - \"%s\"\n\nError in definition:\n%s"), token2, buffer);
					ERRORBOX(cmdstr);
				}
				continue;
			}

			_stprintf(idstr, _T("JKEY%08X"), numjKeys);
			tmpjKey.id = GlobalAddAtom( idstr );
			if (!tmpjKey.id){
				if (!jks.bNoWarn){
					_stprintf(cmdstr, _T("Hotkey resource allocation failed.\n\nError while processing definition:\n%s"), buffer);
					ERRORBOX(cmdstr);
				}
				continue;
			}

			tmpjKey.cmd = (LPTSTR)malloc((_tcslen(cmdstr)+1)*sizeof(_TCHAR));
			if (tmpjKey.cmd != NULL){
				_tcscpy(tmpjKey.cmd, cmdstr);

				if (!RegisterHotKey(hMainWnd,tmpjKey.id,tmpjKey.modkey,tmpjKey.ckey)){
					GlobalDeleteAtom(tmpjKey.id);
					free(tmpjKey.cmd);
					if (!jks.bNoWarn){
						_stprintf(cmdstr, _T("Hotkey failed to register.\n\nError while processing definition:\n%s"), buffer);
						ERRORBOX(cmdstr);
					}
				}else{
					jKeyType * tempKeys = jkeys;
					if (!jkeys)
						jkeys = (jKeyType *)malloc(sizeof(jKeyType));
					else
						jkeys = (jKeyType *)realloc(jkeys, (numjKeys+1)*sizeof(jKeyType));
					if (jkeys == NULL){
						jkeys = tempKeys;
						free(tmpjKey.cmd);
						UnregisterHotKey(hMainWnd, tmpjKey.id);
						GlobalDeleteAtom(tmpjKey.id);
						if (!jks.bNoWarn){
							_stprintf(cmdstr, _T("Hotkey resource allocation failed.\n\nError while processing definition:\n%s"), buffer);
							ERRORBOX(cmdstr);
						}
					}else{
						memcpy(&jkeys[numjKeys], &tmpjKey, sizeof(jKeyType));
						++numjKeys;
					}
					tempKeys = NULL;
				}
			}
			*buffer = 0;
		}
		LCClose(f);
	}
	return;
}

VOID loadVKTable( LPTSTR table )
{
	FILE *f;
	tVKTable tmpTable;
	_TCHAR tmpBuf[128];
	_TCHAR tBuf[128];
	UINT nKey;

	f = _tfopen(table, _T("r"));
	if (f != NULL)
		fseek(f, 0, SEEK_SET);
	else
		return;

	numvKeys = 0;
	while (f && !ferror(f) && !feof(f)){
		if (!_fgetts(tmpBuf, 128, f))
			continue;
		if (stripWS(_tcsupr(tmpBuf)) && *tmpBuf != _T(';')){
			*tBuf = 0;
			nKey = 0;
			if (_stscanf(tmpBuf, _T("%s , %08X"), tBuf, &nKey)){
				if (*tBuf != 0 && nKey != 0){
					memset(&tmpTable, 0, sizeof(tVKTable));
					tmpTable.key = (LPTSTR)malloc((_tcslen(tBuf)+1)*sizeof(_TCHAR));
					if (tmpTable.key != NULL){
						tVKTable * tempVKT = vkTable;

						_tcscpy(tmpTable.key, tBuf);
						tmpTable.vkey = nKey;

						if (!vkTable)
							vkTable = (tVKTable *)malloc(sizeof(tVKTable));
						else
							vkTable = (tVKTable *)realloc(vkTable, (numvKeys+1)*sizeof(tVKTable));
						if (vkTable == NULL){
							vkTable = tempVKT;
							free (tmpTable.key);
							tmpTable.key = NULL;
						}else{
							memcpy(&vkTable[numvKeys], &tmpTable, sizeof(tVKTable));
							++numvKeys;
						}
					}
				}
			}
		}
	}
	fclose(f);
	return;
}

VOID freejKeys()
{
	UINT i;
	for (i=0;i<numjKeys;i++){
		UnregisterHotKey(hMainWnd,jkeys[i].id);
		GlobalDeleteAtom(jkeys[i].id);
		jkeys[i].id = 0;
		if (jkeys[i].cmd != NULL){
			free(jkeys[i].cmd);
			jkeys[i].cmd = NULL;
		}
	}
	if (jkeys != NULL){
		free(jkeys);
		jkeys = NULL;
	}
	numjKeys = 0;
	return;
}

VOID freeVKTable( VOID ){
	UINT i;
	for (i=0;i<numvKeys;i++){
		free(vkTable[i].key);
		vkTable[i].key = NULL;
	}
	if (vkTable != NULL){
		free(vkTable);
		vkTable = NULL;
	}
	return;
}

BOOL stripWS ( LPTSTR buffer )
{
	size_t length = buffer != NULL ? _tcslen(buffer):0;
	if (length){
		LPTSTR tmpBuf = buffer;
		while (length && _istspace(*tmpBuf)) {++tmpBuf; --length;}
		if (length){
			while (length && _istspace(tmpBuf[length-1]))
				tmpBuf[--length] = 0;
			if (tmpBuf != buffer)
				_tcscpy(buffer, tmpBuf);
		}
	}
	return (length != 0);
}

BOOL isKeyInList( ATOM id )
{
	UINT i;

	for (i=0;i<numjKeys;i++)
		if (jkeys[i].id == id)
			return TRUE;

	return FALSE;
}

UINT getKeyById( ATOM id )
{
	UINT i;

	for (i=0;i<numjKeys;i++)
		if (jkeys[i].id == id)
			return i;

	return i;
}