#ifndef __JKEY_H
#define __JKEY_H

#define ERRORBOX(x) MessageBox(NULL,x,_T("jKey"),MB_OK|MB_ICONERROR|MB_DEFBUTTON1|MB_SYSTEMMODAL)

typedef struct{
	LPTSTR key;
	UINT vkey;
} tVKTable;

typedef struct{
	LPTSTR cmd;
	UINT ckey;
	UINT modkey;
	ATOM id;
} jKeyType;

typedef struct{
	BOOL bNoWarn;
	BOOL bUseHotkeyDef;
	LPTSTR pLWinKey, pRWinKey;
	_TINT nLWinKeyTimeout, nRWinKeyTimeout;
} jkSettings;

#ifdef __cplusplus
	extern "C" {
#endif

		__declspec( dllexport ) INT initModuleEx ( HWND, HINSTANCE, LPCTSTR );
		__declspec( dllexport ) VOID quitModule ( HINSTANCE );

#ifdef __cplusplus
	}
#endif

#endif /*__JKEY_H*/
