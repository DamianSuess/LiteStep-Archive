/*------------------------------------------------------------------------------
    This is part of the the source code for "systray"; a Litestep Module.
	As a whole it implements the "icon notification area".

    Copyright (C) 1999 - 2000 Kevin Schafer
    Copyright (C) 2001 - 2004 Chris Rempel

    This program is free software; you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the Free
    Software Foundation; either version 2 of the License, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
    more details.

    You should have received a copy of the GNU General Public License along with
    this program; if not, write to the Free Software Foundation, Inc.,
    59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
------------------------------------------------------------------------------*/

////
/// system tray bang commands
//
#include <tchar.h>
#include <windows.h>

#include "systray.h"

void SystrayHide( HWND hCaller, LPCSTR pszArgs )
{
	ShowWindow( g_hMainWnd, SW_HIDE );
	stCfg.fVisible = FALSE;

	UNREFERENCED_PARAMETER(hCaller);
	UNREFERENCED_PARAMETER(pszArgs);
}

void SystrayMove( HWND hCaller, LPCSTR pszArgs )
{
	LPCTSTR p = pszArgs;
	TCHAR szValue[16];

	p = NextToken( p, szValue, 16 );
	stCfg.nX = ParseInteger( szValue );
	stCfg.nX = (stCfg.nX < 0) ? (stCfg.nScreenCX + stCfg.nX + 1) : stCfg.nX;

	p = NextToken( p, szValue, 16 );
	stCfg.nY = ParseInteger( szValue );
	stCfg.nY = (stCfg.nY < 0) ? (stCfg.nScreenCY + stCfg.nY + 1) : stCfg.nY;

	SetWindowPos( g_hMainWnd, NULL, stCfg.nX, stCfg.nY, 0, 0, SWP_NOSIZE |
		SWP_NOZORDER | SWP_NOACTIVATE );

	UNREFERENCED_PARAMETER(hCaller);
}

void SystrayShow( HWND hCaller, LPCSTR pszArgs )
{
	ShowWindow( g_hMainWnd, SW_SHOWNOACTIVATE );
	stCfg.fVisible = TRUE;

	UNREFERENCED_PARAMETER(hCaller);
	UNREFERENCED_PARAMETER(pszArgs);
}

void SystrayToggle( HWND hCaller, LPCSTR pszArgs )
{
	stCfg.fVisible = !stCfg.fVisible;
	ShowWindow( g_hMainWnd, stCfg.fVisible ? SW_SHOWNOACTIVATE : SW_HIDE );

	UNREFERENCED_PARAMETER(hCaller);
	UNREFERENCED_PARAMETER(pszArgs);
}

void SystrayPinToDesktop( HWND hCaller, LPCSTR pszArgs )
{
	LPCTSTR p = pszArgs;
	TCHAR szValue[8];

	p = NextToken( p, szValue, 8 );

	if( !lstrcmpi(_T("FALSE"), szValue) )
	{
		if( NULL != g_hParentWnd )
		{
			g_hParentWnd = NULL;
			SetParent(g_hMainWnd, g_hParentWnd);
			SetWindowLong(g_hMainWnd, GWL_STYLE, (GetWindowLong(g_hMainWnd, GWL_STYLE) &~ WS_CHILD)|WS_POPUP);
		}
	}
	else
	{
		g_hParentWnd = g_hDesktopWnd;
		SetWindowLong(g_hMainWnd, GWL_STYLE, (GetWindowLong(g_hMainWnd, GWL_STYLE) &~ WS_POPUP)|WS_CHILD);
		SetParent(g_hMainWnd, g_hParentWnd);
	}

	UNREFERENCED_PARAMETER(hCaller);
}

/*--End Of File---------------------------------------------------------------*/
