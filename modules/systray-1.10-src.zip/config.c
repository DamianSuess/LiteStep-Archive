/*------------------------------------------------------------------------------
    This is part of the the source code for "systray"; a Litestep Module.
	As a whole it implements the "icon notification area".

    Copyright (C) 1999 - 2000 Kevin Schafer
    Copyright (C) 2001 - 2004 Chris Rempel

    This program is free software; you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the Free
    Software Foundation; either version 2 of the License, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
    more details.

    You should have received a copy of the GNU General Public License along with
    this program; if not, write to the Free Software Foundation, Inc.,
    59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
------------------------------------------------------------------------------*/

////
/// system tray config functions
//
#include <tchar.h>
#include <windows.h>

#include "systray.h"

MAP mapDirection[] = {
	TEXT("left"),   DIR_LEFT,
	TEXT("up"),     DIR_UP,
	TEXT("right"),  DIR_RIGHT,
	TEXT("down"),   DIR_DOWN,
	NULL,           0
};

MAP mapLR[] = {
	TEXT("left"),   DIR_LEFT,
	TEXT("right"),  DIR_RIGHT,
	NULL,           0
};

MAP mapUD[] = {
	TEXT("up"),     DIR_UP,
	TEXT("down"),   DIR_DOWN,
	NULL,           0
};

//
// NextToken
//

LPCTSTR NextToken( LPCTSTR s, LPTSTR d, UINT m )
{
	while( *s && *s <= 32 )
	{
		s++;
	}

	if( *s == 34 )
	{
		s++;
		
		while( *s && *s != 34 && --m )
		{
			*d++ = *s++;
		}

		s++;
	}
	else
	{
		while( *s && *s > 32 && --m )
		{
			*d++ = *s++;
		}
	}

	*d = 0;
	return s;
}

//
// ParseInteger
//

int ParseInteger( LPCTSTR pszSource )
{
	int nValue = 0;
	BOOL fNegative = FALSE;

	while( *pszSource && *pszSource <= 32 )
	{
		pszSource++;
	}

	if( *pszSource && *pszSource == '-' )
	{
		fNegative = TRUE;
		pszSource++;
	}

	while( *pszSource && *pszSource >= '0' && *pszSource <= '9' )
	{
		nValue = (nValue * 10) + (*pszSource++ - '0');
	}

	return fNegative ? -nValue : nValue;
}

//
// MapName
//

UINT MapName( PMAP mapTable, LPCTSTR pszName, UINT uDefaultValue )
{
	PMAP map;

	for( map = mapTable; map->pszName; map++ )
	{
		if( !lstrcmpi( map->pszName, pszName ) )
		{
			return map->uValue;
		}
	}

	return uDefaultValue;
}

//
// GetConfigBoolean
//

BOOL GetConfigBoolean( LPCTSTR pszName )
{
	TCHAR szFullName[64];

	lstrcpy( szFullName, CFG_NAME );
	lstrcat( szFullName, pszName );

	return GetRCBool( szFullName, TRUE );
}

//
// GetConfigColor
//

COLORREF GetConfigColor( LPCTSTR pszName, COLORREF crDefault )
{
	TCHAR szFullName[64];

	lstrcpy( szFullName, CFG_NAME );
	lstrcat( szFullName, pszName );

	return GetRCColor( szFullName, crDefault );
}

//
// GetConfigInteger
//

int GetConfigInteger( LPCTSTR pszName, int nDefault, int nMin, int nMax )
{
	int nValue;
	TCHAR szFullName[64];

	lstrcpy( szFullName, CFG_NAME );
	lstrcat( szFullName, pszName );

	nValue = GetRCInt( szFullName, nDefault );
	nValue = max( nMin, min( nMax, nValue ) );

	return nValue;
}

//
// GetConfigString
//

void GetConfigString( LPCTSTR pszName, LPTSTR pszBuffer, UINT nBufLen, LPCTSTR pszDefault )
{
	TCHAR szFullName[64];

	lstrcpy( szFullName, CFG_NAME );
	lstrcat( szFullName, pszName );
	GetRCLine( szFullName, pszBuffer, nBufLen, pszDefault );

	return;
}

//
// FreeConfig
//

void FreeConfig( void )
{
	if( stCfg.hbmSkin )
	{
		DeleteObject(stCfg.hbmSkin);
		stCfg.hbmSkin = NULL;
	}

	if( stCfg.hbrBgColor )
	{
		DeleteObject(stCfg.hbrBgColor);
		stCfg.hbrBgColor = NULL;
	}

	return;
}

//
// ReadConfig
//

void ReadConfig( void )
{
	TCHAR szLine[MAX_PATH];
	TCHAR szBuffer[MAX_PATH];
	LPCTSTR p;
	BITMAP bm;
	int nDir1;
	int nDir2;

	stCfg.nScreenCX = GetSystemMetrics(SM_CXSCREEN);
	stCfg.nScreenCY = GetSystemMetrics(SM_CYSCREEN);

	stCfg.fAlwaysOnTop = GetConfigBoolean( CFG_ALWAYSONTOP );
	stCfg.fBorderDrag = GetConfigBoolean( CFG_BORDERDRAG );
	stCfg.fHidden = GetConfigBoolean( CFG_HIDDEN );
	stCfg.fNoTransparency = GetConfigBoolean( CFG_NOTRANSPARENCY );
	stCfg.fHideIfEmpty = GetConfigBoolean( CFG_HIDEIFEMPTY );
	stCfg.fShowInfoTips = GetConfigBoolean( CFG_SHOWINFOTIPS );

	stCfg.fIconEffects = GetConfigBoolean( CFG_ICONEFFECTS );
	stCfg.clrHue = GetConfigColor( CFG_HUECOLOR, RGB(128, 128, 128) );
	stCfg.nHueIntensity = GetConfigInteger( CFG_HUEINTENSITY, 128, 0, 255 );
	stCfg.nColorSaturation = GetConfigInteger( CFG_COLORSATURATION, 0, 0, 255 );

	if(0 == stCfg.nHueIntensity && 255 == stCfg.nColorSaturation)
	{
		/* If non of the effects are actually enabled, then disable creating custom icons */
		stCfg.fIconEffects = FALSE;
	}

	stCfg.hbrBgColor = CreateSolidBrush(GetConfigColor( CFG_BGCOLOR, RGB(255,255,255) ));

	GetConfigString( CFG_BITMAP, szLine, MAX_PATH, TEXT("") );

	if( szLine[0] )
	{
		p = NextToken( szLine, szBuffer, MAX_PATH );
		stCfg.hbmSkin = LoadBitmapFile( szBuffer );

		if( stCfg.hbmSkin )
		{
			GetObject( stCfg.hbmSkin, sizeof(BITMAP), &bm );
			stCfg.nBitmapX = bm.bmWidth;
			stCfg.nBitmapY = bm.bmHeight;
		}

		p = NextToken( p, szBuffer, MAX_PATH );
		stCfg.nBorderLeft = ParseInteger( szBuffer );

		p = NextToken( p, szBuffer, MAX_PATH );
		stCfg.nBorderTop = ParseInteger( szBuffer );

		p = NextToken( p, szBuffer, MAX_PATH );
		stCfg.nBorderRight = ParseInteger( szBuffer );

		p = NextToken( p, szBuffer, MAX_PATH );
		stCfg.nBorderBottom = ParseInteger( szBuffer );

		p = NextToken( p, szBuffer, MAX_PATH );
		stCfg.fSkinTiled = (szBuffer[0] && !lstrcmpi( szBuffer, TEXT("tiled") )) ? TRUE : FALSE;
	}

	stCfg.nBorderX = GetConfigInteger( CFG_BORDERX, 0, 0, MAXLONG );
	stCfg.nBorderY = GetConfigInteger( CFG_BORDERY, 0, 0, MAXLONG );

	nDir1 = DIR_RIGHT;
	nDir2 = DIR_UP;

	GetConfigString( CFG_DIRECTION, szLine, MAX_PATH, TEXT("") );

	if( szLine[0] )
	{
		p = NextToken( szLine, szBuffer, MAX_PATH );
		nDir1 = MapName( mapDirection, szBuffer, DIR_RIGHT );
		
		p = NextToken( p, szBuffer, MAX_PATH );
		nDir2 = MapName( mapDirection, szBuffer, DIR_UP );
	}

	stCfg.nIconSize = GetConfigInteger( CFG_ICONSIZE, 16, 1, MAXLONG );

	stCfg.nX = GetConfigInteger( CFG_X, -1, MINLONG, MAXLONG );
	stCfg.nY = GetConfigInteger( CFG_Y, -1, MINLONG, MAXLONG );

	stCfg.nResizeH = DIR_RIGHT;
	stCfg.nResizeV = DIR_DOWN;

	GetConfigString( CFG_AUTOSIZE, szLine, MAX_PATH, TEXT("") );

	if( szLine[0] )
	{
		p = NextToken( szLine, szBuffer, MAX_PATH );
		stCfg.nResizeH = MapName( mapLR, szBuffer, DIR_RIGHT );
		
		p = NextToken( p, szBuffer, MAX_PATH );
		stCfg.nResizeV = MapName( mapUD, szBuffer, DIR_DOWN );
	}

	stCfg.nSnapDistance = GetConfigInteger( CFG_SNAPDISTANCE, 4, 0, MAXLONG );

	stCfg.nSpacingX = GetConfigInteger( CFG_SPACINGX, 2, 0, MAXLONG );
	stCfg.nSpacingY = GetConfigInteger( CFG_SPACINGY, 2, 0, MAXLONG );	

	stCfg.nWrapCount = GetConfigInteger( CFG_WRAPCOUNT, -1, -1, MAXLONG );

	stCfg.nMaxWidth = GetConfigInteger( CFG_MAXWIDTH, -1, -1, stCfg.nScreenCX );
	stCfg.nMaxHeight = GetConfigInteger( CFG_MAXHEIGHT, -1, -1, stCfg.nScreenCY );
	stCfg.nMinWidth = GetConfigInteger( CFG_MINWIDTH, -1, -1, stCfg.nScreenCX );
	stCfg.nMinHeight = GetConfigInteger( CFG_MINHEIGHT, -1, -1, stCfg.nScreenCY );

	stCfg.fHorizontal = ((nDir1 == DIR_LEFT) || (nDir1 == DIR_RIGHT)) ? TRUE : FALSE;

	if( stCfg.fHorizontal )
	{
		stCfg.nDeltaX = (nDir1 == DIR_LEFT) ? -1 : 1;
		stCfg.nDeltaY = (nDir2 == DIR_DOWN) ? 1 : -1;
	}
	else
	{
		stCfg.nDeltaX = (nDir2 == DIR_LEFT) ? -1 : 1;
		stCfg.nDeltaY = (nDir1 == DIR_DOWN) ? 1 : -1;
	}

	stCfg.nDeltaX *= stCfg.nIconSize + stCfg.nSpacingX;
	stCfg.nDeltaY *= stCfg.nIconSize + stCfg.nSpacingY;

	stCfg.nX = (stCfg.nX < 0) ? (stCfg.nScreenCX + stCfg.nX + 1) : stCfg.nX;
	stCfg.nY = (stCfg.nY < 0) ? (stCfg.nScreenCY + stCfg.nY + 1) : stCfg.nY;

	stCfg.nWrapCount = (stCfg.nWrapCount < 0) ? -1 : ((stCfg.nWrapCount == 0) ? 1 : stCfg.nWrapCount);

	if( NULL == g_hParentWnd && GetConfigBoolean(CFG_PINTODESKTOP) )
	{
		g_hParentWnd = g_hDesktopWnd;
	}

	if( g_bOnWharf )
	{
		RECT r;

		GetClientRect( g_hParentWnd, &r );

		stCfg.fAlwaysOnTop = FALSE;
		stCfg.fBorderDrag = FALSE;

		stCfg.nSnapDistance = 0;

		stCfg.nX = g_nWharfBevelWidth;
		stCfg.nY = g_nWharfBevelWidth;

		stCfg.nMinWidth = stCfg.nMaxWidth = r.right - r.left - (g_nWharfBevelWidth * 2);
		stCfg.nMinHeight = stCfg.nMaxHeight = r.bottom - r.top - (g_nWharfBevelWidth * 2);
	}

	return;
}

/*--End Of File---------------------------------------------------------------*/
