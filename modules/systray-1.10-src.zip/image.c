/*------------------------------------------------------------------------------
    This is part of the the source code for "systray"; a Litestep Module.
	As a whole it implements the "icon notification area".

    Copyright (C) 1999 - 2000 Kevin Schafer
    Copyright (C) 2001 - 2004 Chris Rempel

    This program is free software; you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the Free
    Software Foundation; either version 2 of the License, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
    more details.

    You should have received a copy of the GNU General Public License along with
    this program; if not, write to the Free Software Foundation, Inc.,
    59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
------------------------------------------------------------------------------*/

////
/// image routines
//
#include <tchar.h>
#include <windows.h>

#include "systray.h"

//
// LoadBitmapFile
//

HBITMAP LoadBitmapFile( LPCTSTR pszFile )
{
	return LoadLSImage( pszFile, NULL );
}

//
// TransBlt
//

BOOL TransBlt( HDC hdcDest, int xDest, int yDest, int cx, int cy, HDC hdcSrc, int xSrc, int ySrc, COLORREF clrTrans )
{
	HDC hdcMask;
	HBITMAP hbmMask;
	HDC hdcMem;
	HBITMAP hbmMem;
	COLORREF clrBack;
	COLORREF clrText;

	hdcMask = CreateCompatibleDC( hdcDest );
	hbmMask = CreateBitmap( cx, cy, 1, 1, NULL );
	hbmMask = (HBITMAP) SelectObject( hdcMask, hbmMask );

	hdcMem = CreateCompatibleDC( hdcDest );
	hbmMem = CreateCompatibleBitmap( hdcDest, cx, cy );
	hbmMem = (HBITMAP) SelectObject( hdcMem, hbmMem );

	clrBack = SetBkColor( hdcSrc, clrTrans );
	BitBlt( hdcMask, 0, 0, cx, cy, hdcSrc, xSrc, ySrc, SRCCOPY );
	SetBkColor( hdcSrc, clrBack );

	clrBack = SetBkColor( hdcDest, 0xFFFFFF );
	clrText = SetTextColor( hdcDest, 0x000000 );

	BitBlt( hdcMem, 0, 0, cx, cy, hdcDest, xDest, yDest, SRCCOPY );
	BitBlt( hdcMem, 0, 0, cx, cy, hdcSrc, xSrc, ySrc, SRCINVERT );
	BitBlt( hdcMem, 0, 0, cx, cy, hdcMask, 0, 0, SRCAND );
	BitBlt( hdcMem, 0, 0, cx, cy, hdcSrc, xSrc, ySrc, SRCINVERT );
	BitBlt( hdcDest, xDest, yDest, cx, cy, hdcMem, 0, 0, SRCCOPY );

	SetBkColor( hdcDest, clrBack );
	SetTextColor( hdcDest, clrText );

	hbmMask = (HBITMAP) SelectObject( hdcMask, hbmMask );
	DeleteObject( hbmMask );
	DeleteDC( hdcMask );

	hbmMem = (HBITMAP) SelectObject( hdcMem, hbmMem );
	DeleteObject( hbmMem );
	DeleteDC( hdcMem );

	return TRUE;
}

/*--End Of File---------------------------------------------------------------*/
