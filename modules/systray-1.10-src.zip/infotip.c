/*------------------------------------------------------------------------------
    This is part of the the source code for "systray"; a Litestep Module.
	As a whole it implements the "icon notification area".

    Copyright (C) 2004 Chris Rempel

    This program is free software; you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the Free
    Software Foundation; either version 2 of the License, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
    more details.

    You should have received a copy of the GNU General Public License along with
    this program; if not, write to the Free Software Foundation, Inc.,
    59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
------------------------------------------------------------------------------*/

////
/// infotip implementation
//

/* Thanks to the GeoShell devs I was able to write this!  Thanks! */

#include <tchar.h>
#include <windows.h>
#include <tlhelp32.h>
#include <commctrl.h>
#include <shellapi.h>

#include "systray.h"

// these are the infotip settings
#define INFOTIP_MAXIMUM_TIMEOUT 30000
#define INFOTIP_NORMAL_TIMEOUT 10000
#define INFOTIP_MINIMUM_TIMEOUT 5000
#define INFOTIP_MAXIMUM_WIDTH 300

typedef struct _INFOTIPITEM
{
	UINT uTimeout;
	DWORD dwInfoFlags;
	_TCHAR szInfo[256];
	_TCHAR szInfoTitle[64];
	PSYSTRAYICON psti;
	/**/
	struct _INFOTIPITEM * pNext;
	/**/
} INFOTIPITEM, *PINFOTIPITEM;

static PINFOTIPITEM s_pInfoTips;

static struct
{
	HWND hWnd;
	HWND hTrayWnd;
	BOOL bShowing;
	UINT uTimer;
	UINT uTimeout;
	/**/
} s_IT;



static VOID showInfoTip(VOID)
{
	if(NULL != s_pInfoTips)
	{
		DWORD icon;
		DWORD mask;
		RECT r;
		BOOL br = 0;

		// setup the timer
		s_IT.uTimer = 0;

		// if other tips are waiting, then always go with minimum timeout
		if(NULL != s_pInfoTips->pNext)
		{
			s_IT.uTimeout = INFOTIP_MINIMUM_TIMEOUT;
		}
		// otherwise use specified timeout within constraints
		else
		{
			if(s_pInfoTips->uTimeout == 0)
			{
				s_IT.uTimeout = INFOTIP_NORMAL_TIMEOUT;
			}
			else
			{
				s_IT.uTimeout = max(
					 INFOTIP_MINIMUM_TIMEOUT
					,min(s_pInfoTips->uTimeout, INFOTIP_MAXIMUM_TIMEOUT)
				);
			}
		}

		// work out the icon
		mask = NIIF_INFO | NIIF_WARNING | NIIF_ERROR;
		icon = s_pInfoTips->dwInfoFlags & mask;

		if(0 == *s_pInfoTips->szInfoTitle)
		{
			icon = 0;
		}

		if(GetWindowRect(g_hMainWnd, &r))
		{
			TOOLINFO ti;
			PRECT pr2;
			int x, y;

			pr2 = &s_pInfoTips->psti->rc;

			x = r.left + pr2->left + ((pr2->right - pr2->left) / 2);
			y = r.top + pr2->top + ((pr2->bottom - pr2->top) / 2);

			ti.cbSize = sizeof(TOOLINFO);
			ti.uId = (UINT)s_IT.hTrayWnd;
			ti.hwnd = s_IT.hTrayWnd;
			ti.lpszText = NULL;

			br = SendMessage(s_IT.hWnd, TTM_GETTOOLINFO, 0, (LPARAM)(LPTOOLINFO)&ti);

			if(br)
			{
				ti.lpszText = s_pInfoTips->szInfo;

				CopyRect(&ti.rect, &r);

				SendMessage(s_IT.hWnd, TTM_SETTOOLINFO, 0, (LPARAM)(LPTOOLINFO)&ti);
				br = SendMessage(s_IT.hWnd, TTM_SETTITLE, icon, (LPARAM) s_pInfoTips->szInfoTitle);

				if(br)
				{
					SendMessage(s_IT.hWnd, TTM_TRACKPOSITION, 0, (LPARAM)(DWORD) MAKELONG(x, y));
					SendMessage(s_IT.hWnd, TTM_TRACKACTIVATE, TRUE, (LPARAM)(LPTOOLINFO) &ti);

					s_IT.bShowing = TRUE;

					// set the timer to check every second
					SetTimer(s_IT.hTrayWnd, 1, 1000, NULL);
				}
			}
		}
	}

	return;
}

static VOID hideInfoTip(VOID)
{
	if(s_IT.bShowing)
	{
		PINFOTIPITEM piti = s_pInfoTips;
		TOOLINFO ti;

		KillTimer(s_IT.hTrayWnd, 1);

		s_pInfoTips = s_pInfoTips->pNext;

		ti.cbSize = sizeof(TOOLINFO);
		ti.uId = (UINT)s_IT.hTrayWnd;
		ti.hwnd = s_IT.hTrayWnd;

		SendMessage(s_IT.hWnd, TTM_TRACKACTIVATE, FALSE, (LPARAM)(LPTOOLINFO)&ti);

		s_IT.bShowing = FALSE;
		LocalFree(piti);
	}

	return;
}

static VOID nextInfoTip(VOID)
{
	// hide the current one
	hideInfoTip();

	// show the next one
	showInfoTip();

	return;
}

static VOID freeInfoTips(VOID)
{
	PINFOTIPITEM pitem;

	while(NULL != s_pInfoTips)
	{
		pitem = s_pInfoTips;
		s_pInfoTips = pitem->pNext;

		LocalFree(pitem);
	}

	return;
}

static VOID removeInfoTipByIcon(PSYSTRAYICON psti)
{
	if(s_IT.bShowing && psti == s_pInfoTips->psti)
	{
		nextInfoTip();
	}
	else
	{
		PINFOTIPITEM pitem = s_pInfoTips, pprev = NULL;

		while(NULL != pitem)
		{
			if(psti == pitem->psti)
			{
				if(NULL == pprev)
				{
					s_pInfoTips = pitem->pNext;
				}
				else
				{
					pprev->pNext = pitem->pNext;
				}

				LocalFree(pitem);
				break;
			}

			pprev = pitem;
			pitem = pitem->pNext;
		}
	}

	return;
}

static BOOL createInfoTipWnd(VOID)
{
	BOOL br = FALSE;

	if(NULL == s_IT.hWnd)
	{
		s_IT.hWnd = CreateWindowEx(
			 WS_EX_TOPMOST
			,TOOLTIPS_CLASS
			,NULL
			,WS_POPUP | TTS_BALLOON | TTS_NOPREFIX | TTS_ALWAYSTIP | TTS_CLOSE
			,0 ,0
			,0 ,0
			,s_IT.hTrayWnd
			,NULL
			,g_hMainInst
			,NULL
		);

		if(NULL != s_IT.hWnd)
		{
			TOOLINFO ti;

			SetWindowLong(s_IT.hWnd, GWL_USERDATA, magicDWord);

			SendMessage(s_IT.hWnd, TTM_SETMAXTIPWIDTH, 0, INFOTIP_MAXIMUM_WIDTH);

			ti.cbSize = sizeof(TOOLINFO);
			ti.uId = (UINT)s_IT.hTrayWnd;
			ti.hwnd = s_IT.hTrayWnd;

			ti.uFlags = TTF_TRACK|TTF_IDISHWND|TTF_TRANSPARENT|TTF_PARSELINKS;
			ti.hinst = g_hMainInst;
			ti.lpszText = TEXT("Dummy");
			SetRectEmpty(&ti.rect);

			// this fixes the mouse event bug on windows 2000
			SendMessage(s_IT.hWnd, CCM_SETVERSION, COMCTL32_VERSION, 0);

			// add the toolinfo to the window
			br = SendMessage(s_IT.hWnd, TTM_ADDTOOL, 0, (LPARAM)(LPTOOLINFO)&ti);
		}
	}

    return br;
}

static VOID destroyInfoTipWnd(VOID)
{
	if(NULL != s_IT.hWnd)
	{
	    TOOLINFO ti;

		ti.cbSize = sizeof(TOOLINFO);
		ti.uId = (UINT)s_IT.hTrayWnd;
		ti.hwnd = s_IT.hTrayWnd;
		
		SendMessage(s_IT.hWnd, TTM_DELTOOL, 0, (LPARAM)(LPTOOLINFO)&ti);

		DestroyWindow(s_IT.hWnd);
		s_IT.hWnd = NULL;
	}

	return;
}

LRESULT WINAPI InfoTipWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	LRESULT lr = 0;

	switch(uMsg)
	{
	case WM_TIMER:
		if(!s_IT.bShowing) /* shouldn't happen */
		{
			KillTimer(s_IT.hTrayWnd, 1);
			break;
		}

		if(s_IT.uTimer >= s_IT.uTimeout)
		{
			// hide the current infotip
			nextInfoTip();
		}
		else
		{
			s_IT.uTimer += 1000;
		}
		break;

	case WM_LBUTTONDOWN:
		nextInfoTip();
		break;

	case WM_NOTIFY:
		if(0 != lParam)
		{
			LPNMHDR pnmh = (LPNMHDR)lParam;

			switch(pnmh->code)
			{
			case TTN_POP:
				break;

			default:
				break;
			}
		}
		break;

	default:
		lr = DefWindowProc(hWnd, uMsg, wParam, lParam);
	}

	return lr;
}


/*----------------------------------------------------------------------------*/
VOID RemoveInfoTip(PSYSTRAYICON psti)
{
	if(NULL != s_IT.hTrayWnd)
	{
		removeInfoTipByIcon(psti);
	}

	return;
}

/*----------------------------------------------------------------------------*/
VOID PositionInfoTip(VOID)
{
	if(NULL != s_IT.hTrayWnd && s_IT.bShowing)
	{
		RECT r;

		if(GetWindowRect(g_hMainWnd, &r))
		{
			PRECT pr2;
			int x, y;

			pr2 = &s_pInfoTips->psti->rc;

			x = r.left + pr2->left + ((pr2->right - pr2->left) / 2);
			y = r.top + pr2->top + ((pr2->bottom - pr2->top) / 2);

			SendMessage(s_IT.hWnd, TTM_TRACKPOSITION, 0, (LPARAM)(DWORD) MAKELONG(x, y));
		}
		else
		{
			nextInfoTip();
		}
	}

	return;
}


/*----------------------------------------------------------------------------*/
BOOL SetInfoTip(PSYSTRAYICON psti, LPCTSTR szTip, LPCTSTR szTitle, DWORD dwFlags, UINT uTimeout)
{
	if(NULL == s_IT.hTrayWnd)
	{
		return FALSE;
	}

	/* Remove existing info tip */
	if(0 == *szTip)
	{
		removeInfoTipByIcon(psti);
	}
	/* Display new info tip */
	else
	{
		PINFOTIPITEM piti = LocalAlloc(LPTR, sizeof(INFOTIPITEM));

		if(NULL == piti)
		{
			return(FALSE);
		}

		if(NULL == s_pInfoTips)
		{
			s_pInfoTips = piti;
		}
		else
		{
			PINFOTIPITEM pLast = s_pInfoTips;

			while(NULL != pLast->pNext)
			{
				pLast = pLast->pNext;
			}

			pLast->pNext = piti;
		}

		piti->psti = psti;
		piti->uTimeout = uTimeout;
		piti->dwInfoFlags = dwFlags;
		lstrcpy(piti->szInfo, szTip);
		lstrcpy(piti->szInfoTitle, szTitle);

		// check if there is already a tip showing (we can only show 1 at a time)
		if(!s_IT.bShowing)
		{
			showInfoTip();
		}
		else
		{
			if(s_IT.uTimer < INFOTIP_MINIMUM_TIMEOUT)
			{
				// reset the timer to make it go quicker
				s_IT.uTimeout = INFOTIP_MINIMUM_TIMEOUT;
			}
			else
			{
				// if not, then we can timeout the info tip now
				s_IT.uTimer = s_IT.uTimeout;
			}
		}
	}

	return TRUE;
}


/*----------------------------------------------------------------------------*/
BOOL CreateInfoTips(VOID)
{
	WNDCLASS wc;
	BOOL br = FALSE;

	s_pInfoTips = NULL;

	s_IT.hWnd = NULL;
	s_IT.hTrayWnd = NULL;
	s_IT.bShowing = FALSE;
	s_IT.uTimer = 0;
	s_IT.uTimeout = INFOTIP_NORMAL_TIMEOUT;

	wc.style = CS_DBLCLKS;
	wc.lpfnWndProc = InfoTipWndProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = g_hMainInst;
	wc.hCursor = NULL;
	wc.hIcon = NULL;
	wc.hbrBackground = NULL;
	wc.lpszMenuName = NULL;
	wc.lpszClassName = WC_INFOTIP;

	if(0 != RegisterClass(&wc))
	{
		s_IT.hTrayWnd = CreateWindowEx(
			 0
			,WC_INFOTIP
			,NULL
			,WS_CLIPSIBLINGS | WS_CHILD
			,0, 0, 50, 20
			,g_hMainWnd
			,NULL
			,g_hMainInst
			,NULL
		);

		if(NULL == s_IT.hTrayWnd)
		{
			UnregisterClass(WC_INFOTIP, g_hMainInst);
		}
		else
		{
			br = createInfoTipWnd();

			if(!br)
			{
				DeleteInfoTips();
			}
		}
	}

	return br;
}

/*----------------------------------------------------------------------------*/
VOID DeleteInfoTips(VOID)
{
	if(NULL != s_IT.hTrayWnd)
	{
		hideInfoTip();

		freeInfoTips();

		destroyInfoTipWnd();

		DestroyWindow(s_IT.hTrayWnd);
		s_IT.hTrayWnd = NULL;

		UnregisterClass(WC_INFOTIP, g_hMainInst);
	}

	return;
}

/*--End Of File---------------------------------------------------------------*/
