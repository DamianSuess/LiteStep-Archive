/*------------------------------------------------------------------------------
    This is part of the the source code for "systray"; a Litestep Module.
	As a whole it implements the "icon notification area".

    Copyright (C) 1999 - 2000 Kevin Schafer
    Copyright (C) 2001 - 2004 Chris Rempel

    This program is free software; you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the Free
    Software Foundation; either version 2 of the License, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
    more details.

    You should have received a copy of the GNU General Public License along with
    this program; if not, write to the Free Software Foundation, Inc.,
    59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
------------------------------------------------------------------------------*/

////
/// system tray module interface implementation
//
#include <tchar.h>
#include <windows.h>
#include <commctrl.h>

#include "systray.h"
#include "wharfdata.h"

HINSTANCE g_hMainInst;
HWND g_hMainWnd;

HWND g_hShellWnd;
HWND g_hParentWnd;
HWND g_hTrayWnd;
HWND g_hDesktopWnd;

BOOL g_bOnWharf;
int g_nWharfBevelWidth;

SYSTRAY_CONFIG stCfg;

FUNC_BOOL__DWORD AllowSetForegroundWindow;

UINT nMessages[] = {
	LM_GETREVID,
	LM_SYSTRAY,
	0
};

//
// initModuleEx
//
EXTERN_C EXPORT int initModuleEx( HWND hParent, HINSTANCE hInstance, LPCTSTR pszPath )
{
	WNDCLASSEX wc;
	INITCOMMONCONTROLSEX iccex;

    iccex.dwSize = sizeof(INITCOMMONCONTROLSEX);
	iccex.dwICC = ICC_TAB_CLASSES;//ICC_BAR_CLASSES;//ICC_WIN95_CLASSES;
    InitCommonControlsEx(&iccex);

#ifdef _DEBUG /* Release build assigns this in _DllMainCRTStartup */
	g_hMainInst = hInstance;
#endif
	g_hMainWnd = NULL;
	g_hShellWnd = GetLitestepWnd();
	g_hParentWnd = hParent != g_hShellWnd ? hParent:NULL;

	g_hTrayWnd = FindWindowEx(
		 FindWindow(_T("Shell_TrayWnd"), _T(""))
		,NULL
		,_T("TrayNotifyWnd")
		,_T("")
	);

	g_hDesktopWnd = FindWindow(_T("DesktopBackgroundClass"), _T(""));
	
	if(NULL == g_hDesktopWnd)
	{
		g_hDesktopWnd = GetDesktopWindow();
	}

	AllowSetForegroundWindow = (FUNC_BOOL__DWORD)GetProcAddress(
		 GetModuleHandle(_T("USER32"))
		,"AllowSetForegroundWindow"
	);

	ReadConfig();

	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = CS_DBLCLKS|CS_NOCLOSE;
	wc.lpfnWndProc = SystrayProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = g_hMainInst;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hIcon = NULL;
	wc.hbrBackground = NULL;
	wc.lpszMenuName = NULL;
	wc.lpszClassName = WC_SYSTRAY;
	wc.hIconSm = NULL;

	RegisterClassEx(&wc);

	g_hMainWnd = CreateWindowEx(
		 WS_EX_TOOLWINDOW|(stCfg.fAlwaysOnTop ? WS_EX_TOPMOST:0)
		,WC_SYSTRAY
		,NULL
		,WS_POPUP
		,stCfg.nX
		,stCfg.nY
		,0
		,0
		,(HWND)NULL
		,(HMENU)NULL
		,g_hMainInst
		,NULL
	);

	SetWindowLong(g_hMainWnd, GWL_USERDATA, magicDWord);
	PostMessage(g_hTrayWnd, SS_NOTIFYTRAY, NT_SETTRAYHWND, (LPARAM)g_hMainWnd);

	if(stCfg.fShowInfoTips && !CreateInfoTips())
	{
		stCfg.fShowInfoTips = FALSE;
	}

	if(NULL != g_hParentWnd)
	{
		SetWindowLong(g_hMainWnd, GWL_STYLE, (GetWindowLong(g_hMainWnd, GWL_STYLE) &~ WS_POPUP)|WS_CHILD);
		SetParent(g_hMainWnd, g_hParentWnd);
	}

	SendMessage(g_hShellWnd, LM_REGISTERMESSAGE, (WPARAM) g_hMainWnd, (LPARAM) nMessages);

	if(!g_bOnWharf)
	{
		AddBangCommand(TEXT("!SystrayHide"), SystrayHide);
		AddBangCommand(TEXT("!SystrayMove"), SystrayMove);
		AddBangCommand(TEXT("!SystrayShow"), SystrayShow);
		AddBangCommand(TEXT("!SystrayToggle"), SystrayToggle);
		AddBangCommand(TEXT("!SystrayPinToDesktop"), SystrayPinToDesktop);
	}

	stCfg.fVisible = !stCfg.fHidden;
	AdjustLayout();

	if(stCfg.fVisible && !stCfg.fHideIfEmpty)
	{
		ShowWindow(g_hMainWnd, SW_SHOWNOACTIVATE);
	}

	PostMessage(g_hShellWnd, LM_SYSTRAYREADY, 0, 0);

	return 0;

	UNREFERENCED_PARAMETER(pszPath);
	UNREFERENCED_PARAMETER(hInstance);
}

//
// initModule
//
EXTERN_C EXPORT int initModule( HWND hParent, HINSTANCE hInstance, wharfDataType *wd )
{
	return initModuleEx(hParent, hInstance, NULL != wd ? wd->lsPath:NULL);
}

//
// quitModule
//
EXTERN_C EXPORT void quitModule( HINSTANCE hInstance )
{
	if(!g_bOnWharf)
	{
		RemoveBangCommand(TEXT("!SystrayHide"));
		RemoveBangCommand(TEXT("!SystrayMove"));
		RemoveBangCommand(TEXT("!SystrayShow"));
		RemoveBangCommand(TEXT("!SystrayToggle"));
		RemoveBangCommand(TEXT("!SystrayPinToDesktop"));
	}

	SendMessage(g_hShellWnd, LM_UNREGISTERMESSAGE, (WPARAM)g_hMainWnd, (LPARAM)nMessages);

	if(stCfg.fShowInfoTips)
	{
		DeleteInfoTips();
	}

	DestroyWindow(g_hMainWnd);
	UnregisterClass(WC_SYSTRAY, g_hMainInst);

	FreeConfig();

	g_hMainWnd = NULL;

	return;
	UNREFERENCED_PARAMETER(hInstance);
}

//
// initWharfModule
//
EXTERN_C EXPORT int initWharfModule( HWND hParent, HINSTANCE hInstance, wharfDataType *wd )
{
	g_bOnWharf = TRUE;
	g_nWharfBevelWidth = NULL != wd ? wd->borderSize:GetRCInt("WharfBevelWidth", 0);
	return initModuleEx(hParent, hInstance, NULL != wd ? wd->lsPath:NULL);
}

//
// quitWharfModule
//
EXTERN_C EXPORT void quitWharfModule( HINSTANCE hInstance )
{
	quitModule(hInstance);
	g_bOnWharf = FALSE;
}


#ifndef _DEBUG /* No need to depend on the CRT lib in release binaries */
BOOL WINAPI _DllMainCRTStartup( HANDLE hDllHandle, DWORD dwReason, LPVOID lpResereved )
{
    if(DLL_PROCESS_ATTACH == dwReason)
    {
		DisableThreadLibraryCalls(hDllHandle);
		g_hMainInst = hDllHandle;
	}

	return TRUE;
	UNREFERENCED_PARAMETER(lpResereved);
}
#endif

/*--End Of File---------------------------------------------------------------*/
