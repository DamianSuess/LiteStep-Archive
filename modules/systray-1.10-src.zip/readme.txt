system tray module for Litestep (systray.dll), 1.08
--

Systray.dll is a system tray module for Litestep which provides complete
control over appearance, placement, and icon layout.  The systray is also
(more correctly) known as the "icon notification area".

Systray is distributed under the conditions of the GNU GENERAL PUBLIC LICENSE.
See license.txt for details.

Release Notes: 1.08

  Thanks to Maudin for releasing the source code to his systray module, I
  (jugg) have been able to bring a few more features and updates to the
  table.

  This release adds Info Tips (also known as balloon tips) support among
  many other improvments and tweaks.  While not as fully featured or
  bloated *cough* as other systray modules, it is a stable streamlined
  implementation that works for me.  I hope others find it useful as well.
  So, while I am glad to get feature requests, I won't promise to implent
  every one.  Please do let me know of any bugs, or odd behavior of the
  module that needs fixing.

  A big shout out to the geoShell dev's, as I was able to glean the
  necessary information on how to implement InfoTips from their code when
  my implementation wasn't handling timeouts and movement correctly.  So,
  I took their code and revamped it to fit my needs. Isn't the GPL great?

  Thanks geoShell!

Installation

  Add a LoadModule line for systray.dll to your step.rc (assuming you want
  systray.dll to run as a desktop module as opposed to a wharf module - see
  next section).
  
  Example:
  
  LoadModule C:\Litestep\modules\systray.dll
  
  Included in the zip file is systray.steprc, a sample configuration file
  for systray.dll. It contains only systray.dll configuration options and
  can be pasted directly into your step.rc (or theme.rc) to give you a
  template to work from when configuring systray.dll.

Dock to Wharf

  If you want the systray in a wharf tile instead of on the desktop
  then you can load systray.dll as wharf module instead of a load
  module. Instead of the LoadModule line, use something like:
  
  *Wharf "System Tray" .none @C:\Litestep\modules\systray.dll
  
  Functions such as always on top, dragging, and dynamic sizing are
  not available while the tray is docked to the wharf.

Configuration

  SystrayAlwaysOnTop
  
    If this option is present, it causes the tray window to appear
    on top of all other windows.
  
  SystrayAutoSize <horizontal> <vertical>
  
    Determines how the tray is automatically resized when icons are
    added or removed. Horizontal can be left or right and vertical
    can be up or down. Defaults are right and down. This option
    controls how the tray window is resized, where SystrayDirection
    controls how the icons are placed inside the tray. Note that
    unlike SystrayDirection, you must specify the horizontal first
    and vertical second: "left up", not "up left".
    
  SystrayBgColor <color>
  
    Sets the background color of the systray when transparency is not
    enabled.  Defaults to white (FFFFFF)
  
  SystrayBitmap <bitmap> <border-left> <border-top> <border-right> <border-bottom> <method>
  
    Sets the bitmap file and border widths used for skins. See the
    discussion of skins below. By default the tray is transparent. If
    the method parameter has a value of "tiled" then the dynamic
    sections of the skin bitmap are tiled rather than stretched. It is
    recommended that for tiled skins you make the tile reasonably
    large in order to reduce flicker during painting.
  
  SystrayBorderDrag
  
    If this option is present, you will be able to drag the tray by
    pressing and holding the left mouse button over the border or
    any area not covered by an icon.
  
  SystrayBorderX <n>
  SystrayBorderY <n>
  
    Specifies the amount of space (in pixels) between the border
    and the icons, horizontal and vertical respectively. Default is 0.
  
  SystrayColorSaturation <n>
  
    Sets the icon color saturation between 0 and 255, where 255 is full color
    and 0 is no color (gray scale). Defaults to 0. SystrayIconEffects must
    be enabled for this to have an affect.
  
  SystrayDirection <direction> <wrap-direction>
  
    Controls the icon layout. The direction can be one of: left, right,
    up, down. The wrap-direction can be up or down if direction is
    left or right (horizontal tray), or left or right if direction is up
    or down (vertical tray). The default direction is right and the
    default wrap-direction is up.
  
  SystrayHidden
  
    If this command is present the tray will be initially hidden. Use
    !SystrayShow or !SystrayToggle to show it.
  
  SystrayHideIfEmpty
  
    Causes the tray to be hidden if there are no icons.
  
  SystrayHueColor <color>
  
    Sets the hue color to be applied to the icons
  
  SystrayHueIntensity <n>
  
    Sets the hue intensity between 1 and 255, or 0 to disable. Defaults to 128.
    SystrayIconEffects must be enabled for this to have an affect.
  
  SystrayIconEffects
  
    If this option is set, both Icon Color Saturation and Icon Hueing effects
    are enabled.
  
  SystrayIconSize <n>
  
    Tray icons are stretched (if necessary) to be n x n pixels in
    size. The default is 16.
  
  SystrayMaxWidth <n>
  SystrayMaxHeight <n>
  
    Ensures that the tray will never exceed n pixels in width or
    height. The default is -1 (no maximum).
  
  SystrayMinWidth <n>
  SystrayMinHeight <n>
  
    Ensures that the tray will always be at least n pixels in width
    or height. The default is -1 (no minimum).
  
  SystrayNoTransparency
  
    If you're using a bitmapped background with no transparent areas
    then you can add this command to enable flicker free painting.
  
  SystrayPinToDesktop
  
    If this option is present, it causes the tray window to be
    pinned to the desktop, making it appear behind normal application
    windows.
  
  SystrayShowInfoTips
  
    If this option is present, InfoTips will be displayed for any
    notification icon that supports them.
  
  SystraySnapDistance <n>
  
    While dragging, if the tray is moved to a position less than
    n pixels from a screen edge, it will be snapped to that edge.
    If n is 0 then snap to edge is disabled. Default is 4.
  
  SystraySpacingX <n>
  SystraySpacingY <n>
  
    Specifies the number of pixels of spacing between icons in
    the tray, horizontal and vertical respectively. Default is 2.
  
  SystrayWrapCount <n>
  
    Specifies the maximum number of icons on a row (horizontal)
    or column (vertical) before wrapping. The default is -1 (do not
    wrap).
  
  SystrayX <n>
  SystrayY <n>
  
    Sets the x or y position (screen coordinates, pixels) of the
    tray. Negative values are interpreted relative to the bottom
    right corner of the screen. The default is -1 (screen width or
    height).

Bang Commands

  !SystrayHide
  
    Hides the tray window.
  
  !SystrayMove <x> <y>
  
    Moves the tray to screen position x, y (in pixels).
  
  !SystrayShow
  
    Shows the tray window after having been hidden.
  
  !SystrayToggle
  
    Toggle the visible state (show/hide) of the tray window.
  
  !SystrayPinToDesktop <boolean>
    Pins the systray to the desktop, or if called with "FALSE" as
    the parameter, it detaches from the desktop.

Skins

  Instead of a standard transparent system tray, systray.dll also
  supports skins (bitmapped background and borders). The systray
  uses 9 bitmaps: a bitmap for each corner, one for each side
  and one for the icon area. For efficiency, all these bitmaps are
  stored in a single .bmp file. The SystrayBitmap commands takes
  this .bmp file along with four border widths as its parameters.
  
  These border widths specify the widths (left and right borders)
  and heights (top and bottom borders) of the borders. Corner
  bitmaps are determined by the borders they join, ie, the top
  left corner's bitmap has the width of the left border and the
  height of the top border. The width of the top and bottom
  borders, the height of the left and right borders, and both
  the width and height of the center bitmap are calculated from
  the border widths and the size of the entire bitmap.
  
  As I found out, Enlightenment has a similar function called edge
  scaling (actually, it's a function of Imlib). If you're familiar
  with that, skins work the same way.
  
  Note: Not all the borders have to be present. If you don't
  want a border, use 0 as its width. It is also possible to have
  no borders, just a single bitmap.
  
  Pseudo-transparency is also available in skins. Areas which are
  to be transparent should be pink (RGB 255, 0, 255). Corner bitmaps
  always support transparency, and border and center bitmaps
  support it when the drawing method is set to "tiled".
  
  I've added a collection of sample configurations which take
  advantage of skins. Check out the samples dir in the zip.

--
Maduin <maduin@dasoft.org>
jugg <jugg@hotmail.com> (current maintainer)
