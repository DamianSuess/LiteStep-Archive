/*------------------------------------------------------------------------------
    This is part of the the source code for "systray"; a Litestep Module.
	As a whole it implements the "icon notification area".

    Copyright (C) 1999 - 2000 Kevin Schafer
    Copyright (C) 2001 - 2004 Chris Rempel

    This program is free software; you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the Free
    Software Foundation; either version 2 of the License, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
    more details.

    You should have received a copy of the GNU General Public License along with
    this program; if not, write to the Free Software Foundation, Inc.,
    59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
------------------------------------------------------------------------------*/

////
/// system tray
//
#include <tchar.h>
#include <windows.h>
#include <commctrl.h>
#include <shellapi.h>

#include "systray.h"

PSYSTRAYICON g_pIconList;
int g_cIcons;

HWND g_hToolTip;
UINT g_uLastID = 1;
HWND g_hInfoTip;
UINT g_uInfoID = 1;

int g_nSizeX;
int g_nSizeY;

HBITMAP g_hbmSaved;
HBITMAP g_hbmBuffer;
HDC g_hdcBuffer;
BOOL g_fMoveTemp;


VOID AddToolTip(PSYSTRAYICON psti)
{
	TOOLINFO ti;

	ti.cbSize = sizeof(TOOLINFO);
	ti.uFlags = 0;
	ti.hwnd = g_hMainWnd;
	ti.uId = psti->uToolTip = g_uLastID++;
	ti.rect = psti->rc;
	ti.hinst = NULL;
	ti.lpszText = 0 != *psti->szTip ? psti->szTip : NULL;

	SendMessage(g_hToolTip, TTM_ADDTOOL, 0, (LPARAM)(LPTOOLINFO)&ti);
	return;
}

VOID ModToolTip(PSYSTRAYICON psti)
{
	TOOLINFO ti;

	ti.cbSize = sizeof(TOOLINFO);
	ti.hwnd = g_hMainWnd;
	ti.uId = psti->uToolTip;
	ti.hinst = NULL;
	ti.lpszText = psti->szTip;

	SendMessage(g_hToolTip, TTM_UPDATETIPTEXT, 0, (LPARAM)(LPTOOLINFO)&ti);
	return;
}

VOID DelToolTip(PSYSTRAYICON psti)
{
	TOOLINFO ti;

	ti.cbSize = sizeof(TOOLINFO);
	ti.hwnd = g_hMainWnd;
	ti.uId = psti->uToolTip;

	SendMessage(g_hToolTip, TTM_DELTOOL, 0, (LPARAM)(LPTOOLINFO)&ti);
	return;
}


//
// AdjustLayout
//

void AdjustLayout( void )
{
	// boy is this function a mess =)
	// ... but, it works!

	PSYSTRAYICON psti = g_pIconList;
	int nOriginX, nOriginY;
	int nCurrentX, nCurrentY;
	int nActualX, nActualY;
	int nCount = 0;

	if( stCfg.fHorizontal )
	{
		g_nSizeX = (stCfg.nWrapCount > 0) ? min(g_cIcons, stCfg.nWrapCount) : g_cIcons;
		g_nSizeX = (g_nSizeX * (stCfg.nIconSize + stCfg.nSpacingX)) - stCfg.nSpacingX;

		g_nSizeY = (stCfg.nWrapCount > 0) ? ((((g_cIcons > 1 ? g_cIcons : 1) - 1) / stCfg.nWrapCount) + 1) : 1;
		g_nSizeY = (g_nSizeY * (stCfg.nIconSize + stCfg.nSpacingY)) - stCfg.nSpacingY;
	}
	else
	{
		g_nSizeX = (stCfg.nWrapCount > 0) ? ((((g_cIcons > 1 ? g_cIcons : 1) - 1) / stCfg.nWrapCount) + 1) : 1;
		g_nSizeX = (g_nSizeX * (stCfg.nIconSize + stCfg.nSpacingX)) - stCfg.nSpacingX;

		g_nSizeY = (stCfg.nWrapCount > 0) ? min(g_cIcons, stCfg.nWrapCount) : g_cIcons;
		g_nSizeY = (g_nSizeY * (stCfg.nIconSize + stCfg.nSpacingY)) - stCfg.nSpacingY;
	}

	if( g_nSizeX )
	{
		g_nSizeX += stCfg.nBorderLeft + stCfg.nBorderRight + (stCfg.nBorderX * 2);
	}

	if( g_nSizeY )
	{
		g_nSizeY += stCfg.nBorderTop + stCfg.nBorderBottom + (stCfg.nBorderY * 2);
	}

	g_nSizeX = (stCfg.nMinWidth > 0) ? max(stCfg.nMinWidth, g_nSizeX) : g_nSizeX;
	g_nSizeX = (stCfg.nMaxWidth > 0) ? min(stCfg.nMaxWidth, g_nSizeX) : g_nSizeX;
	g_nSizeY = (stCfg.nMinHeight > 0) ? max(stCfg.nMinHeight, g_nSizeY) : g_nSizeY;
	g_nSizeY = (stCfg.nMaxHeight > 0) ? min(stCfg.nMaxHeight, g_nSizeY) : g_nSizeY;

	if( stCfg.nDeltaX < 0 )
	{
		if( stCfg.nDeltaY < 0 )
		{
			nOriginX = g_nSizeX - stCfg.nIconSize - stCfg.nBorderRight - stCfg.nBorderX;
			nOriginY = g_nSizeY - stCfg.nIconSize - stCfg.nBorderBottom - stCfg.nBorderY;
		}
		else
		{
			nOriginX = g_nSizeX - stCfg.nIconSize - stCfg.nBorderRight - stCfg.nBorderX;
			nOriginY = stCfg.nBorderTop + stCfg.nBorderY;
		}
	}
	else
	{
		if( stCfg.nDeltaY < 0 )
		{
			nOriginX = stCfg.nBorderLeft + stCfg.nBorderX;
			nOriginY = g_nSizeY - stCfg.nIconSize - stCfg.nBorderBottom - stCfg.nBorderY;
		}
		else
		{
			nOriginX = stCfg.nBorderLeft + stCfg.nBorderX;
			nOriginY = stCfg.nBorderTop + stCfg.nBorderY;
		}
	}

	nCurrentX = nOriginX;
	nCurrentY = nOriginY;

	while( psti )
	{
		psti->rc.left = nCurrentX;
		psti->rc.top = nCurrentY;
		psti->rc.right = nCurrentX + stCfg.nIconSize;
		psti->rc.bottom = nCurrentY + stCfg.nIconSize;

		if( psti->uToolTip )
		{
			TOOLINFO ti;

			ti.cbSize = sizeof(TOOLINFO);
			ti.hwnd = g_hMainWnd;
			ti.uId = psti->uToolTip;
			ti.rect = psti->rc;

			SendMessage(g_hToolTip, TTM_NEWTOOLRECT, 0, (LPARAM) &ti);
			SendMessage(g_hToolTip, TTM_SETMAXTIPWIDTH, 0, 300);
		}

		nCount++;

		if( (stCfg.nWrapCount > 0) && (nCount >= stCfg.nWrapCount) )
		{
			if( stCfg.fHorizontal )
			{
				nOriginY += stCfg.nDeltaY;
			}
			else
			{
				nOriginX += stCfg.nDeltaX;
			}

			nCurrentX = nOriginX;
			nCurrentY = nOriginY;

			nCount = 0;
		}
		else
		{
			if( stCfg.fHorizontal )
			{
				nCurrentX += stCfg.nDeltaX;
			}
			else
			{
				nCurrentY += stCfg.nDeltaY;
			}
		}

		psti = psti->pNext;
	}

	PositionInfoTip();

	nActualX = (stCfg.nResizeH == DIR_LEFT) ? (stCfg.nX - g_nSizeX) : stCfg.nX;
	nActualY = (stCfg.nResizeV == DIR_UP) ? (stCfg.nY - g_nSizeY) : stCfg.nY;

	if( nActualX < 0 )
	{
		nActualX = 0;
	}
	else if( (nActualX + g_nSizeX) > stCfg.nScreenCX )
	{
		nActualX = stCfg.nScreenCX - g_nSizeX;
	}

	if( nActualY < 0 )
	{
		nActualY = 0;
	}
	else if( (nActualY + g_nSizeY) > stCfg.nScreenCY )
	{
		nActualY = stCfg.nScreenCY - g_nSizeY;
	}

	g_fMoveTemp = TRUE;

	SetWindowPos(
		 g_hMainWnd
		,NULL
		,nActualX
		,nActualY
		,g_nSizeX
		,g_nSizeY
		,SWP_NOZORDER | SWP_NOACTIVATE
	);

	if( stCfg.fHideIfEmpty )
	{
		if( !g_cIcons )
		{
			if( stCfg.fVisible )
			{
				ShowWindow(g_hMainWnd, SW_HIDE);
			}
		}
		else
		{
			if( stCfg.fVisible && !IsWindowVisible(g_hMainWnd) )
			{
				ShowWindow(g_hMainWnd, SW_SHOWNOACTIVATE);
			}
		}
	}

	g_fMoveTemp = FALSE;
	InvalidateRect(g_hMainWnd, NULL, FALSE);
}

//
// AddIcon
//

PSYSTRAYICON AddIcon( BOOL fRedraw )
{
	PSYSTRAYICON pIcon;

	pIcon = (PSYSTRAYICON)LocalAlloc(LPTR, sizeof(SYSTRAYICON));

	if( NULL != pIcon )
	{
		if( !g_pIconList )
		{
			g_pIconList = pIcon;
		}
		else
		{
			PSYSTRAYICON pLast = g_pIconList;

			while( pLast->pNext )
			{
				pLast = pLast->pNext;
			}

			pLast->pNext = pIcon;
		}

		g_cIcons++;

		AddToolTip(pIcon);

		if( fRedraw )
		{
			AdjustLayout();
		}

	}

	return pIcon;
}

//
// SearchForIcon
//

PSYSTRAYICON SearchForIcon( HWND hWnd, UINT uID, BOOL fAdd )
{
	PSYSTRAYICON psti = g_pIconList;

	while( psti )
	{
		if( psti->hWnd == hWnd && psti->uID == uID )
		{
			return psti;
		}

		psti = psti->pNext;
	}

	if( !fAdd )
	{
		return NULL;
	}

	return AddIcon(TRUE);
}

//
// RemoveIcon
//

BOOL RemoveIcon( PSYSTRAYICON psti )
{
	PSYSTRAYICON pIcon = g_pIconList;
	PSYSTRAYICON pPrev = NULL;

	while( NULL != pIcon )
	{
		if( pIcon == psti )
		{
			if( pPrev )
			{
				pPrev->pNext = pIcon->pNext;
			}
			else
			{
				g_pIconList = pIcon->pNext;
			}

			DelToolTip(pIcon);
			RemoveInfoTip(pIcon);

			g_cIcons--;

			LocalFree((LPVOID)pIcon);

			AdjustLayout();
			return TRUE;
		}

		pPrev = pIcon;
		pIcon = pIcon->pNext;
	}

	return FALSE;
}

//
// FreeTrayIconList
//

void FreeTrayIconList( void )
{
	PSYSTRAYICON pIcon = g_pIconList;
	PSYSTRAYICON pNext;

	while( pIcon )
	{
		pNext = pIcon->pNext;

		if( NULL != pIcon->hIcon )
		{
			DestroyIcon(pIcon->hIcon);
		}

		DelToolTip(pIcon);
		RemoveInfoTip(pIcon);

		LocalFree((LPVOID)pIcon);

		pIcon = pNext;
	}

	g_pIconList = NULL;
	g_cIcons = 0;

	return;
}

//
// CreateIconEffects
//

HICON CreateIconEffects( HICON hIcon )
{
	ICONINFO ii;
	HICON hHuedIcon = NULL;

	if( GetIconInfo(hIcon, &ii) )
	{
		HDC hDC = GetDC(g_hMainWnd);
		HDC hColorDC = CreateCompatibleDC(hDC);
		HDC hMaskDC = CreateCompatibleDC(hDC);
		BITMAP bm;

		int intense = stCfg.nHueIntensity;
		int saturate = stCfg.nColorSaturation;
		int x, y, cx, cy;

		GetObject( ii.hbmColor, sizeof(BITMAP), &bm );
		cx = bm.bmWidth;
		cy = bm.bmHeight;

		/* Select the icon bitmaps into their DCs */
		ii.hbmColor = (HBITMAP)SelectObject(hColorDC, ii.hbmColor);
		ii.hbmMask = (HBITMAP)SelectObject(hMaskDC, ii.hbmMask);

		/* Modified from MrJukes Icon Effects (color saturation and icon hueing) code */
		for(y = 0; y < cy; y++ )
		{
			for(x = 0; x < cx; x++ )
			{
				/* check mask for non transparent pixel */
				if( !GetPixel(hMaskDC, x, y) )
				{
					COLORREF cl = GetPixel(hColorDC, x, y);
					BYTE r = GetRValue(cl);
					BYTE g = GetGValue(cl);
					BYTE b = GetBValue(cl);

					/* saturation effect (255 = full color, so no need to modify) */
					if( 255 != saturate )
					{
						BYTE gray = (BYTE)((r * 3086 + g * 6094 + b * 820)/10000);

						r = (BYTE)((r * saturate + gray * (255 - saturate) + 255) >> 8);
						g = (BYTE)((g * saturate + gray * (255 - saturate) + 255) >> 8);
						b = (BYTE)((b * saturate + gray * (255 - saturate) + 255) >> 8);
					}

					/* icon hue effect (0 = no hue intensity, so need need to modify) */
					if( 0 != intense )
					{
						r = (BYTE)((r * (255 - intense) + GetRValue(stCfg.clrHue) * intense + 255) >> 8);
						g = (BYTE)((g * (255 - intense) + GetGValue(stCfg.clrHue) * intense + 255) >> 8);
						b = (BYTE)((b * (255 - intense) + GetBValue(stCfg.clrHue) * intense + 255) >> 8);
					}

					/* Put the modified pixel back */
					SetPixel(hColorDC, x, y, RGB(r,g,b));
				}
			}
		}

		/* Restore the bitmap handles */
		ii.hbmColor = (HBITMAP)SelectObject(hColorDC, ii.hbmColor);
		ii.hbmMask = (HBITMAP)SelectObject(hMaskDC, ii.hbmMask);

		/* Create the Hued icon */
		hHuedIcon = CreateIconIndirect(&ii);

		/* Free GetIconInfo() allocated resources */
		DeleteObject(ii.hbmColor);
		DeleteObject(ii.hbmMask);

		/* Free local allocations */
		DeleteDC(hMaskDC);
		DeleteDC(hColorDC);
		ReleaseDC(g_hMainWnd, hDC);
	}

	/* If it failed for some reason, just straight copy it */
	if(NULL == hHuedIcon)
	{
		hHuedIcon = CopyIcon(hIcon);
	}

	return hHuedIcon;
}

//
// CopyTrayIcon
//

PSYSTRAYICON CopyTrayIcon( PLSNOTIFYICONDATA pnid )
{
	PSYSTRAYICON psti;

	psti = SearchForIcon(pnid->hWnd, pnid->uID, TRUE);

	if( NULL != psti )
	{
		psti->hWnd = pnid->hWnd;
		psti->uID = pnid->uID;

		if( NIF_MESSAGE == (pnid->uFlags & NIF_MESSAGE) )
		{
			psti->uCallbackMessage = pnid->uCallbackMessage;
		}

		if( NIF_ICON == (pnid->uFlags & NIF_ICON) )
		{
			if( NULL != psti->hIcon )
			{
				DestroyIcon(psti->hIcon);
				psti->hIcon = NULL;
			}

			if( NULL != pnid->hIcon )
			{
				if( stCfg.fIconEffects )
				{
					psti->hIcon = CreateIconEffects(pnid->hIcon);
				}
				else
				{
					psti->hIcon = CopyIcon(pnid->hIcon);
				}
			}

			InvalidateRect(g_hMainWnd, &psti->rc, FALSE);
		}

		if( NIF_TIP == (pnid->uFlags & NIF_TIP) )
		{
			lstrcpyn(psti->szTip, pnid->szTip, LEN_TOOLTIP);
			psti->szTip[LEN_TOOLTIP-1] = 0;

			ModToolTip(psti);
		}

		if( NIF_INFO == (pnid->uFlags & NIF_INFO) && stCfg.fShowInfoTips )
		{
			PCNOTIFYICONDATASH pnsh = (PCNOTIFYICONDATASH)(VOID*)pnid;

			SetInfoTip(psti, pnsh->szInfo, pnsh->szInfoTitle, pnsh->dwInfoFlags, pnsh->u.uTimeout);
		}
	}

	return psti;
}

//
// RemoveTrayIcon
//

VOID RemoveTrayIcon( PSYSTRAYICON psti )
{
	if( NULL != psti->hIcon )
	{
		DestroyIcon(psti->hIcon);
	}

	RemoveIcon(psti);

	return;
}

//
// OmniBlt (all-in-one blt function)
//

BOOL OmniBlt(
	 HDC hdcDest
	,int xDest
	,int yDest
	,int cxDest
	,int cyDest
	,HDC hdcSrc
	,int xSrc
	,int ySrc
	,int cxSrc
	,int cySrc
	,BOOL fTile
	,COLORREF crTrans
)
{
	// this function selects the appropriate blt
	// method (tile or stretch). makes SkinTray
	// simpler.

	BOOL fResult = TRUE;

	if( fTile )
	{
		int nWidth = cxDest;
		int nHeight = cyDest;
		int x, y;

		for( y = 0; y < nHeight; y += cySrc )
		{
			cxDest = nWidth;

			for( x = 0; x < nWidth; x += cxSrc )
			{
				if( crTrans != CLR_NONE )
				{
					TransBlt(
						 hdcDest
						,xDest + x
						,yDest + y
						,min(cxDest, cxSrc)
						,min(cyDest, cySrc)
						,hdcSrc
						,xSrc
						,ySrc
						,crTrans
					);
				}
				else
				{
					fResult &= BitBlt(
						 hdcDest
						,xDest + x
						,yDest + y
						,min(cxDest, cxSrc)
						,min(cyDest, cySrc)
						,hdcSrc
						,xSrc
						,ySrc
						,SRCCOPY
					);
				}

				cxDest -= cxSrc;
			}

			cyDest -= cySrc;
		}
	}
	else
	{
		fResult = StretchBlt(
			 hdcDest
			,xDest
			,yDest
			,cxDest
			,cyDest
			,hdcSrc
			,xSrc
			,ySrc
			,cxSrc
			,cySrc
			,SRCCOPY
		);
	}

	return fResult;
}

//
// SkinTray
//

BOOL SkinTray( HDC hDC )
{
	// very ugly, but it works...

	HDC hdcMem;
	HBITMAP hbmOld;

	if( g_bOnWharf )
	{
		hdcMem = CreateCompatibleDC(hDC);

		if( !g_hbmSaved )
		{
			g_hbmSaved = CreateCompatibleBitmap(hDC, g_nSizeX, g_nSizeY);
			hbmOld = (HBITMAP) SelectObject(hdcMem, g_hbmSaved);

			BitBlt(hdcMem, 0, 0, g_nSizeX, g_nSizeY, hDC, 0, 0, SRCCOPY);
			SelectObject(hdcMem, hbmOld);
		}

		hbmOld = (HBITMAP) SelectObject(hdcMem, g_hbmSaved);
		BitBlt(hDC, 0, 0, g_nSizeX, g_nSizeY, hdcMem, 0, 0, SRCCOPY);

		SelectObject(hdcMem, hbmOld);
		DeleteDC(hdcMem);

		return TRUE;
	}

	if( stCfg.fNoTransparency )
	{ // fill complete area with background color
		RECT r;
		GetClientRect(g_hMainWnd, &r);
		FillRect(hDC, &r, stCfg.hbrBgColor);
	}

	if( stCfg.hbmSkin )
	{
		hdcMem = CreateCompatibleDC(hDC);
		hbmOld = (HBITMAP) SelectObject(hdcMem, stCfg.hbmSkin);

		SetStretchBltMode(hDC, STRETCH_DELETESCANS);

		if( stCfg.nBorderTop )
		{
			// topleft corner
			TransBlt(
				 hDC
				,0 ,0
				,stCfg.nBorderLeft ,stCfg.nBorderTop
				,hdcMem
				,0, 0
				,CLR_TRANSPARENT
			);

			// top edge
			OmniBlt(
				 hDC
				,stCfg.nBorderLeft
				,0
				,g_nSizeX - stCfg.nBorderLeft - stCfg.nBorderRight
				,stCfg.nBorderTop
				,hdcMem
				,stCfg.nBorderLeft
				,0
				,stCfg.nBitmapX - stCfg.nBorderLeft - stCfg.nBorderRight
				,stCfg.nBorderTop
				,stCfg.fSkinTiled
				,CLR_TRANSPARENT
			);

			// topright corner
			TransBlt(
				 hDC
				,g_nSizeX - stCfg.nBorderRight
				,0
				,stCfg.nBorderRight
				,stCfg.nBorderTop
				,hdcMem
				,stCfg.nBitmapX - stCfg.nBorderRight
				,0
				,CLR_TRANSPARENT
			);
		}

		if( stCfg.nBorderLeft )
		{
			// left edge
			OmniBlt(
				 hDC
				,0
				,stCfg.nBorderTop
				,stCfg.nBorderLeft
				,g_nSizeY - stCfg.nBorderTop - stCfg.nBorderBottom
				,hdcMem
				,0
				,stCfg.nBorderTop
				,stCfg.nBorderLeft
				,stCfg.nBitmapY - stCfg.nBorderTop - stCfg.nBorderBottom
				,stCfg.fSkinTiled
				,CLR_TRANSPARENT
			);
		}

		// background
		OmniBlt(
			 hDC
			,stCfg.nBorderLeft
			,stCfg.nBorderTop
			,g_nSizeX - stCfg.nBorderLeft - stCfg.nBorderRight
			,g_nSizeY - stCfg.nBorderTop - stCfg.nBorderBottom
			,hdcMem
			,stCfg.nBorderLeft
			,stCfg.nBorderTop
			,stCfg.nBitmapX - stCfg.nBorderLeft - stCfg.nBorderRight
			,stCfg.nBitmapY - stCfg.nBorderTop - stCfg.nBorderBottom
			,stCfg.fSkinTiled
			,CLR_TRANSPARENT
		);

		if( stCfg.nBorderRight )
		{
			// right edge
			OmniBlt(
				 hDC
				,g_nSizeX - stCfg.nBorderRight
				,stCfg.nBorderTop
				,stCfg.nBorderRight
				,g_nSizeY - stCfg.nBorderTop - stCfg.nBorderBottom
				,hdcMem
				,stCfg.nBitmapX - stCfg.nBorderRight
				,stCfg.nBorderTop
				,stCfg.nBorderRight
				,stCfg.nBitmapY - stCfg.nBorderTop - stCfg.nBorderBottom
				,stCfg.fSkinTiled
				,CLR_TRANSPARENT
			);
		}

		if( stCfg.nBorderBottom )
		{
			// bottomleft corner
			TransBlt(
				 hDC
				,0
				,g_nSizeY - stCfg.nBorderBottom
				,stCfg.nBorderLeft
				,stCfg.nBorderBottom
				,hdcMem
				,0
				,stCfg.nBitmapY - stCfg.nBorderBottom
				,CLR_TRANSPARENT
			);

			// bottom edge
			OmniBlt(
				 hDC
				,stCfg.nBorderLeft
				,g_nSizeY - stCfg.nBorderBottom
				,g_nSizeX - stCfg.nBorderLeft - stCfg.nBorderRight
				,stCfg.nBorderBottom
				,hdcMem
				,stCfg.nBorderLeft
				,stCfg.nBitmapY - stCfg.nBorderBottom
				,stCfg.nBitmapX - stCfg.nBorderLeft - stCfg.nBorderRight
				,stCfg.nBorderBottom
				,stCfg.fSkinTiled
				,CLR_TRANSPARENT
			);

			// bottomright corner
			TransBlt(
				 hDC
				,g_nSizeX - stCfg.nBorderRight
				,g_nSizeY - stCfg.nBorderBottom
				,stCfg.nBorderRight
				,stCfg.nBorderBottom
				,hdcMem
				,stCfg.nBitmapX - stCfg.nBorderRight
				,stCfg.nBitmapY - stCfg.nBorderBottom
				,CLR_TRANSPARENT
			);
		}

		SelectObject(hdcMem, hbmOld);
		DeleteDC(hdcMem);
	}

	return TRUE;
}

//
// SystrayProc
//

LRESULT WINAPI SystrayProc( HWND hWnd, UINT nMessage, WPARAM wParam, LPARAM lParam )
{
	switch( nMessage )
	{
		case LM_GETREVID:
			//lstrcpy((char*)lParam, TEXT("Systray ")TEXT(__DATE__)TEXT(" (jugg)"));
			lstrcpy((char*)lParam, TEXT("Systray 1.10 (jugg)"));
			return lstrlen((char*)lParam);

		case LM_SYSTRAY:
			switch( wParam )
			{
			case NIM_DELETE:
				{
					PLSNOTIFYICONDATA pnid = (PLSNOTIFYICONDATA)lParam;
					PSYSTRAYICON psti;

					psti = SearchForIcon(pnid->hWnd, pnid->uID, FALSE);

					if( NULL != psti )
					{
						RemoveTrayIcon(psti);
						return TRUE;
					}
				}
				break;

			case NIM_ADD:
			case NIM_MODIFY:
				{
					PLSNOTIFYICONDATA pnid = (PLSNOTIFYICONDATA)lParam;

					if( NULL != CopyTrayIcon(pnid) )
					{
						return TRUE;
					}
				}
				break;

			case NIM_SETVERSION:
				break;

			case NIM_SETFOCUS:
				return TRUE;

			default:
				break;
			}
			return FALSE;

		case WM_CREATE:
			g_pIconList = NULL;
			g_cIcons = 0;

			g_nSizeX = 0;
			g_nSizeY = 0;

			g_fMoveTemp = FALSE;

			g_hToolTip = CreateWindowEx(
				 WS_EX_TOOLWINDOW | WS_EX_TOPMOST
				,TOOLTIPS_CLASS
				,NULL
				,TTS_ALWAYSTIP | WS_POPUP
				,0 ,0
				,0 ,0
				,hWnd
				,NULL
				,NULL
				,NULL
			);
			return 0;

		case WM_DESTROY:
			FreeTrayIconList();
			DestroyWindow(g_hToolTip);

			if( g_hbmSaved )
			{
				DeleteObject(g_hbmSaved);
				g_hbmSaved = NULL;
			}

			if( g_hbmBuffer )
			{
				DeleteObject(g_hbmBuffer);
				g_hbmBuffer = NULL;
			}

			if( g_hdcBuffer )
			{
				DeleteDC(g_hdcBuffer);
				g_hdcBuffer = NULL;
			}
			return 0;

		case WM_LBUTTONDBLCLK:
		case WM_LBUTTONDOWN:
		case WM_LBUTTONUP:
		case WM_MBUTTONDBLCLK:
		case WM_MBUTTONDOWN:
		case WM_MBUTTONUP:
		case WM_MOUSEMOVE:
		case WM_RBUTTONDBLCLK:
		case WM_RBUTTONDOWN:
		case WM_RBUTTONUP:		// whew!
		{
			PSYSTRAYICON psti = g_pIconList;
			POINT pt;
			MSG msg;

			pt.x = LOWORD(lParam);
			pt.y = HIWORD(lParam);

			msg.hwnd = hWnd;
			msg.message = nMessage;
			msg.wParam = wParam;
			msg.lParam = lParam;
			msg.time = GetTickCount();
			msg.pt = pt;

			SendMessage(g_hToolTip, TTM_RELAYEVENT, 0, (LPARAM) &msg);

			while( psti )
			{
				if( PtInRect(&psti->rc, pt) )
				{
					if( !IsWindow(psti->hWnd) )
					{
						LSNOTIFYICONDATA nid;

						nid.cbSize = sizeof(LSNOTIFYICONDATA);
						nid.hWnd = psti->hWnd;
						nid.uID = psti->uID;
						nid.uFlags = 0;

						SendMessage(hWnd, LM_SYSTRAY, NIM_DELETE, (LPARAM)&nid);
					}
					else
					{
						if( nMessage != WM_MOUSEMOVE && NULL != AllowSetForegroundWindow )
						{
							AllowSetForegroundWindow(ASFW_ANY);
						}

						PostMessage(
							 psti->hWnd
							,psti->uCallbackMessage
							,(WPARAM)psti->uID
							,(LPARAM)nMessage
						);
					}

					return 0;
				}

				psti = psti->pNext;
			}

			if( stCfg.fBorderDrag && nMessage == WM_LBUTTONDOWN )
			{
				SendMessage(hWnd, WM_SYSCOMMAND, SC_MOVE | 2, lParam);
			}

			if( nMessage == WM_RBUTTONUP )
			{
				POINT pt;

				GetCursorPos(&pt);
				PostMessage(g_hShellWnd, LM_POPUP, (WPARAM)pt.x, (LPARAM)pt.y);
			}

			return 0;
		}

		//case WM_MOUSEACTIVATE:
		//	return MA_NOACTIVATE;

		case WM_MOVE:
			if( !g_fMoveTemp )
			{
				stCfg.nX = LOWORD(lParam);
				stCfg.nY = HIWORD(lParam);

				if( stCfg.nResizeH == DIR_LEFT )
				{
					stCfg.nX = stCfg.nX + g_nSizeX;
				}

				if( stCfg.nResizeV == DIR_UP )
				{
					stCfg.nY = stCfg.nY + g_nSizeY;
				}

				if( stCfg.nSnapDistance )
				{
					if( stCfg.nResizeH == DIR_RIGHT )
					{
						if( stCfg.nX > (stCfg.nScreenCX - g_nSizeX - stCfg.nSnapDistance) )
						{
							stCfg.nX = stCfg.nScreenCX;
						}
					}

					if( stCfg.nResizeV == DIR_DOWN )
					{
						if( stCfg.nY > (stCfg.nScreenCY - g_nSizeY - stCfg.nSnapDistance) )
						{
							stCfg.nY = stCfg.nScreenCY;
						}
					}
				}
			}

			if( !stCfg.fNoTransparency )
			{
				InvalidateRect(hWnd, NULL, FALSE);
			}

			PostMessage(g_hTrayWnd, SS_NOTIFYTRAY, NT_SETTRAYMOVE, lParam);

			PositionInfoTip();
			return 0;

		case WM_EXITSIZEMOVE:
			if( stCfg.hbmSkin )
			{
				InvalidateRect(hWnd, NULL, FALSE);
			}
			return 0;

		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hDC;
			PSYSTRAYICON psti = g_pIconList;

			if( !wParam )
			{
				hDC = BeginPaint(hWnd, &ps);
			}
			else
			{
				hDC = (HDC)wParam;
			}

			g_hbmBuffer = (HBITMAP) SelectObject(g_hdcBuffer, g_hbmBuffer);

			if( !stCfg.fNoTransparency && !g_bOnWharf )
			{
				PaintDesktop(hDC);
				BitBlt(g_hdcBuffer, 0, 0, g_nSizeX, g_nSizeY, hDC, 0, 0, SRCCOPY);
			}

			SkinTray(g_hdcBuffer);

			while( psti )
			{
				if( NULL != psti->hIcon )
				{
					DrawIconEx(
						 g_hdcBuffer
						,psti->rc.left
						,psti->rc.top
						,psti->hIcon
						,stCfg.nIconSize
						,stCfg.nIconSize
						,0
						,NULL
						,DI_NORMAL
					);
				}

				psti = psti->pNext;
			}

			BitBlt(
				 hDC
				,0 ,0
				,g_nSizeX
				,g_nSizeY
				,g_hdcBuffer
				,0 ,0
				,SRCCOPY
			);

			g_hbmBuffer = (HBITMAP) SelectObject(g_hdcBuffer, g_hbmBuffer);

			if( !wParam )
			{
				EndPaint(hWnd, &ps);
			}

			return 0;
		}

		case WM_SIZE:
		{
			HDC hDC = GetDC(g_hMainWnd);

			g_nSizeX = LOWORD(lParam);
			g_nSizeY = HIWORD(lParam);

			if( !g_hdcBuffer )
			{
				g_hdcBuffer = CreateCompatibleDC(hDC);
			}

			if( g_hbmBuffer )
			{
				DeleteObject(g_hbmBuffer);
			}

			g_hbmBuffer = CreateCompatibleBitmap(hDC, g_nSizeX, g_nSizeY);

			ReleaseDC(g_hMainWnd, hDC);

			PostMessage(g_hTrayWnd, SS_NOTIFYTRAY, NT_SETTRAYSIZE, lParam);
			return 0;
		}

		case WM_WINDOWPOSCHANGING:
		{
			LPWINDOWPOS pwp = (LPWINDOWPOS) lParam;

			if( stCfg.nSnapDistance )
			{
				if( pwp->x < stCfg.nSnapDistance )
				{
					pwp->x = 0;
				}
				else if( pwp->x > (stCfg.nScreenCX - g_nSizeX - stCfg.nSnapDistance) )
				{
					pwp->x = stCfg.nScreenCX - g_nSizeX;
				}

				if( pwp->y < stCfg.nSnapDistance )
				{
					pwp->y = 0;
				}
				else if( pwp->y > (stCfg.nScreenCY - g_nSizeY - stCfg.nSnapDistance) )
				{
					pwp->y = stCfg.nScreenCY - g_nSizeY;
				}
			}

			return 0;
		}
	}

	return DefWindowProc(hWnd, nMessage, wParam, lParam);
}

/*--End Of File---------------------------------------------------------------*/
