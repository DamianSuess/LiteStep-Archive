/*------------------------------------------------------------------------------
    This is part of the the source code for "systray"; a Litestep Module.
	As a whole it implements the "icon notification area".

    Copyright (C) 1999 - 2000 Kevin Schafer
    Copyright (C) 2001 - 2004 Chris Rempel

    This program is free software; you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the Free
    Software Foundation; either version 2 of the License, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
    more details.

    You should have received a copy of the GNU General Public License along with
    this program; if not, write to the Free Software Foundation, Inc.,
    59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
------------------------------------------------------------------------------*/

////
/// system tray
//
#ifndef __SYSTRAY_H
#define __SYSTRAY_H

#include <stdio.h>
#include "../../PureLS/purels/sdk/include/lsapi.h"
#include "../../PureLS/purels/sdk/include/shelltray.h"

#ifndef NIF_INFO
#define NIF_INFO        0x00000010
#endif
#ifndef NIIF_INFO
#define NIIF_INFO       0x00000001
#endif
#ifndef NIIF_WARNING
#define NIIF_WARNING    0x00000002
#endif
#ifndef NIIF_ERROR
#define NIIF_ERROR      0x00000003
#endif

#define LM_POPUP           (9182)
#define SS_NOTIFYTRAY      (WM_APP + 500)
#define NT_SETTRAYHWND     (0)
#define NT_SETTRAYMOVE     (1)
#define NT_SETTRAYSIZE     (2)

#define LEN_TOOLTIP    128

typedef struct LSNOTIFYICONDATA
{
	DWORD cbSize;
	HWND hWnd;
	UINT uID;
	UINT uFlags;
	UINT uCallbackMessage;
	HICON hIcon;
	CHAR szTip[LEN_TOOLTIP];
} LSNOTIFYICONDATA, *PLSNOTIFYICONDATA;


#define NIM_SETFOCUS    3
#define NIM_SETVERSION  4

typedef struct _SYSTRAYICON
{
	HWND hWnd;
	UINT uID;
	UINT uCallbackMessage;
	HICON hIcon;
	UINT uToolTip;
	TCHAR szTip[LEN_TOOLTIP];
	RECT rc;
	struct _SYSTRAYICON *pNext;
} SYSTRAYICON, *PSYSTRAYICON;


#ifndef EXTERN_C
  #ifdef __cplusplus
    #define EXTERN_C extern "C"
  #else
    #define EXTERN_C extern
  #endif
#endif

#define EXPORT __declspec(dllexport)

typedef WINUSERAPI BOOL (WINAPI *FUNC_BOOL__DWORD)(DWORD);
#define ASFW_ANY    ((DWORD)-1)

//
// structures
//

typedef struct MAP {
	LPCTSTR pszName;
	UINT uValue;
} MAP, *PMAP, FAR *LPMAP;

//
// constants
//
#define WC_SHELLDESKTOP    TEXT("DesktopBackgroundClass")
#define WC_SYSTRAY         TEXT("SysTrayClass")
#define WC_INFOTIP         TEXT("SysTrayInfoTipClass")

#define CLR_TRANSPARENT    RGB(255, 0, 255)

#define DIR_LEFT           0
#define DIR_UP             1
#define DIR_RIGHT	       2
#define DIR_DOWN           3

#define CFG_NAME                 TEXT("Systray")
#define CFG_ALWAYSONTOP          TEXT("AlwaysOnTop")
#define CFG_AUTOSIZE             TEXT("AutoSize")
#define CFG_BGCOLOR              TEXT("BGColor")
#define CFG_BITMAP               TEXT("Bitmap")
#define CFG_BORDERDRAG           TEXT("BorderDrag")
#define CFG_BORDERX              TEXT("BorderX")
#define CFG_BORDERY              TEXT("BorderY")
#define CFG_COLORSATURATION      TEXT("ColorSaturation")
#define CFG_DIRECTION            TEXT("Direction")
#define CFG_HIDDEN               TEXT("Hidden")
#define CFG_HIDEIFEMPTY          TEXT("HideIfEmpty")
#define CFG_HUECOLOR             TEXT("HueColor")
#define CFG_HUEINTENSITY         TEXT("HueIntensity")
#define CFG_ICONEFFECTS          TEXT("IconEffects")
#define CFG_ICONSIZE             TEXT("IconSize")
#define CFG_MAXHEIGHT            TEXT("MaxHeight")
#define CFG_MAXWIDTH             TEXT("MaxWidth")
#define CFG_MINHEIGHT            TEXT("MinHeight")
#define CFG_MINWIDTH             TEXT("MinWidth")
#define CFG_NOTRANSPARENCY       TEXT("NoTransparency")
#define CFG_PINTODESKTOP         TEXT("PinToDesktop")
#define CFG_SHOWINFOTIPS         TEXT("ShowInfoTips")
#define CFG_SNAPDISTANCE         TEXT("SnapDistance")
#define CFG_SPACINGX             TEXT("SpacingX")
#define CFG_SPACINGY             TEXT("SpacingY")
#define CFG_WRAPCOUNT            TEXT("WrapCount")
#define CFG_X                    TEXT("X")
#define CFG_Y                    TEXT("Y")


typedef struct _SYSTRAY_CONFIG
{
	BOOL fAlwaysOnTop;
	BOOL fBorderDrag;
	BOOL fHidden;
	BOOL fNoTransparency;
	BOOL fHideIfEmpty;
	BOOL fVisible;
	BOOL fShowInfoTips;

	HBRUSH hbrBgColor;

	int nBorderX;
	int nBorderY;
	int nIconSize;
	int nX;
	int nY;
	int nSnapDistance;
	int nSpacingX;
	int nSpacingY;
	int nWrapCount;

	BOOL fIconEffects;
	COLORREF clrHue;
	int nHueIntensity;
	int nColorSaturation;

	int nMinWidth;
	int nMinHeight;
	int nMaxWidth;
	int nMaxHeight;

	HBITMAP hbmSkin;
	BOOL fSkinTiled;
	int nBitmapX;
	int nBitmapY;
	int nBorderLeft;
	int nBorderTop;
	int nBorderRight;
	int nBorderBottom;

	BOOL fHorizontal;
	int nDeltaX;
	int nDeltaY;
	int nResizeH;
	int nResizeV;

	int nScreenCX;
	int nScreenCY;

} SYSTRAY_CONFIG, *PSYSTRAY_CONFIG;

//
// variables
//
extern FUNC_BOOL__DWORD AllowSetForegroundWindow;
extern SYSTRAY_CONFIG stCfg;
extern HINSTANCE g_hMainInst;
extern HWND g_hTrayWnd;
extern HWND g_hShellWnd;
extern HWND g_hMainWnd;
extern HWND g_hParentWnd;
extern HWND g_hDesktopWnd;

extern BOOL g_bOnWharf;
extern int g_nWharfBevelWidth;

extern MAP mapDirection[];
extern MAP mapLR[];
extern MAP mapUD[];

//
// functions
//

extern LPCTSTR NextToken( LPCTSTR, LPTSTR, UINT );
extern int ParseInteger( LPCTSTR );
extern UINT MapName( PMAP, LPCTSTR, UINT );
extern BOOL GetConfigBoolean( LPCTSTR );
extern int GetConfigInteger( LPCTSTR, int, int, int );
extern void GetConfigString( LPCTSTR, LPTSTR, UINT, LPCTSTR );
extern void ReadConfig();
extern void FreeConfig();

extern LRESULT WINAPI SystrayProc( HWND, UINT, WPARAM, LPARAM );

extern void AdjustLayout();
extern void Recycle();

extern void SystrayHide( HWND, LPCTSTR );
extern void SystrayMove( HWND, LPCTSTR );
extern void SystrayShow( HWND, LPCTSTR );
extern void SystrayToggle( HWND, LPCTSTR );
extern void SystrayPinToDesktop( HWND, LPCTSTR );

extern HBITMAP LoadBitmapFile( LPCTSTR );
extern BOOL TransBlt( HDC, int, int, int, int, HDC, int, int, COLORREF );

extern BOOL CreateInfoTips(VOID);
extern VOID DeleteInfoTips(VOID);
extern BOOL SetInfoTip(PSYSTRAYICON, LPCTSTR, LPCTSTR, DWORD, UINT);
extern VOID PositionInfoTip(VOID);
extern VOID RemoveInfoTip(PSYSTRAYICON psti);

//
// API
//

#undef RtlFillMemory
#undef RtlMoveMemory
#undef RtlZeroMemory

EXTERN_C NTSYSAPI VOID NTAPI RtlFillMemory( VOID UNALIGNED *Destination, DWORD Length, BYTE Fill );
EXTERN_C NTSYSAPI VOID NTAPI RtlMoveMemory( VOID UNALIGNED *Destination, CONST VOID UNALIGNED *Source, DWORD Length );
EXTERN_C NTSYSAPI VOID NTAPI RtlZeroMemory( VOID UNALIGNED *Destination, DWORD Length );

#endif /* __SYSTRAY_H */
