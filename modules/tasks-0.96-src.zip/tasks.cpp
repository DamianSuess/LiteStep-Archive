/*------------------------------------------------------------------------------
	This Litestep module is a Task Manager implementation.

	Copyright (C) 1999-2004 Chris Rempel

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
------------------------------------------------------------------------------*/

/*---System Includes----------------------------------------------------------*/
#include <windows.h>
#include <windowsx.h> // Some convenient macros
#include <commctrl.h> // Included for ToolTips.

/*---Language Includes--------------------------------------------------------*/
#include <stdio.h>

/*---Module Includes----------------------------------------------------------*/
#include "tasks.h"

#define DEFINEUNSUPPORTEDLSMSGS
#include "../../PureLS/pls040/sdk/include/lsapi.h"

/*----------------------------------------------------------------------------*/

/*setup constants*/
//const char g_szAboutStr[] = "Tasks 0.96beta, "__DATE__" - "__TIME__" (jugg)";
const char g_szAboutStr[] = "Tasks 0.96 (jugg)";

/*setup variables*/
FUNC_VOID__HWND_BOOL fpSwitchToThisWindow;


ClassList* classTag;
IconList* iconTag;
PCLASSTITLEITEM g_pAddList;
PCLASSTITLEITEM g_pIgnoreList;
PixList* pixTag;
WrapCmdList* wrapCmd;
TaskType* tasks;
TasksSettings ts;

int numTasks;
int numClass, numIcon, numPix, numWrapCmd;
int bkUpX, bkUpY, bkDisp;

HWND g_hParentWnd;

HINSTANCE g_hDllInst;
HWND g_hMainWnd, g_hHintWnd;
ATOM g_ClassAtom, g_TasksAtom;

BOOL g_bTasksDisabled;
BOOL g_bTaskWrap, g_bBgImgNone, g_bMinBgImgNone, g_bSelBgImgNone;
HCURSOR g_hCursorNormal, g_hCursorMoving;
int g_nScreenCX, g_nScreenCY, g_nDockCX, g_nDockCY;

HWND g_hCurTask, g_hLockCurTask, g_hOldCurTask, g_hFlashingTask;
UINT g_uButtonDownMsg;
RECT g_rAllTasks;
POINTS g_oldCursorPos, g_lastPos;

/*forward declare all the functions*/
void FreeSettings( TasksSettings * const );
void ReadSettings( TasksSettings * const );
BOOL GetTasksAdd( char *, char * );
BOOL GetTasksIgnore( char *, char * );
BOOL IsAppWindow( HWND, BOOL );
BOOL IsValidWindow( HWND );
BOOL CALLBACK EnumWindowsProc( HWND, LPARAM );
BOOL StripWS( char * );
LRESULT CALLBACK MainWndProc( HWND, UINT, WPARAM, LPARAM );
LRESULT CALLBACK WndProc( HWND, UINT, WPARAM, LPARAM );
int InWinList( HWND );
BOOL IsPointInTask( int, POINTS );
int GetTaskByWnd( HWND );
int GetTaskByAppWnd( HWND );
int GetUnMovedNrTasks( int );
void CreateHints( HWND, char * );
void CreateTask( int, HWND );
void DeleteTask( int );
void FreeList( void );
void GetNewTaskPos( int );
void GetTasksClass( int );
void GetTasksIcon( int );
BOOL GetTasksPix( int );
void HideMinAppBar( HWND );
void PackList( void );
void PaintTask( HDC, int );
void FreeTasksAdd( void );
void FreeTasksIgnore( void );
void ReadTasksIcon( void );
void ReadTasksAdd( void );
void ReadTasksClass( void );
void ReadTasksIgnore( void );
void ReadTasksPix( void );
void ReadTasksWrapCmd( void );
void ReArrangeTasks( int, BOOL );
void RemoveHints( HWND );
void TaskPosition( int, int );
void UpdateTasks( void );
void UpdateHints( HWND, char * );
BOOL IsDockWindowValid( void );
/*The rest are !bang commands*/
void TasksGather( HWND, const char * );
void TasksHide( HWND, const char * );
void TasksMove( HWND, const char * );
void TasksShow( HWND, const char * );
void TasksSwitch( HWND, const char * );
void TasksToggle( HWND, const char * );
void TasksDisplay( HWND, const char * );
void TasksDockWindow( HWND, const char * );
void TaskszOrder( HWND, const char * );
void TasksMinimize( HWND, const char * );
void TasksMaximize( HWND, const char * );
void TasksRestore( HWND, const char * );
void TasksBoxHook( HWND, const char * );
void TasksDisable( HWND, const char * );
void TasksEnable( HWND, const char * );



void FreeSettings(TasksSettings * const ps)
{
	/* Macro action list */
#define DELETE_ON_ACTION(MEMBER, STRING, DEFAULT)   delete [] ps->MEMBER;
	TASKS_ON_COMMAND_LIST(DELETE_ON_ACTION)
#undef DELETE_ON_ACTION

	delete [] ps->TitleFont;
	delete [] ps->TitleMinFont;
	delete [] ps->TitleSelFont;

	if(NULL != ps->BgImage)
	{
		DeleteObject(ps->BgImage);
	}

	if(NULL != ps->MinBgImage)
	{
		DeleteObject(ps->MinBgImage);
	}

	if(NULL != ps->SelBgImage)
	{
		DeleteObject(ps->SelBgImage);
	}

	memset(ps, 0, sizeof(TasksSettings));

	return;
}

int getPosition(int const align, int const size, int const sizeto, int const border)
{
	int pos = align;

	if(0 > pos)
	{
		if(-1 == pos)
		{
			pos = border;
		}
		else if(-3 == pos)
		{
			pos = sizeto - size - border;
		}
		else /*Center the Icon for '-2' and by default for any other negative value.*/
		{
			pos = (sizeto - size) / 2;
		}

		if(0 > pos)
		{
			pos = 0;
		}
	}

	return(pos);
}

UINT parseAlignment(LPCTSTR const pszValue)
{
	UINT align = 0;

	if(strstr(pszValue, "multiline")) // multiline ignores DT_TOP/BOTTOM/VCENTER
	{
		align |= DT_WORDBREAK;
	}
	else
	{
		align |= DT_SINGLELINE; // don't allow newline characters

		if(strstr(pszValue, "middle"))
		{
			align |= DT_VCENTER;
		}
		else if(strstr(pszValue, "top"))
		{
			align |= DT_TOP;
		}
		else if(strstr(pszValue, "bottom"))
		{
			align |= DT_BOTTOM;
		}
	}

	if(strstr(pszValue, "center"))
	{
		align |= DT_CENTER;
	}
	else if(strstr(pszValue, "left"))
	{
		align |= DT_LEFT;
	}
	else if(strstr(pszValue, "right"))
	{
		align |= DT_RIGHT;
	}

	return(align);
}


void ReadSettings(TasksSettings * const ps)
{
	char tmp[MAX_LINE_LENGTH];

	*tmp = '\0';
	GetRCString("TasksDockWindow", tmp, "DesktopBackgroundClass", MAX_LINE_LENGTH);
	if(StripWS(tmp))
	{
		if(0 != _strcmpi(tmp, ".none"))
		{
			char * ptr1, * ptr2;
			ptr1 = strtok(tmp, ";");
			ptr2 = strtok(NULL, ";");
			StripWS(ptr1);
			StripWS(ptr2);
			ps->DockWindow = (ptr1 && strlen(ptr1)) ? FindWindow(ptr1, ptr2):NULL;
			if(NULL != ps->DockWindow && !IsWindow(ps->DockWindow))
			{
				ps->DockWindow = NULL;
			}
		}
	}

	if(NULL != ps->DockWindow)
	{
		RECT r;
		GetWindowRect(ps->DockWindow, &r);
		g_nDockCX = r.right - r.left;
		g_nDockCY = r.bottom - r.top;
	}
	else
	{
		g_nDockCX = g_nScreenCX;
		g_nDockCY = g_nScreenCY;
	}

	*tmp = '\0';
	GetRCString("TasksDirection", tmp, "right", 16);
			ps->Direction = 2;  /*only needed if user enters an invalid parameter*/
		if (_strcmpi(tmp, "up") == 0)
			ps->Direction = 1;
		else if (_strcmpi(tmp, "right") == 0)
			ps->Direction = 2;
		else if (_strcmpi(tmp, "down") == 0)
			ps->Direction = 3;
		else if (_strcmpi(tmp, "left") == 0)
			ps->Direction = 4;

	*tmp = '\0';
	GetRCString("TasksDisplay", tmp, "all", 256);
		ps->Display = MASK_NONE;
		if (tmp && strlen(tmp)){
			_strlwr(tmp); // convert to lower case, since there is no 'strstr' case insensitive routine.
			if (strstr(tmp, "all"))
				ps->Display = MASK_ALL;
			else{ // no real reason to do this, but just that much less processing to do on startup.
				if (strstr(tmp, "normal"))
					ps->Display |= MASK_NORMAL;
				if (strstr(tmp, "minimized"))
					ps->Display |= MASK_MINIMIZED;
				if (strstr(tmp, "selected"))
					ps->Display |= MASK_SELECTED;
			}
		}
		if (ps->Display == MASK_NONE) ps->Display = MASK_ALL;  // if they put in something bogus, lets just default to 'all'
		bkDisp = ps->Display;

	*tmp = '\0';
	GetRCString("TasksTransparency", tmp, "fake", 16);
			ps->Transparency = 1;  /*only needed if user enters an invalid parameter*/
		if (_strcmpi(tmp, "none") == 0)
			ps->Transparency = 0;
		else if (_strcmpi(tmp, "fake") == 0)
			ps->Transparency = 1;
		else if (_strcmpi(tmp, "real") == 0)
			ps->Transparency = 2;

	*tmp = '\0';
	GetRCString("TaskszOrder", tmp, "floating", 16);
			ps->zOrder = 1;  /*only needed if user enters an invalid parameter*/
		if (_strcmpi(tmp, "floating") == 0)
			ps->zOrder = 1;
		else if (_strcmpi(tmp, "ontop") == 0)
			ps->zOrder = 2;

	ps->DragDistance = GetRCInt("TasksDragDistance", 4);
		if (ps->DragDistance < 0) ps->DragDistance = 4;
	ps->MaxTiles = GetRCInt("TasksMaxTiles", 0);
		if (ps->MaxTiles < 0) ps->MaxTiles = 0;
	ps->SetTimer = GetRCInt("TasksSetTimer", 250);
		if (ps->SetTimer < 250) ps->SetTimer = 250;
	ps->SpacingX = GetRCInt("TasksSpacingX", 0);
	ps->SpacingY = GetRCInt("TasksSpacingY", 0);
	ps->WrapCount = GetRCInt("TasksWrapCount", 0);
		g_bTaskWrap = ps->WrapCount > 0 || ps->WrapCount == -1;

	*tmp = '\0';
	GetRCString("TasksWrapDirection", tmp, "down", 10); // the largest size is 5, but in case of typo's or something...
			ps->WrapDirection = 3;  /*only needed if user enters an invalid parameter*/
		if (_strcmpi(tmp, "up") == 0)
			ps->WrapDirection = 1;
		else if (_strcmpi(tmp, "right") == 0)
			ps->WrapDirection = 2;
		else if (_strcmpi(tmp, "down") == 0)
			ps->WrapDirection = 3;
		else if (_strcmpi(tmp, "left") == 0)
			ps->WrapDirection = 4;

	ps->Height = GetRCInt("TasksHeight", 32);
		if (ps->Height < 2) ps->Height = 32;
	ps->Width = GetRCInt("TasksWidth", 32);
		if (ps->Width < 2) ps->Width = 32;

	/* Don't use GetRCCoordinate!!! */ 
	ps->X = bkUpX = GetRCInt("TasksX", 0);
		if(0 > ps->X || (0 == ps->X && (4 == ps->Direction || (4 == ps->WrapDirection && g_bTaskWrap))))
			ps->X += g_nDockCX;
	ps->Y = bkUpY = GetRCInt("TasksY", 0);
		if(0 > ps->Y || (0 == ps->Y && (1 == ps->Direction || (1 == ps->WrapDirection && g_bTaskWrap))))
			ps->Y += g_nDockCY;

	ps->IconSize = GetRCInt("TasksIconSize", 16);
		if (ps->IconSize < 2) ps->IconSize = 16;

	ps->IconX = getPosition(GetRCInt("TasksIconX", -2), ps->IconSize, ps->Width, 1);
	ps->MinIconX = getPosition(GetRCInt("TasksMinIconX", ps->IconX), ps->IconSize, ps->Width, 1);
	ps->SelIconX = getPosition(GetRCInt("TasksSelIconX", ps->IconX), ps->IconSize, ps->Width, 1);

	ps->IconY = getPosition(GetRCInt("TasksIconY", -2), ps->IconSize, ps->Height, 1);
	ps->MinIconY = getPosition(GetRCInt("TasksMinIconY", ps->IconY), ps->IconSize, ps->Height, 1);
	ps->SelIconY = getPosition(GetRCInt("TasksSelIconY", ps->IconY), ps->IconSize, ps->Height, 1);

	ps->PixX = GetRCInt("TasksPixX", 1);
	ps->MinPixX = GetRCInt("TasksMinPixX", ps->PixX);
	ps->SelPixX = GetRCInt("TasksSelPixX", ps->PixX);

	ps->PixY = GetRCInt("TasksPixY", 1);
	ps->MinPixY = GetRCInt("TasksMinPixY", ps->PixY);
	ps->SelPixY = GetRCInt("TasksSelPixY", ps->PixY);

	ps->AutoArrange = GetRCBool("TasksAutoArrange", TRUE);
	ps->HideMinAppBar = GetRCBool("TasksHideMinAppBar", TRUE);
	ps->MoveAll = GetRCBool("TasksMoveAll", TRUE);
	ps->NoMinimizeOnClick = GetRCBool("TasksNoMinimizeOnClick", TRUE);
	ps->NoMove = GetRCBool("TasksNoMove", TRUE);
	ps->Sort = GetRCBool("TasksSort", TRUE);
	ps->StartHidden = GetRCBool("TasksStartHidden", TRUE);
	ps->UseSystemHook = GetRCBool("TasksUseSystemHook", TRUE);
	ps->UseVWMSwitching = GetRCBool("TasksUseVWMSwitching", TRUE);
	ps->UseVWMDisplay = GetRCBool("TasksVWMCurrentDesktopOnly", TRUE);
	ps->StartDisabled = GetRCBool("TasksStartDisabled", TRUE);

	ps->NoHints = GetRCBool("TasksNoHints", TRUE);
	ps->NoIcons = GetRCBool("TasksNoIcons", TRUE);
	ps->HighLightMinimized = GetRCBool("TasksHighLightMinimized", TRUE);
	ps->HighLightSelected = GetRCBool("TasksHighLightSelected", TRUE);
	ps->UseWindowsSettings = GetRCBool("TasksUseWindowsSettings", TRUE);

	ps->BgColor = GetRCColor("TasksBgColor", 0xFF00FF);
	ps->MinBgColor = GetRCColor("TasksMinBgColor", ps->BgColor);
	ps->SelBgColor = GetRCColor("TasksSelBgColor", ps->BgColor);

	ps->DarkColor = GetRCColor("TasksDarkColor", 0xFF00FF);
	ps->MinDarkColor = GetRCColor("TasksMinDarkColor", ps->DarkColor);
	ps->SelDarkColor = GetRCColor("TasksSelDarkColor", ps->DarkColor);

	ps->LightColor = GetRCColor("TasksLightColor", 0xFF00FF);
	ps->MinLightColor = GetRCColor("TasksMinLightColor", ps->LightColor);
	ps->SelLightColor = GetRCColor("TasksSelLightColor", ps->LightColor);

	ps->bHueIcons = GetRCBool("TasksHueIcons", TRUE);

	ps->HueColor = GetRCColor("TasksIconHueColor", 0x808080);
	ps->MinHueColor = GetRCColor("TasksMinIconHueColor", ps->HueColor);
	ps->SelHueColor = GetRCColor("TasksSelIconHueColor", ps->HueColor);

	ps->HueIntensity = (UCHAR)min(max(GetRCInt("TasksIconHueIntensity", 128), 0), 255);
	ps->MinHueIntensity = (UCHAR)min(max(GetRCInt("TasksMinIconHueIntensity", ps->HueIntensity), 0), 255);
	ps->SelHueIntensity = (UCHAR)min(max(GetRCInt("TasksSelIconHueIntensity", ps->HueIntensity), 0), 255);

	ps->HueSaturation = (UCHAR)min(max(GetRCInt("TasksIconHueSaturation", 0), 0), 255);
	ps->MinHueSaturation = (UCHAR)min(max(GetRCInt("TasksMinIconHueSaturation", ps->HueSaturation), 0), 255);
	ps->SelHueSaturation = (UCHAR)min(max(GetRCInt("TasksSelIconHueSaturation", ps->HueSaturation), 0), 255);

	*tmp = '\0';
	GetRCString("TasksBgImage", tmp, ".none", MAX_LINE_LENGTH);
			g_bBgImgNone = TRUE;
		if (_strcmpi(".none", tmp))
		{
			ps->BgImage = LoadLSImage(tmp, NULL);
			g_bBgImgNone = FALSE;
		}
		else
			ps->BgImage = NULL;

	*tmp = '\0';
	GetRCString("TasksMinBgImage", tmp, "", MAX_LINE_LENGTH); /*By using "" as the default, it uses the TasksBackImage.*/
			g_bMinBgImgNone = FALSE;
		if (_strcmpi(".none", tmp))
			ps->MinBgImage = LoadLSImage(tmp, NULL);
		else
		{
			ps->MinBgImage = NULL;
			g_bMinBgImgNone = TRUE;
		}

	*tmp = '\0';
	GetRCString("TasksSelBgImage", tmp, "", MAX_LINE_LENGTH); /*By using "" as the default, it uses the TasksBackImage.*/
			g_bSelBgImgNone = FALSE;
		if (_strcmpi(".none", tmp))
			ps->SelBgImage = LoadLSImage(tmp, NULL);
		else
		{
			ps->SelBgImage = NULL;
			g_bSelBgImgNone = TRUE;
		}

	/*The default Title settings here align it centered along the bottom of a 32x32 tile.*/
	ps->TitleHeight = GetRCInt("TasksTitleHeight", 12);
		if (ps->TitleHeight < 2) ps->TitleHeight = 12;
	ps->TitleMinHeight = GetRCInt("TasksTitleMinHeight", ps->TitleHeight);
		if (ps->TitleMinHeight < 2) ps->TitleMinHeight = ps->TitleHeight;
	ps->TitleSelHeight = GetRCInt("TasksTitleSelHeight", ps->TitleHeight);
		if (ps->TitleSelHeight < 2) ps->TitleSelHeight = ps->TitleHeight;

	ps->TitleWidth = GetRCInt("TasksTitleWidth", 28);
		if (ps->TitleWidth < 2) ps->TitleWidth = 28;
	ps->TitleMinWidth = GetRCInt("TasksTitleMinWidth", ps->TitleWidth);
		if (ps->TitleMinWidth < 2) ps->TitleMinWidth = ps->TitleWidth;
	ps->TitleSelWidth = GetRCInt("TasksTitleSelWidth", ps->TitleWidth);
		if (ps->TitleSelWidth < 2) ps->TitleSelWidth = ps->TitleWidth;

	ps->TitleX = getPosition(GetRCInt("TasksTitleX", -2), ps->TitleWidth, ps->Width, 1);
	ps->TitleMinX = getPosition(GetRCInt("TasksTitleMinX", ps->TitleX), ps->TitleMinWidth, ps->Width, 1);
	ps->TitleSelX = getPosition(GetRCInt("TasksTitleSelX", ps->TitleX), ps->TitleSelWidth, ps->Width, 1);

	ps->TitleY = getPosition(GetRCInt("TasksTitleY", -3), ps->TitleHeight, ps->Height, 1);
	ps->TitleMinY = getPosition(GetRCInt("TasksTitleMinY", ps->TitleY), ps->TitleMinHeight, ps->Height, 1);
	ps->TitleSelY = getPosition(GetRCInt("TasksTitleSelY", ps->TitleY), ps->TitleSelHeight, ps->Height, 1);

	ps->TitleIconX = getPosition(GetRCInt("TasksTitleIconX", -2), ps->IconSize, ps->Width, 1);
	ps->TitleMinIconX = getPosition(GetRCInt("TasksTitleMinIconX", ps->TitleIconX), ps->IconSize, ps->Width, 1);
	ps->TitleSelIconX = getPosition(GetRCInt("TasksTitleSelIconX", ps->TitleIconX), ps->IconSize, ps->Width, 1);

	ps->TitleIconY = getPosition(GetRCInt("TasksTitleIconY", -1), ps->IconSize, ps->Height, 1);
	ps->TitleMinIconY = getPosition(GetRCInt("TasksTitleMinIconY", ps->TitleIconY), ps->IconSize, ps->Height, 1);
	ps->TitleSelIconY = getPosition(GetRCInt("TasksTitleSelIconY", ps->TitleIconY), ps->IconSize, ps->Height, 1);

	ps->TitlePixX = GetRCInt("TasksTitlePixX", 1);
	ps->TitleMinPixX = GetRCInt("TasksTitleMinPixX", ps->TitlePixX);
	ps->TitleSelPixX = GetRCInt("TasksTitleSelPixX", ps->TitlePixX);

	ps->TitlePixY = GetRCInt("TasksTitlePixY", 1);
	ps->TitleMinPixY = GetRCInt("TasksTitleMinPixY", ps->TitlePixY);
	ps->TitleSelPixY = GetRCInt("TasksTitleSelPixY", ps->TitlePixY);

	ps->TitleOldFontSize = GetRCBool("TasksUseOldFontSizes", TRUE);

	ps->TitleFontSize = GetRCInt("TasksTitleFontSize", 7);
		if (ps->TitleFontSize < 2) ps->TitleFontSize = 7;
	ps->TitleMinFontSize = GetRCInt("TasksTitleMinFontSize", ps->TitleFontSize);
		if (ps->TitleMinFontSize < 2) ps->TitleMinFontSize = ps->TitleFontSize;
	ps->TitleSelFontSize = GetRCInt("TasksTitleSelFontSize", ps->TitleFontSize);
		if (ps->TitleSelFontSize < 2) ps->TitleSelFontSize = ps->TitleFontSize;

	ps->Titles = GetRCBool("TasksTitles", TRUE);
	ps->TitleMinimized = GetRCBool("TasksTitleMinimized", TRUE);
	ps->TitleSelected = GetRCBool("TasksTitleSelected", TRUE);

	ps->TitleItalicize = GetRCBool("TasksTitleItalicize", TRUE);
	ps->TitleMinItalicize = GetRCBool("TasksTitleMinItalicize", TRUE);
	ps->TitleSelItalicize = GetRCBool("TasksTitleSelItalicize", TRUE);

	ps->TitleNoEllipsis = GetRCBool("TasksTitleNoEllipsis", TRUE);
	ps->TitleMinNoEllipsis = GetRCBool("TasksTitleMinNoEllipsis", TRUE);
	ps->TitleSelNoEllipsis = GetRCBool("TasksTitleSelNoEllipsis", TRUE);

	ps->TitleUnderline = GetRCBool("TasksTitleUnderline", TRUE);
	ps->TitleMinUnderline = GetRCBool("TasksTitleMinUnderline", TRUE);
	ps->TitleSelUnderline = GetRCBool("TasksTitleSelUnderline", TRUE);

	ps->TitleBold = GetRCBool("TasksTitleBold", TRUE);
	ps->TitleMinBold = GetRCBool("TasksTitleMinBold", TRUE);
	ps->TitleSelBold = GetRCBool("TasksTitleSelBold", TRUE);

	*tmp = '\0';
	GetRCString("TasksTitleAlignment", tmp, "", 256);
		if(0 != *tmp)
		{
			_strlwr(tmp); // convert to lower case, since there is no 'strstr' case insensitive routine.
			ps->TitleAlignment = parseAlignment(tmp);
		}
		else
		{
			ps->TitleAlignment = DT_SINGLELINE|DT_TOP|DT_LEFT;
		}

	*tmp = '\0';
	GetRCString("TasksTitleMinAlignment", tmp, "", 256);
		if(0 != *tmp)
		{
			_strlwr(tmp); // convert to lower case, since there is no 'strstr' case insensitive routine.
			ps->TitleMinAlignment = parseAlignment(tmp);
		}
		else
		{
			ps->TitleMinAlignment = ps->TitleAlignment;
		}

	*tmp = '\0';
	GetRCString("TasksTitleSelAlignment", tmp, "", 256);
		if(0 != *tmp)
		{
			_strlwr(tmp); // convert to lower case, since there is no 'strstr' case insensitive routine.
			ps->TitleSelAlignment = parseAlignment(tmp);
		}
		else
		{
			ps->TitleSelAlignment = ps->TitleAlignment;
		}

	ps->TitleBgColor = GetRCColor("TasksTitleBgColor", 0xFF00FF);
	ps->TitleMinBgColor = GetRCColor("TasksTitleMinBgColor", ps->TitleBgColor);
	ps->TitleSelBgColor = GetRCColor("TasksTitleSelBgColor", ps->TitleBgColor);

	ps->TitleDarkColor = GetRCColor("TasksTitleDarkColor", 0xFF00FF);
	ps->TitleMinDarkColor = GetRCColor("TasksTitleMinDarkColor", ps->TitleDarkColor);
	ps->TitleSelDarkColor = GetRCColor("TasksTitleSelDarkColor", ps->TitleDarkColor);

	ps->TitleFontColor = GetRCColor("TasksTitleFontColor", 0xC0C0C0); /*'C0C0C0' is a light gray*/
	ps->TitleMinFontColor = GetRCColor("TasksTitleMinFontColor", ps->TitleFontColor);
	ps->TitleSelFontColor = GetRCColor("TasksTitleSelFontColor", ps->TitleFontColor);

	ps->TitleLightColor = GetRCColor("TasksTitleLightColor", 0xFF00FF);
	ps->TitleMinLightColor = GetRCColor("TasksTitleMinLightColor", ps->TitleLightColor);
	ps->TitleSelLightColor = GetRCColor("TasksTitleSelLightColor", ps->TitleLightColor);

	*tmp = '\0';
	GetRCString("TasksTitleFont", tmp, "Tahoma", MAX_LINE_LENGTH);
	ps->TitleFont = new char[strlen(tmp)+1];
	strcpy(ps->TitleFont, tmp);
	*tmp = '\0';
	GetRCString("TasksTitleMinFont", tmp, ps->TitleFont, MAX_LINE_LENGTH);
	ps->TitleMinFont = new char[strlen(tmp)+1];
	strcpy(ps->TitleMinFont, tmp);
	*tmp = '\0';
	GetRCString("TasksTitleSelFont", tmp, ps->TitleFont, MAX_LINE_LENGTH);
	ps->TitleSelFont = new char[strlen(tmp)+1];
	strcpy(ps->TitleSelFont, tmp);


  /* using macro to avoid typos */ 
  /* it would probably be better to write a function for this, but */ 
  /* I guess I'm just trying to somewhat stick with the style [rc] */ 
#define GET_ON_ACTION(MEMBER, STRING, DEFAULT)             \
	*tmp = '\0';                                           \
	GetRCLine(STRING, tmp, MAX_LINE_LENGTH, DEFAULT);      \
	if(0 != *tmp)                                          \
	{                                                      \
		ps->MEMBER = new char[strlen(tmp)+1];              \
		strcpy(ps->MEMBER, tmp);                           \
	}                                                      \
	else                                                   \
	{                                                      \
		ps->MEMBER = NULL;                                 \
	}

	TASKS_ON_COMMAND_LIST(GET_ON_ACTION)
#undef GET_ON_ACTION

	return;
}

void unloadSetup( void )
{
	int i;

	if(NULL != g_hHintWnd)
	{
		DestroyWindow(g_hHintWnd);
		g_hHintWnd = NULL;
	}

	if(NULL != wrapCmd)
	{
		for(i = 0; i < numWrapCmd; i++)
		{
			delete [] wrapCmd[i].cmd;
		}

		free(wrapCmd);

		wrapCmd = NULL;
		numWrapCmd = 0;
	}

	if(NULL != pixTag)
	{
		for(i = 0; i < numPix; i++)
		{
			delete [] pixTag[i].match;
			delete [] pixTag[i].pix;
		}

		free(pixTag);

		pixTag = NULL;
		numPix = 0;
	}

	if(NULL != iconTag)
	{
		for(i = 0; i < numIcon; i++)
		{
			delete [] iconTag[i].match;
			delete [] iconTag[i].name;
		}

		free(iconTag);

		iconTag = NULL;
		numIcon = 0;
	}

	FreeTasksAdd();
	FreeTasksIgnore();

	if(NULL != classTag)
	{
 		for(i = 0; i < numClass; i++)
		{
 			delete [] classTag[i].match;
 			delete [] classTag[i].name;
 		}

		free(classTag);

		classTag = NULL;
		numClass = 0;
 	}

	if(ts.HideMinAppBar)
	{
		ArrangeIconicWindows(GetDesktopWindow());
	}

	FreeSettings(&ts);

	return;
}

void loadSetup( void )
{
	ReadSettings(&ts);

	if (!ts.NoIcons)
	{
		ReadTasksIcon();
	}

	ReadTasksClass();
	ReadTasksAdd();
	ReadTasksIgnore();
	ReadTasksPix();
	ReadTasksWrapCmd();

	if(!ts.NoHints)
	{
		g_hHintWnd = CreateWindowEx(
			 WS_EX_TOPMOST
			,TOOLTIPS_CLASS
			,NULL
			,WS_POPUP|TTS_NOPREFIX|TTS_ALWAYSTIP
			,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT
			,NULL
			,NULL
			,g_hDllInst
			,NULL
		);

		if(NULL == g_hHintWnd)
		{
			MessageBox(NULL, "Error creating ToolTip Window. ToolTips are now disabled!", "Tasks", MB_OK|MB_ICONERROR|MB_DEFBUTTON1|MB_SYSTEMMODAL);
			ts.NoHints = TRUE;
		}
	}

	return;
}

void unregisterEvents( void )
{
	UINT uBaseMsgs[] = \
	{
		 LM_GETREVID
		,LM_REFRESH
		,0
	};

	SendMessage(
		 g_hParentWnd
		,LM_UNREGISTERMESSAGE
		,(WPARAM)g_hMainWnd
		,(LPARAM)uBaseMsgs
	);

	if(ts.UseVWMDisplay)
	{
		UINT uMsgs[] = { 9370, 0 };

		SendMessage(
			 g_hParentWnd
			,LM_UNREGISTERMESSAGE
			,(WPARAM)g_hMainWnd
			,(LPARAM)uMsgs
		);
	}

	if(ts.UseSystemHook)
	{
		UINT uMsgs[] = \
		{
			 LM_WINDOWCREATED
			,LM_WINDOWDESTROYED
			,LM_WINDOWACTIVATED
			,LM_REDRAW
			,0
		};

		SendMessage(
			 g_hParentWnd
			,LM_UNREGISTERMESSAGE
			,(WPARAM)g_hMainWnd
			,(LPARAM)uMsgs
		);
	}
	else
	{
		KillTimer(g_hMainWnd, TMR_UPDATE);
	}

	return;
}

bool registerEvents( void )
{
	UINT uBaseMsgs[] = \
	{
		 LM_GETREVID
		,LM_REFRESH
		,0
	};

	SendMessage(
		 g_hParentWnd
		,LM_REGISTERMESSAGE
		,(WPARAM)g_hMainWnd
		,(LPARAM)uBaseMsgs
	);

	if(ts.UseVWMDisplay)
	{
		UINT uMsgs[] = { 9370, 0 };

		SendMessage(
			 g_hParentWnd
			,LM_REGISTERMESSAGE
			,(WPARAM)g_hMainWnd
			,(LPARAM)uMsgs
		);
	}

	if(ts.UseSystemHook)
	{
		UINT uMsgs[] = \
		{
			 LM_WINDOWCREATED
			,LM_WINDOWDESTROYED
			,LM_WINDOWACTIVATED
			,LM_REDRAW
			,0
		};

		SendMessage(
			 g_hParentWnd
			,LM_REGISTERMESSAGE
			,(WPARAM)g_hMainWnd
			,(LPARAM)uMsgs
		);
	}
	else if(0 == SetTimer(g_hMainWnd, TMR_UPDATE, ts.SetTimer, (TIMERPROC)NULL))
	{
		return(false);
	}

	return(true);
}

int initModuleEx(HWND hWnd, HINSTANCE hInst, const char* /*szPath*/)
{
	WNDCLASS wc;

	fpSwitchToThisWindow = (FUNC_VOID__HWND_BOOL)GetProcAddress(
		 GetModuleHandle(_T("USER32"))
		,"SwitchToThisWindow"
	);

	/* Store some globals */
	g_hDllInst = hInst;
	g_hParentWnd = hWnd;

	g_nScreenCX = GetSystemMetrics(SM_CXSCREEN);
	g_nScreenCY = GetSystemMetrics(SM_CYSCREEN);
	g_uButtonDownMsg = 0;

	g_hCursorMoving = LoadCursor(NULL, IDC_UPARROW);
	g_hCursorNormal = LoadCursor(NULL, IDC_ARROW);

	/* Register window classes */
	memset(&wc, 0, sizeof(wc));

	wc.hInstance = g_hDllInst;
	wc.lpfnWndProc = WndProc;
	wc.lpszClassName = "Tasks";
	wc.style = CS_NOCLOSE;

	g_TasksAtom = RegisterClass(&wc);

	if(0 == g_TasksAtom)
	{
		MessageBox(NULL,"Error registering window class","Tasks",MB_OK|MB_ICONERROR|MB_DEFBUTTON1|MB_SYSTEMMODAL);
		quitModule(g_hDllInst);
		return -1;
	}

	memset(&wc, 0, sizeof(wc));

	wc.hInstance = g_hDllInst;
	wc.lpfnWndProc = MainWndProc;
	wc.lpszClassName = "TasksClass";
	wc.style = CS_NOCLOSE;

	g_ClassAtom = RegisterClass(&wc);

	if(0 == g_ClassAtom)
	{
		MessageBox(NULL,"Error registering message window class","Tasks",MB_OK|MB_ICONERROR|MB_DEFBUTTON1|MB_SYSTEMMODAL);
		quitModule(g_hDllInst);
		return -1;
	}

	/* Create the main communication window */
	g_hMainWnd = CreateWindowEx(WS_EX_TOOLWINDOW, "TasksClass"/*MAKEINTATOM(g_ClassAtom)*/, "", WS_POPUP, 0,0,0,0, NULL, NULL, g_hDllInst, NULL);
	if(NULL == g_hMainWnd)
	{
		MessageBox(NULL,"Error creating message window","Tasks",MB_OK|MB_ICONERROR|MB_DEFBUTTON1|MB_SYSTEMMODAL);
		quitModule(g_hDllInst);
		return -1;
	}

	/* Load user configurable settings */
	loadSetup();

	/* Register shell messages.  Only returns false if we are using the timer, and the timer creation fails */
	if(!registerEvents())
	{
		MessageBox(NULL,"Error creating update Timer!\nCan not continue to load.","Tasks",MB_OK|MB_ICONERROR|MB_DEFBUTTON1|MB_SYSTEMMODAL);
		quitModule(g_hDllInst);
		return(-1);
	}

	/* Add our bang commands */
	AddBangCommand("!TASKSGATHER", TasksGather);
	AddBangCommand("!TASKSHIDE", TasksHide);
	AddBangCommand("!TASKSMOVE", TasksMove);
	AddBangCommand("!TASKSSHOW", TasksShow);
	AddBangCommand("!TASKSSWITCH", TasksSwitch);
	AddBangCommand("!TASKSTOGGLE", TasksToggle);
	AddBangCommand("!TASKSDISPLAY", TasksDisplay);
	AddBangCommand("!TASKSDOCKWINDOW", TasksDockWindow);
	AddBangCommand("!TASKSZORDER", TaskszOrder);
	AddBangCommand("!TASKSMINIMIZE", TasksMinimize);
	AddBangCommand("!TASKSMAXIMIZE", TasksMaximize);
	AddBangCommand("!TASKSRESTORE", TasksRestore);
	AddBangCommand("!TASKSBOXHOOK", TasksBoxHook);
	AddBangCommand("!TASKSENABLE", TasksEnable);
	AddBangCommand("!TASKSDISABLE", TasksDisable);

	/*
	 * Immediately add and update tasks, instead of
	 * waiting for the first round of the timer.
	 */
	g_bTasksDisabled = TRUE;
	if(!ts.StartDisabled)
	{
		TasksEnable(NULL, NULL);
	}

	/* Execute "onInit" command */
	LSExecute(g_hMainWnd, ts.OnInit, 0);

	return 0;
}

void quitModule(HINSTANCE hInst)
{
	/* First execute "onQuit" command before unloading. */
	LSExecute(g_hMainWnd, ts.OnQuit, 0);

	/* Then shutdown external interaction before anything else. */
	RemoveBangCommand("!TASKSGATHER");
	RemoveBangCommand("!TASKSHIDE");
	RemoveBangCommand("!TASKSMOVE");
	RemoveBangCommand("!TASKSSHOW");
	RemoveBangCommand("!TASKSSWITCH");
	RemoveBangCommand("!TASKSTOGGLE");
	RemoveBangCommand("!TASKSDISPLAY");
	RemoveBangCommand("!TASKSDOCKWINDOW");
	RemoveBangCommand("!TASKSZORDER");
	RemoveBangCommand("!TASKSMINIMIZE");
	RemoveBangCommand("!TASKSMAXIMIZE");
	RemoveBangCommand("!TASKSRESTORE");
	RemoveBangCommand("!TASKSBOXHOOK");
	RemoveBangCommand("!TASKSENABLE");
	RemoveBangCommand("!TASKSDISABLE");

	if(0 != g_ClassAtom)
	{
		if(NULL != g_hMainWnd)
		{
			unregisterEvents();

			DestroyWindow(g_hMainWnd);
			g_hMainWnd = NULL;
		}

		UnregisterClass(MAKEINTATOM(g_ClassAtom), hInst);
		g_ClassAtom = 0;
	}

	/* Free tasks and associated internal resources */
	if(0 != g_TasksAtom)
	{
		TasksDisable(NULL, NULL);

		UnregisterClass(MAKEINTATOM(g_TasksAtom), hInst);
		g_TasksAtom = 0;
	}

	/* Finally, unload user defined resources */
	unloadSetup();

	return;
}

void SwitchToWnd(const HWND hWnd)
{
	HWND hWnd2 = GetLastActivePopup(hWnd);

	if(
		!ts.UseVWMSwitching
		||
		!SendMessage(
			 g_hParentWnd
			,LM_BRINGTOFRONT
			,0
			,(LPARAM)hWnd2
		)
	)
	{
		if(NULL != fpSwitchToThisWindow)
		{
			fpSwitchToThisWindow(hWnd2, TRUE);
		}
		else
		{
			SetForegroundWindow(hWnd2);
		}
	}

	return;
}

void SwitchToTasksWnd(const int nTask)
{
	HWND hWnd = tasks[nTask].appHandle;
	HWND hWnd2 = GetLastActivePopup(hWnd);

	if(!IsAppWindow(hWnd2, FALSE))
	{
		hWnd = hWnd2;
	}

	if(
		!ts.UseVWMSwitching
		||
		!SendMessage(
			 g_hParentWnd
			,LM_BRINGTOFRONT
			,0
			,(LPARAM)hWnd
		)
	)
	{
		if(NULL != fpSwitchToThisWindow)
		{
			fpSwitchToThisWindow(hWnd, TRUE);
		}
		else
		{
			SetForegroundWindow(hWnd);
		}
	}

	return;
}

void ShowWindowSysMenu(const int nTask, const DWORD dwPos)
{
	HWND hWnd = tasks[nTask].appHandle;

	if(tasks[nTask].IsIconic)
	{
		if(NULL != fpSwitchToThisWindow)
		{
			fpSwitchToThisWindow(hWnd, FALSE);
		}
		else
		{
			SetForegroundWindow(hWnd);
		}
	}
	else
	{
		SwitchToTasksWnd(nTask);
	}

	Sleep(130);

	PostMessage(hWnd, 0x313, 0, dwPos);

	return;
}

BOOL GetTasksAdd(char * pClass, char * pTitle)
{
	PCLASSTITLEITEM pcti;

	for(pcti = g_pAddList; NULL != pcti; pcti = pcti->pNext)
	{
		if(match(pcti->szClass, pClass) && match(pcti->szTitle, pTitle))
		{
			return TRUE;
		}
	}

	return FALSE;
}

BOOL GetTasksIgnore(char * pClass, char * pTitle)
{
	PCLASSTITLEITEM pcti;

	if(match("WindowsScreenSaverClass", pClass) || match("tooltips_class32", pClass))
	{
		return(TRUE);
	}

	for(pcti = g_pIgnoreList; NULL != pcti; pcti = pcti->pNext)
	{
		if(match(pcti->szClass, pClass) && match(pcti->szTitle, pTitle))
		{
			return TRUE;
		}
	}

	return FALSE;
}

BOOL IsDockWindowValid( void )
{
	if(NULL != ts.DockWindow && !IsWindow(ts.DockWindow))
	{
		ts.DockWindow = NULL;

		g_nDockCX = g_nScreenCX;
		g_nDockCY = g_nScreenCY;

		FreeList();

		g_hCurTask = g_hLockCurTask = g_hOldCurTask = g_hFlashingTask = NULL;

		ts.X = bkUpX;
		ts.Y = bkUpY;

		if(0 > ts.X || (0 == ts.X && (4 == ts.Direction || (4 == ts.WrapDirection && g_bTaskWrap))))
			ts.X += g_nDockCX;
		if(0 > ts.Y || (0 == ts.Y && (1 == ts.Direction || (1 == ts.WrapDirection && g_bTaskWrap))))
			ts.Y += g_nDockCY;

		return(FALSE);
	}

	return(TRUE);
}

BOOL CALLBACK EnumWindowsProc(HWND hWnd, LPARAM lParam)
{
	if(0 != ts.MaxTiles && numTasks == ts.MaxTiles)
	{
		return(FALSE);
	}

	if(IsWindow(hWnd) && !InWinList(hWnd))
	{
		if(IsValidWindow(hWnd))
		{
			TaskType *tmpTasks = NULL;

			if(NULL == tasks)
			{
				tasks = (TaskType *)malloc(sizeof(TaskType));
			}
			else
			{
				tmpTasks = tasks;
				tasks = (TaskType *)realloc(tasks, (numTasks+1)*sizeof(TaskType));
			}

			if(NULL == tasks)
			{
				tasks = tmpTasks;
				return(FALSE);
			}

			memset(&tasks[numTasks], 0, sizeof(TaskType));
			CreateTask(numTasks, hWnd);
		}
		else if(ts.HideMinAppBar && IsWindowVisible(hWnd) && IsIconic(hWnd))
		{
			HideMinAppBar(hWnd);
		}
	}

	return(TRUE);
	UNREFERENCED_PARAMETER(lParam);
}

BOOL IsAppWindow(HWND hWnd, BOOL bChkOwner)
{
	BOOL bResult = (
		IsWindow(hWnd)
		&&
		IsWindowVisible(hWnd)
		&&
		NULL == GetParent(hWnd)
		&&
		0x49474541 != GetWindowLong(hWnd, GWL_USERDATA) /*ignore shell windows (magicDWord)*/
	);

	if(bResult)
	{
		DWORD dwExStyle = GetWindowExStyle(hWnd);

		if(
			WS_EX_APPWINDOW != (WS_EX_APPWINDOW & dwExStyle)
			&&
			(
				WS_EX_TOOLWINDOW == (WS_EX_TOOLWINDOW & dwExStyle)
				||
				(
					bChkOwner
					&&
					NULL != GetWindowOwner(hWnd)
				)
			)
		)
		{
			bResult = FALSE;
		}
	}

	return(bResult);
}

BOOL IsValidWindow(HWND hWnd)
{
	BOOL bResult = FALSE;

	if(IsWindow(hWnd))
	{
		int maskVal = MASK_NONE;

		maskVal |= hWnd == g_hCurTask ? MASK_SELECTED:MASK_NONE;
		maskVal |= IsIconic(hWnd) ? MASK_MINIMIZED:MASK_NONE;
		maskVal |= (maskVal & MASK_MINIMIZED) || (maskVal & MASK_SELECTED) ? MASK_NONE:MASK_NORMAL;

		if(MASK_NONE != (maskVal & ts.Display))
		{
			char tmpTitle[MAXLEN], tmpClass[MAXLEN];

			if(0 != GetClassName(hWnd, tmpClass, MAXLEN))
			{
				GetWindowText(hWnd, tmpTitle, MAXLEN);

				if(!GetTasksIgnore(tmpClass, tmpTitle) && (IsAppWindow(hWnd, TRUE) || GetTasksAdd(tmpClass, tmpTitle)))
				{
					/*
					 * If we are showing all masked applications (we aren't using UseVWMDisplay), then bResult = TRUE
					 *
					 * Otherwise if we -are- using UseVWMDisplay to only show applications on the current desktop
					 * then bResult = TRUE only if it is a minimized app, or the application is on the current desktop.
					 */
					if(!ts.UseVWMDisplay || MASK_MINIMIZED == (MASK_MINIMIZED & maskVal))
					{
						bResult = TRUE;
					}
					else
					{
						/* Ask VWM if the hWnd is on the current desktop */
						LRESULT lResult = SendMessage(g_hParentWnd, LM_GETDESKTOPOF, (WPARAM)hWnd, 0x00000001);

						/*
						 * Some VWMs return -1 for any window that it doesn't 'manage', so we should accept those
						 * windows as always being on the current desktop.  Otherwise, we need to check the 'active'
						 * bit in the uppper nible of the return value.  If it is set, then the window was on the
						 * current desktop.
						 */
						if(0 > lResult || 0x01000000 == (lResult & 0xFF000000))
						{
							bResult = TRUE;
						}
					}
				}
			}
		}
	}

	return bResult;
}

#if 0
static VOID _logTasksIcon(const int n, const int x)
{
#define LOG_TASKS_ICON
#ifdef LOG_TASKS_ICON

	FILE * fLog;

	fLog = _tfopen(_T("C:\\TEMP\\tasks.log"), _T("a+"));

	if(NULL != fLog)
	{
		_ftprintf(fLog, _T("\r\n========================================\r\n"));
		_ftprintf(fLog, _T("TasksIcon(%d, %d) - "), n, x);

		switch(x)
		{
		case 0:
			_ftprintf(fLog, _T("[Updating]\r\n"));
			break;

		case 1:
			_ftprintf(fLog, _T("[Invalid Icon, trying alternate methods]\r\n"));
			break;

		case 2:
			_ftprintf(fLog, _T("[Copy Image failed!]\r\n"));
			break;

		case 3:
			_ftprintf(fLog, _T("[Copy Icon failed!]\r\n"));
			break;

		case 4:
			_ftprintf(fLog, _T("[Update successful]\r\n"));
			break;

		case 5:
			_ftprintf(fLog, _T("[No valid icon found, keeping current one.]\r\n"));
			break;

		case 6:
			_ftprintf(fLog, _T("[Using IDI_APPLICATION default icon!]\r\n"));
			break;
		}
		_ftprintf(fLog, _T("\t   icon(0x%08X)\r\n"), tasks[n].icon);
		_ftprintf(fLog, _T("\ticonOrg(0x%08X)\r\n"), tasks[n].iconOrg);

		_ftprintf(fLog, _T("\r\n========================================\r\n"));

		fclose(fLog);
	}
#endif /* LOG_TASKS_ICON */

	return;
}
#endif

#define INVALID_ICON(x) ((NULL == (x)) || (1 == (int)(x)) || (-1 == (int)(x)))

BOOL CreateTasksIcon(UINT nTask, HICON hIcon)
{
	HICON hNewIcon;

	hNewIcon = (HICON)CopyImage((HANDLE)hIcon, IMAGE_ICON, 0, 0, 0);

	if(INVALID_ICON(hNewIcon))
	{
		//_logTasksIcon(nTask, 2);

		hNewIcon = CopyIcon(hIcon);
	}

	if(!INVALID_ICON(hNewIcon))
	{
		if(NULL != tasks[nTask].icon)
		{
			DestroyIcon(tasks[nTask].icon);
		}

		tasks[nTask].iconOrg = hIcon;
		tasks[nTask].icon = hNewIcon;

		//_logTasksIcon(nTask, 4);

		return(TRUE);
	}

	//_logTasksIcon(nTask, 3);

	return(FALSE);
}

BOOL UpdateTasksIcon(const int nTask, const int nTimeOut)
{
	HICON hIcon = NULL;
	HWND hWnd = tasks[nTask].appHandle;

	//_logTasksIcon(nTask, 0);

	if(ts.IconSize > 23)
	{
		if(SendMessageTimeout(
			 hWnd
			,WM_GETICON
			,ICON_BIG
			,0
			,SMTO_BLOCK|SMTO_ABORTIFHUNG
			,nTimeOut
			,(PDWORD_PTR)&hIcon
		) && !INVALID_ICON(hIcon))
		{
			if(hIcon == tasks[nTask].iconOrg)
			{
				return(FALSE);
			}
			else if(CreateTasksIcon(nTask, hIcon))
			{
				return(TRUE);
			}
		}

		//_logTasksIcon(nTask, 1);

		hIcon = (HICON)GetClassLong(hWnd, GCL_HICON);
		if(!INVALID_ICON(hIcon))
		{
			if(hIcon == tasks[nTask].iconOrg)
			{
				return(FALSE);
			}
			else if(CreateTasksIcon(nTask, hIcon))
			{
				return(TRUE);
			}
		}

		//_logTasksIcon(nTask, 1);

		if(SendMessageTimeout(
			 hWnd
			,WM_QUERYDRAGICON
			,ICON_BIG
			,0
			,SMTO_BLOCK|SMTO_ABORTIFHUNG
			,nTimeOut
			,(PDWORD_PTR)&hIcon
		) && !INVALID_ICON(hIcon))
		{
			if(hIcon == tasks[nTask].iconOrg)
			{
				return(FALSE);
			}
			else if(CreateTasksIcon(nTask, hIcon))
			{
				return(TRUE);
			}
		}

		//_logTasksIcon(nTask, 1);

		if(SendMessageTimeout(
			 hWnd
			,WM_GETICON
			,ICON_SMALL
			,0
			,SMTO_BLOCK|SMTO_ABORTIFHUNG
			,nTimeOut
			,(PDWORD_PTR)&hIcon
		) && !INVALID_ICON(hIcon))
		{
			if(hIcon == tasks[nTask].iconOrg)
			{
				return(FALSE);
			}
			else if(CreateTasksIcon(nTask, hIcon))
			{
				return(TRUE);
			}
		}

		//_logTasksIcon(nTask, 1);

		hIcon = (HICON)GetClassLong(hWnd, GCL_HICONSM);
		if(!INVALID_ICON(hIcon))
		{
			if(hIcon == tasks[nTask].iconOrg)
			{
				return(FALSE);
			}
			else if(CreateTasksIcon(nTask, hIcon))
			{
				return(TRUE);
			}
		}
	}
	else
	{
		if(SendMessageTimeout(
			 hWnd
			,WM_GETICON
			,ICON_SMALL
			,0
			,SMTO_BLOCK|SMTO_ABORTIFHUNG
			,nTimeOut
			,(PDWORD_PTR)&hIcon
		) && !INVALID_ICON(hIcon))
		{
			if(hIcon == tasks[nTask].iconOrg)
			{
				return(FALSE);
			}
			else if(CreateTasksIcon(nTask, hIcon))
			{
				return(TRUE);
			}
		}

		//_logTasksIcon(nTask, 1);

		if(SendMessageTimeout(
			 hWnd
			,WM_GETICON
			,ICON_BIG
			,0
			,SMTO_BLOCK|SMTO_ABORTIFHUNG
			,nTimeOut
			,(PDWORD_PTR)&hIcon
		) && !INVALID_ICON(hIcon))
		{
			if(hIcon == tasks[nTask].iconOrg)
			{
				return(FALSE);
			}
			else if(CreateTasksIcon(nTask, hIcon))
			{
				return(TRUE);
			}
		}

		//_logTasksIcon(nTask, 1);

		hIcon = (HICON)GetClassLong(hWnd, GCL_HICONSM);
		if(!INVALID_ICON(hIcon))
		{
			if(hIcon == tasks[nTask].iconOrg)
			{
				return(FALSE);
			}
			else if(CreateTasksIcon(nTask, hIcon))
			{
				return(TRUE);
			}
		}

		//_logTasksIcon(nTask, 1);

		hIcon = (HICON)GetClassLong(hWnd, GCL_HICON);
		if(!INVALID_ICON(hIcon))
		{
			if(hIcon == tasks[nTask].iconOrg)
			{
				return(FALSE);
			}
			else if(CreateTasksIcon(nTask, hIcon))
			{
				return(TRUE);
			}
		}

		//_logTasksIcon(nTask, 1);

		if(SendMessageTimeout(
			 hWnd
			,WM_QUERYDRAGICON
			,ICON_BIG
			,0
			,SMTO_BLOCK|SMTO_ABORTIFHUNG
			,nTimeOut
			,(PDWORD_PTR)&hIcon
		) && !INVALID_ICON(hIcon))
		{
			if(hIcon == tasks[nTask].iconOrg)
			{
				return(FALSE);
			}
			else if(CreateTasksIcon(nTask, hIcon))
			{
				return(TRUE);
			}
		}
	}

	if(NULL == tasks[nTask].iconOrg)
	{
		//_logTasksIcon(nTask, 6);

		if(CreateTasksIcon(nTask, LoadIcon(NULL, IDI_APPLICATION)))
		{
			return(TRUE);
		}
	}

	//_logTasksIcon(nTask, 5);

	return(FALSE);
}

void DoWrapCommand( const int oldNumTasks )
{
	const int tmpNumTasks = ts.AutoArrange ? GetUnMovedNrTasks(numTasks):numTasks;

	if(oldNumTasks != tmpNumTasks)
	{
		if(0 == tmpNumTasks)
		{
			LSExecute(g_hMainWnd, ts.EmptyCmd, 0);
		}
		else if(g_bTaskWrap && numWrapCmd)
		{
			int wrapCmdIndex = -1;

			if(1 == ts.WrapCount)
			{
				wrapCmdIndex = tmpNumTasks - 1;
			}
			else
			{
				if(oldNumTasks < tmpNumTasks)
				{
					if(1 == (tmpNumTasks % ts.WrapCount))
					{
						wrapCmdIndex = tmpNumTasks / ts.WrapCount;
					}
				}
				else if(oldNumTasks > tmpNumTasks)
				{
					if(0 == (tmpNumTasks % ts.WrapCount))
					{
						wrapCmdIndex = tmpNumTasks / ts.WrapCount - 1;
					}
				}
			}

			if(-1 != wrapCmdIndex)
			{
				for(int i = 0; i < numWrapCmd; i++)
				{
					if(wrapCmdIndex == wrapCmd[i].index)
					{
						LSExecute(g_hMainWnd, wrapCmd[i].cmd, 0);
						break;
					}
				}
			}
		}
	}

	return;
}

void DoMouseCommand(const int nTask, const char * const sAction)
{
	if(NULL != sAction && 0 != *sAction)
	{
		if('.' == *sAction)
		{
			if(0 == lstrcmpi(sAction, ".SYSPOPUP"))
			{
				ShowWindowSysMenu(nTask, GetMessagePos());
			}

			return;
		}

		LSExecute(NULL, sAction, 0);
	}

	return;
}

LRESULT CALLBACK MainWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch(uMsg)
	{
	case WM_DISPLAYCHANGE:
		// Screen resolution has changed. Update stored settings.
		g_nScreenCX = LOWORD(lParam);
		g_nScreenCY = HIWORD(lParam);

		if(NULL == ts.DockWindow)
		{
			g_nDockCX = g_nScreenCX;
			g_nDockCY = g_nScreenCY;

			TasksGather(NULL, NULL);
		}
		break;

	case LM_GETREVID:
		return(strlen(strcpy((char*)lParam, g_szAboutStr)));

	case LM_REFRESH:
		TasksDisable(NULL, NULL);

		unregisterEvents();
		unloadSetup();

		loadSetup();
		registerEvents();

		TasksEnable(NULL, NULL);
		break;

	case 9370:// VWM updated
	case LM_WINDOWCREATED:
	case LM_WINDOWDESTROYED:
	case LM_WINDOWACTIVATED:
	case LM_REDRAW:
	case WM_TIMER:
		/* Quick check to make sure we are still in a valid docking window */
		IsDockWindowValid();

		if(!g_bTasksDisabled && (WM_TIMER != uMsg || TMR_UPDATE == wParam))
		{
			int oldNumTasks = ts.AutoArrange ? GetUnMovedNrTasks(numTasks):numTasks;

			/* Don't update the current task if processing a mouse click */
			if(0 == g_uButtonDownMsg)
			{
				g_hOldCurTask = g_hCurTask;
				g_hCurTask = GetForegroundWindow();

				/*
				 * If a popup dialog or some such has focus, then make sure
				 * g_hCurTask = the actual application window
				 */
				if(!InWinList(g_hCurTask))
				{
					int n = GetTaskByAppWnd(GetParent(g_hCurTask));

					if(-1 == n)
					{
						n = GetTaskByAppWnd(GetWindowOwner(g_hCurTask));
					}

					if(-1 != n)
					{
						g_hCurTask = tasks[n].appHandle;
					}
				}

				/*
				 * Used for TasksSwitch() function, so that !TasksSwitch can be
				 * used from a shortcut, or other shell window which may take focus
				 * This will allow us to get the correct current application.
				 */
				if(g_hOldCurTask != g_hCurTask)
				{
					g_hLockCurTask = g_hOldCurTask;
				}
			}

			PackList();/*Get rid of old apps in tasks list*/

			EnumWindows(EnumWindowsProc, NULL);/*Add new apps to tasks list*/

			/* Flashing task support */
			if(LM_REDRAW == uMsg)
			{
				int n = GetTaskByAppWnd((HWND)wParam);

				if(-1 != n && (0 != lParam) != tasks[n].IsFlashing)
				{
					tasks[n].IsFlashing = (0 != lParam);
					g_hFlashingTask = tasks[n].hWnd;
				}
			}

			UpdateTasks();/*Update task windows*/

			DoWrapCommand(oldNumTasks);
		}
		break;

	default:
		return(DefWindowProc(hWnd, uMsg, wParam, lParam));
	}

	return(0);
}

#ifdef USE_HOVER
VOID UpdateHover(int nTask, BOOL bOnMouseMove)
{
	/*
	 * This needs fixing.  This is too f00bar for my taste.
	 * A simple thing like ALT+TAB to another window breaks this implementation.
	 */
	BOOL bHoveringNow, bMouseOverNow;
	POINT pt;
	HWND hWnd;
	RECT r;

	hWnd = tasks[nTask].hWnd;
	
	GetCursorPos(&pt);
	GetWindowRect(hWnd, &r);
	
	bMouseOverNow = PtInRect(&r, pt);
	bHoveringNow = bMouseOverNow && pt.x == tasks[nTask].HoverPoint.x && pt.y == tasks[nTask].HoverPoint.y;
	
	if(bMouseOverNow && WindowFromPoint(pt) != hWnd)
	{
		bMouseOverNow = FALSE;
	}
	
	if(bOnMouseMove)
	{
		if(bMouseOverNow && !tasks[nTask].IsMouseOver)
		{
			tasks[nTask].IsMouseOver = TRUE;

			LSExecute(NULL, ts.OnMouseOver, 0);

			SetCapture(tasks[nTask].hWnd);
		}

		if(tasks[nTask].IsHovering && !bHoveringNow)
		{
			tasks[nTask].IsHovering = FALSE;

			LSExecute(NULL, ts.OnUnhover, 0);
		}

		tasks[nTask].HoverPoint = pt;

		SetTimer(tasks[nTask].hWnd, 0, 5000, NULL);
	}
	else
	{
		if(bHoveringNow && !tasks[nTask].IsHovering)
		{
			tasks[nTask].IsHovering = TRUE;

			LSExecute(NULL, ts.OnHover, 0);
		}
	}

	if(tasks[nTask].IsMouseOver && !bMouseOverNow)
	{
		tasks[nTask].IsMouseOver = FALSE;

		LSExecute(NULL, ts.OnMouseOut, 0);

		KillTimer(tasks[nTask].hWnd, 0);

		if(0 == g_uButtonDownMsg)
		{
			ReleaseCapture();
		}
	}
	return;
}
#endif /* USE_HOVER */

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	int n;

	switch(uMsg)
	{
	case WM_DROPFILES:
	{
		HWND hWnd2;

		n = GetTaskByWnd(hWnd);

		SwitchToTasksWnd(n);

		/* Using GetLAP fixes some issues, hopefully it doesn't break others. */
		hWnd2 = GetLastActivePopup(tasks[n].appHandle);

		//jesus_mjjg fix (must use PostMessage, not SendMessage)
		PostMessage(hWnd2, uMsg, wParam, lParam);
		return 0;
	}
	case WM_PAINT:
	{
		n = GetTaskByWnd(hWnd);

		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hWnd, &ps);

		if (ts.UseWindowsSettings)
		{
			UINT dcFlags = DC_TEXT|DC_ICON;
			RECT r;
			GetClientRect(hWnd, &r);
			if (ts.HighLightSelected && tasks[n].IsActive) dcFlags |= DC_ACTIVE;
			DrawCaption(tasks[n].appHandle, hdc, &r, dcFlags);
		}
		else
		{
			HDC hdcbuf = CreateCompatibleDC(hdc);
			HBITMAP hbmpbuf = CreateCompatibleBitmap(hdc,ts.Width,ts.Height);
			HBITMAP holdbmp = (HBITMAP) SelectObject(hdcbuf,hbmpbuf);

			PaintTask(hdcbuf, n);  // Painting to a buffer first.

			if (ts.Transparency == 2)
			{  // TRUE TRANSPARENCY CODE BY GUSTAV MUNKBY
				SelectObject(hdcbuf,holdbmp);
				HRGN tile = BitmapToRegion(hbmpbuf, 0x00EF00EF, 0x00101010, 0, 0);
				if(NULL != tile && !SetWindowRgn(tasks[n].hWnd,tile,TRUE))
				{
					DeleteObject(tile);
				}
				holdbmp = (HBITMAP) SelectObject(hdcbuf,hbmpbuf);
			}

			if (ts.Transparency == 1)
			{
				PaintDesktop(hdc); // paint to original DC
				TransparentBltLS(hdc, 0,0, ts.Width,ts.Height, hdcbuf, 0,0, RGB(255,0,255));
			}
			else
			{
				BitBlt(hdc, 0,0, ts.Width,ts.Height, hdcbuf, 0,0, SRCCOPY);
			}

			SelectObject(hdcbuf,holdbmp);
			DeleteObject(hbmpbuf);
			DeleteDC(hdcbuf);
		}

		EndPaint(hWnd,&ps);
		return 0;
	}
#ifdef USE_HOVER
	case WM_TIMER:
	{
		n = GetTaskByWnd(hWnd);
		
		UpdateHover(n, FALSE);
		break;
	}
#endif
	case WM_CAPTURECHANGED:
	{
		n = GetTaskByWnd(hWnd);

		switch(g_uButtonDownMsg)
		{
		case WM_LBUTTONDOWN:
			/* Restore the tile to its original position */
			if(!ts.NoMove)
			{
				SetWindowPos(
					 tasks[n].hWnd
					,0
					,tasks[n].x
					,tasks[n].y
					,0
					,0
					,SWP_NOACTIVATE|SWP_NOZORDER|SWP_NOSIZE|SWP_NOOWNERZORDER
				);

				SetCursor(g_hCursorNormal);

				//ClipCursor(NULL);
			}

			/* Must always have a buttonUp after a buttonDown */
			DoMouseCommand(n, ts.OnLButtonUp);
			break;

		case WM_RBUTTONDOWN:
			/* Must always have a buttonUp after a buttonDown */
			DoMouseCommand(n, ts.OnRButtonUp);
			break;

		case WM_MBUTTONDOWN:
			/* Must always have a buttonUp after a buttonDown */
			DoMouseCommand(n, ts.OnMButtonUp);
			break;

		default:
#ifdef USE_HOVER
			UpdateHover(n, FALSE);
#endif
			break;
		}

		g_uButtonDownMsg = 0;

		return(0);
	}
	case WM_KEYDOWN:
	{
		/* If movement is allowed, and it is the left button, then reset */
		if(VK_ESCAPE == wParam && !ts.NoMove && WM_LBUTTONDOWN == g_uButtonDownMsg)
		{
			ReleaseCapture();

			SwitchToWnd(g_hCurTask);

			return(0);
		}
		break;
	}
	case WM_LBUTTONDOWN:
	{
		if(0 == g_uButtonDownMsg)
		{
			n = GetTaskByWnd(hWnd);

			g_uButtonDownMsg = uMsg;
			DoMouseCommand(n, ts.OnLButtonDown);

			/* Used to check for drag/movement */
			if(!ts.NoMove)
			{
				DWORD dwPos;

				/*
				 * Needed to receive WM_KEYDOWN when docked, and it doesn't
				 * hurt to do it when not docked.
				 */
				SetFocus(hWnd);

				/*
				 * NOTE: SetFocus and ClipCursor do not play nice together
				 * If you figure out a way to get them to work with each other,
				 * uncomment this and ClipCursor(NULL) in WM_LBUTTONUP and
				 * WM_CAPTURECHANGED.  Enjoy!
				 */
				//if(NULL != ts.DockWindow)
				//{
				//	RECT r;
				//	/* Lock the cursor to the dock window */
				//	GetWindowRect(ts.DockWindow, &r);
				//	ClipCursor(&r);
				//}

				dwPos = GetMessagePos();

				g_oldCursorPos = MAKEPOINTS(dwPos);
			}

			SetCapture(hWnd);
			return 0;
		}
		break;
	}
	case WM_RBUTTONDOWN:
	{
		if(0 == g_uButtonDownMsg)
		{
			n = GetTaskByWnd(hWnd);

			g_uButtonDownMsg = uMsg;
			DoMouseCommand(n, ts.OnRButtonDown);

			SetCapture(hWnd);
			return 0;
		}
		break;
	}
	case WM_MBUTTONDOWN:
	{
		if(0 == g_uButtonDownMsg)
		{
			n = GetTaskByWnd(hWnd);

			g_uButtonDownMsg = uMsg;
			DoMouseCommand(n, ts.OnMButtonDown);

			SetCapture(hWnd);
			return 0;
		}
		break;
	}
	case WM_MOUSEMOVE:
	{
		if(WM_LBUTTONDOWN == g_uButtonDownMsg && !ts.NoMove && MK_LBUTTON == (MK_LBUTTON & wParam))
		{
			int x, y;
			DWORD dwCurPos;
			BOOL bUpdate = FALSE;

			n = GetTaskByWnd(hWnd);

			dwCurPos = GetMessagePos();

			x = tasks[n].x - (g_oldCursorPos.x - MAKEPOINTS(dwCurPos).x);
			y = tasks[n].y - (g_oldCursorPos.y - MAKEPOINTS(dwCurPos).y);

			if (x < 0) x = 0;
			if (y < 0) y = 0;
			if (x + ts.Width > g_nDockCX) x = g_nDockCX - ts.Width;
			if (y + ts.Height > g_nDockCY) y = g_nDockCY - ts.Height;

			/* Set the cursor depending if we have 'moved' or not */
			if(
				abs(tasks[n].x - x) <= ts.DragDistance
				&&
				abs(tasks[n].y - y) <= ts.DragDistance
			)
			{
				x = tasks[n].x;
				y = tasks[n].y;

				if(GetCursor() != g_hCursorNormal)
				{
					SetCursor(g_hCursorNormal);
					bUpdate = TRUE;
				}
			}
			else
			{
				SetCursor(g_hCursorMoving);
				bUpdate = TRUE;
			}

			if(bUpdate)
			{
				SetWindowPos(hWnd, HWND_TOP, x, y, 0, 0, SWP_NOSIZE|SWP_NOACTIVATE|SWP_NOOWNERZORDER);

				/* psuedo transparency during move, causes some flicker, but it works (Maduin)*/
				if(!ts.StartHidden && ts.Transparency == 1)
				{
					InvalidateRect(hWnd, NULL, TRUE);
				}
			}

			return 0;
		}
		/* Error case handler.  Should never happen */
		else if(0 != g_uButtonDownMsg)
		{
			if(0 == (MK_LBUTTON|MK_RBUTTON|MK_MBUTTON) & wParam)
			{
				ReleaseCapture();
			}
		}
#ifdef USE_HOVER
		else if(0 == g_uButtonDownMsg)
		{
			n = GetTaskByWnd(hWnd);

			UpdateHover(n, TRUE);
		}
#endif /* USE_HOVER */

		SetCursor(g_hCursorNormal);
		break;
	}
	case WM_LBUTTONUP:
	{
		if(WM_LBUTTONDOWN == g_uButtonDownMsg)
		{
			int x, y;
			DWORD dwCurPos;
			BOOL bOver;
			BOOL bMoved = FALSE;

			n = GetTaskByWnd(hWnd);

			dwCurPos = GetMessagePos();

			g_uButtonDownMsg = 0;
			//ClipCursor(NULL);
			ReleaseCapture();

			DoMouseCommand(n, ts.OnLButtonUp);

			x = tasks[n].x;
			y = tasks[n].y;

			if(!ts.NoMove)
			{
				x = tasks[n].x - (g_oldCursorPos.x - MAKEPOINTS(dwCurPos).x);
				y = tasks[n].y - (g_oldCursorPos.y - MAKEPOINTS(dwCurPos).y);

				if (x < 0) x = 0;
				if (y < 0) y = 0;
				if (x + ts.Width > g_nDockCX) x = g_nDockCX - ts.Width;
				if (y + ts.Height > g_nDockCY) y = g_nDockCY - ts.Height;

				if(
					abs(tasks[n].x - x) > ts.DragDistance
					||
					abs(tasks[n].y - y) > ts.DragDistance
				)
				{
					bMoved = TRUE;
				}
			}

			bOver = IsPointInTask(n, MAKEPOINTS(dwCurPos));

			/*
			 * If there was no movement, then it was a 'click' event.
			 */
			if((ts.NoMove || !bMoved) && bOver)
			{
				if(!ts.NoMove)
				{ /* This shouldn't be necessary, but its good to play it safe */
					SetWindowPos(
						 tasks[n].hWnd
						,0
						,tasks[n].x
						,tasks[n].y
						,0
						,0
						,SWP_NOACTIVATE|SWP_NOZORDER|SWP_NOSIZE|SWP_NOOWNERZORDER
					);
				}

				/* Before sending a WS_SYSCOMMAND, a window must have focus for it to work correcly */
				/* So put activation of the app here, instead of after the MinimizeOnClick check. */
				SwitchToTasksWnd(n);

				if(
					!ts.NoMinimizeOnClick
					&&
					!tasks[n].IsIconic
					&&
					tasks[n].appHandle == g_hCurTask
				)
				{
					SendMessage(tasks[n].appHandle, WM_SYSCOMMAND, (WPARAM)SC_MINIMIZE, 0);
				}

				DoMouseCommand(n, ts.OnLButtonClick);
			}
			/*
			 * Otherwise if there was movement, then proceed accordingly
			 */
			else if(!ts.NoMove)
			{
				if (ts.MoveAll)
				{
					BOOL wasHidden = ts.StartHidden;

					ts.X -= tasks[n].x - x;
					ts.Y -= tasks[n].y - y;

					tasks[n].x = x;
					tasks[n].y = y;

					g_rAllTasks.left = g_rAllTasks.right = g_rAllTasks.top = g_rAllTasks.bottom = 0;
					if (!wasHidden)
						TasksHide(NULL, NULL);
					ReArrangeTasks(0, TRUE);
					if (g_rAllTasks.right > g_nDockCX){
						if (ts.Direction == 4 || (g_bTaskWrap && ts.WrapDirection == 4))
							ts.X = g_nDockCX;
						else
							ts.X -= g_rAllTasks.right - g_nDockCX;
					}
					if (g_rAllTasks.bottom > g_nDockCY){
						if (ts.Direction == 1 || (g_bTaskWrap && ts.WrapDirection == 1))
							ts.Y = g_nDockCY;
						else
							ts.Y -= g_rAllTasks.bottom - g_nDockCY;
					}
					if (g_rAllTasks.left < 0){
						if (ts.Direction == 4 || (g_bTaskWrap && ts.WrapDirection == 4))
							ts.X -= g_rAllTasks.left;
						else
							ts.X = 0;
					}
					if (g_rAllTasks.top < 0){
						if (ts.Direction == 1 || (g_bTaskWrap && ts.WrapDirection == 1))
							ts.Y -= g_rAllTasks.top;
						else
							ts.Y = 0;
					}
					g_rAllTasks.left = g_rAllTasks.right = g_rAllTasks.top = g_rAllTasks.bottom = 0;
					ReArrangeTasks(0, TRUE);
					if (!wasHidden)
						TasksShow(NULL, NULL);
				}
				else
				{
					tasks[n].x = x;
					tasks[n].y = y;

					SetWindowPos(
						 tasks[n].hWnd
						,0
						,tasks[n].x
						,tasks[n].y
						,0
						,0
						,SWP_NOACTIVATE|SWP_NOZORDER|SWP_NOSIZE|SWP_NOOWNERZORDER
					);

					if(!tasks[n].IsMoved)
					{
						tasks[n].IsMoved = TRUE;

						if(ts.AutoArrange)
						{
							ReArrangeTasks(n, FALSE);

							DoWrapCommand(GetUnMovedNrTasks(numTasks) + 1);
						}
					}
				}

				/*
				 * After moving the task tiles around, then restore focus
				 * to the previous application that had focus.
				 */
				SwitchToWnd(g_hCurTask);
			}
			/*
			 * If the mouse was released outside of the specified task tile,
			 * then restore focus to the previous application that had focus.
			 */
			else if(!bOver)
			{
				SwitchToWnd(g_hCurTask);
			}

			if(!ts.NoMove)
			{
				SetCursor(g_hCursorNormal);
			}

			return 0;
		}
		break;
	}
	case WM_RBUTTONUP:
		if(WM_RBUTTONDOWN == g_uButtonDownMsg)
		{
			DWORD dwCurPos;

			n = GetTaskByWnd(hWnd);

			dwCurPos = GetMessagePos();

			g_uButtonDownMsg = 0;
			ReleaseCapture();

			// always execute buttonUp command for the task that received the onDown command
			DoMouseCommand(n, ts.OnRButtonUp);

			// Only execute the onClick command for the task receiving the buttonUp event
			if(IsPointInTask(n, MAKEPOINTS(dwCurPos)))
			{
				DoMouseCommand(n, ts.OnRButtonClick);
			}
			else
			{
				SwitchToWnd(g_hCurTask);
			}

			return(0);
		}
		break;

	case WM_MBUTTONUP:
		if(WM_MBUTTONDOWN == g_uButtonDownMsg)
		{
			DWORD dwCurPos;

			n = GetTaskByWnd(hWnd);

			dwCurPos = GetMessagePos();

			g_uButtonDownMsg = 0;
			ReleaseCapture();

			// always execute buttonUp command for the task that received the onDown command
			DoMouseCommand(n, ts.OnMButtonUp);

			// Only execute the onClick command for the task receiving the buttonUp event
			if(IsPointInTask(n, MAKEPOINTS(dwCurPos)))
			{
				DoMouseCommand(n, ts.OnMButtonClick);
			}
			else
			{
				SwitchToWnd(g_hCurTask);
			}

			return(0);
		}
		break;
	}

	return DefWindowProc(hWnd,uMsg,wParam,lParam);
}

BOOL IsPointInTask(int n, POINTS pts)
{
	POINT pt;
	RECT r;

	pt.x = pts.x;
	pt.y = pts.y;

	return(GetWindowRect(tasks[n].hWnd, &r) && PtInRect(&r, pt));
}

int GetTaskByWnd(HWND hWnd)
{
	if (hWnd)
		for (int i=0;i<numTasks;i++)
			if (tasks[i].hWnd == hWnd)
				return i;
	return -1;
}

int GetTaskByAppWnd(HWND hWnd)
{
	if (hWnd)
		for (int i=0;i<numTasks;i++)
			if (tasks[i].appHandle == hWnd)
				return i;
	return -1;
}

int GetUnMovedNrTasks(int n)
{
	int j=0;
	for (int i=0;i<n;i++)
		if (!tasks[i].IsMoved)
			++j;
	return j;
}

int InWinList(HWND hWnd)
{
	if (hWnd)
		for (int i=0;i<numTasks;i++)
			if (tasks[i].appHandle == hWnd)
				return i+1;
	return 0;
}

void CreateHints(HWND hWnd, char * txt)
{ /*from the original ls code (shortcuts)*/
	RECT r;
	GetClientRect(hWnd, &r);
	TOOLINFO ti;/*tool information*/
	ti.cbSize = sizeof(TOOLINFO);
	ti.uFlags = TTF_SUBCLASS;
	ti.hwnd = hWnd;
	ti.hinst = g_hDllInst;
	ti.uId = 0;
	ti.lpszText = txt;
	ti.rect = r;
	SendMessage(g_hHintWnd, TTM_ADDTOOL, 0, (LPARAM) (LPTOOLINFO) &ti);
	return;
}

void CreateTask(int i, HWND handle)
{
	HWND hWnd;
	DWORD dwExStyle = WS_EX_ACCEPTFILES|WS_EX_TOOLWINDOW;

	if(2 == ts.zOrder)
	{
		dwExStyle |= WS_EX_TOPMOST;
	}

	GetNewTaskPos(i);

	hWnd = CreateWindowEx(
		 dwExStyle
		,"Tasks"/*MAKEINTATOM(g_TasksAtom)*/ // A bug in grdTransparent forces us to use a valid string here
		,""
		,WS_POPUP
		,tasks[i].x
		,tasks[i].y
		,ts.Width
		,ts.Height
		,NULL
		,NULL
		,g_hDllInst
		,NULL
	);

	if(NULL == hWnd)
	{
		MessageBox(NULL,"Error creating window","Tasks",MB_OK|MB_ICONERROR|MB_DEFBUTTON1|MB_SYSTEMMODAL);
	}
	else
	{
		if(NULL != ts.DockWindow)
		{
			SetWindowLong(hWnd, GWL_STYLE, (GetWindowLong(hWnd, GWL_STYLE) &~ WS_POPUP)|WS_CHILD|WS_CLIPSIBLINGS);
			SetParent(hWnd, ts.DockWindow);
		}

		tasks[i].hWnd = hWnd;
		tasks[i].appHandle = handle;

		//keeps the tiles from showing up in shell lists/displays, as well as keeping them on every VW in a VWM.
		SetWindowLong(tasks[i].hWnd, GWL_USERDATA, 0x49474541);

		// Populate Title Text
		{
			char titleTmp[MAXLEN];
			GetWindowText(tasks[i].appHandle, titleTmp, MAXLEN);
			tasks[i].appTitle = new char[strlen(titleTmp) + 1];
			strcpy(tasks[i].appTitle, titleTmp);
		}

			// Populate Class Text
		GetTasksClass(i);

		tasks[i].IsActive = (tasks[i].appHandle == g_hCurTask);
		tasks[i].IsIconic = IsIconic(tasks[i].appHandle);
		if (tasks[i].IsIconic && ts.HideMinAppBar) HideMinAppBar(tasks[i].appHandle);
		tasks[i].IsMoved  = FALSE;
		if(!GetTasksPix(i) && !ts.NoIcons)
		{
			GetTasksIcon(i);
		}
		if (ts.StartHidden)
			ShowWindow(tasks[i].hWnd, SW_HIDE);
		else
			ShowWindow(tasks[i].hWnd, SW_SHOWNOACTIVATE);
		if (!ts.NoHints)
			CreateHints(tasks[i].hWnd, tasks[i].appTitle);
		++numTasks;

		LSExecute(g_hMainWnd, ts.OnAdd, 0);
	}

	if (ts.Sort)
		ReArrangeTasks(0, FALSE);

	return;
}

void DeleteTask(int i)
{
	if(0 != g_uButtonDownMsg && tasks[i].hWnd == GetCapture())
	{
		ReleaseCapture();
		SwitchToWnd(g_hCurTask);
	}

	ShowWindow(tasks[i].hWnd, SW_HIDE);

	if (!ts.NoHints)
		RemoveHints(tasks[i].hWnd);
	if (tasks[i].pix){
		DeleteObject(tasks[i].pix);
		tasks[i].pix = NULL;
	}
	if (tasks[i].appClass){
		delete [] tasks[i].appClass;
		tasks[i].appClass = NULL;
	}
	if (tasks[i].appTitle){
		delete [] tasks[i].appTitle;
		tasks[i].appTitle = NULL;
	}
	if (tasks[i].icon){
		DestroyIcon(tasks[i].icon);
		tasks[i].icon = NULL;
	}
	tasks[i].iconOrg = NULL;

	if(NULL != tasks[i].hWnd)
	{
		DestroyWindow(tasks[i].hWnd);
		tasks[i].hWnd = NULL;
	}

	LSExecute(g_hMainWnd, ts.OnDel, 0);

	return;
}

void GetNewTaskPos(int i)
{
	TaskPosition(i, (ts.AutoArrange && !ts.NoMove ? GetUnMovedNrTasks(numTasks):numTasks));
	return;
}

void UpdateTasks(void)
{
	int n;
	BOOL refreshTask = FALSE;
	BOOL resortTasks = FALSE;

	for (n=0;n<numTasks;n++){
		if (tasks[n].IsIconic != IsIconic(tasks[n].appHandle)){
			tasks[n].IsIconic = !tasks[n].IsIconic;
			if (ts.HideMinAppBar)
				HideMinAppBar(tasks[n].appHandle);
			if (ts.HighLightMinimized || !(ts.Titles && ts.TitleMinimized && ts.TitleSelected))
				refreshTask = TRUE;
		}

		if(g_hFlashingTask == tasks[n].hWnd)
		{
			tasks[n].IsActive = !tasks[n].IsActive;
			if (!refreshTask && (ts.HighLightSelected || !(ts.Titles && ts.TitleMinimized && ts.TitleSelected)))
				refreshTask = TRUE;

			g_hFlashingTask = NULL;
		}
		else if (0 == g_uButtonDownMsg && (tasks[n].IsActive != (g_hCurTask == tasks[n].appHandle) || tasks[n].IsFlashing))
		{
			if(!tasks[n].IsFlashing || g_hCurTask == tasks[n].appHandle)
			{
				tasks[n].IsActive = !tasks[n].IsActive || tasks[n].IsFlashing;
				tasks[n].IsFlashing = FALSE;
				if (!refreshTask && (ts.HighLightSelected || !(ts.Titles && ts.TitleMinimized && ts.TitleSelected)))
					refreshTask = TRUE;
			}
		}

		{
			char tmpTitle[MAXLEN];
			GetWindowText(tasks[n].appHandle, tmpTitle, MAXLEN);
			if (strcmp(tmpTitle, tasks[n].appTitle)){
				delete [] tasks[n].appTitle;
				tasks[n].appTitle = new char[strlen(tmpTitle) + 1];
				strcpy(tasks[n].appTitle, tmpTitle);
				if (!ts.NoHints)
					UpdateHints(tasks[n].hWnd, tasks[n].appTitle);
				if (!refreshTask && (ts.UseWindowsSettings || (ts.Titles && !(tasks[n].IsIconic || tasks[n].IsActive)) || (ts.TitleMinimized && tasks[n].IsIconic) || (ts.TitleSelected && tasks[n].IsActive)))
					refreshTask = TRUE;
				resortTasks = TRUE;
			}
		}

		if (!ts.UseWindowsSettings && !ts.NoIcons && !tasks[n].pix && NULL != tasks[n].iconOrg)
		{
			if(UpdateTasksIcon(n, 20))
			{
				refreshTask = TRUE;
			}
		}

		if (!ts.StartHidden && refreshTask)
			InvalidateRect(tasks[n].hWnd, NULL, TRUE);

		refreshTask = FALSE;
	}

	if (ts.DockWindow != NULL)
	{
		RECT r;

		// Should this be happening every time? Seems a bit much.
		GetWindowRect(ts.DockWindow, &r);

		if(g_nDockCX != (r.right - r.left) || g_nDockCY != (r.bottom - r.top))
		{
			g_nDockCX = r.right - r.left;
			g_nDockCY = r.bottom - r.top;

			TasksGather(NULL, NULL);
		}
	}
	else if (ts.Sort && resortTasks)
	{
		ReArrangeTasks(0, FALSE);
	}

	return;
}

// Allow for the user to substitute a class name based upon the
// title or classname. This is useful for apps that do not set
// the classname to something constant for sorting. Also it allows
// you to put a certain class last or first easily by substituting
// a prefix such as "aaa" or "zzz"
void GetTasksClass(int n)
{
	int i;
	char classTmp[MAXLEN];
	BOOL found = FALSE;

	GetClassName(tasks[n].appHandle, classTmp, MAXLEN);
	for (i=0;found == FALSE && i<numClass;i++)
	{
		if (strstr(tasks[n].appTitle, classTag[i].match) || strstr(classTmp, classTag[i].match))
		{
			strcpy(classTmp, classTag[i].name);
			found = TRUE;
		}
	}
	tasks[n].appClass = new char[strlen(classTmp) + 1];
	strcpy(tasks[n].appClass, classTmp);
	return;
}

void GetTasksIcon(int n)
{
	int i;

	tasks[n].icon = NULL;

	for (i=0;i<numIcon;i++)
	{
		if (strstr(tasks[n].appTitle, iconTag[i].match) || strstr(tasks[n].appClass, iconTag[i].match))
		{
			tasks[n].icon = ExtractIcon(g_hDllInst,iconTag[i].name,iconTag[i].icon);

			if(NULL != tasks[n].icon && 1 != (int)tasks[n].icon)
			{
				tasks[n].iconOrg = NULL;
				return;
			}
		}
	}

	UpdateTasksIcon(n, 1000);

	return;
}

BOOL GetTasksPix(int n)
{
	int i;
	for (i=0;i<numPix;i++)
	{
		if (strstr(tasks[n].appTitle, pixTag[i].match) || strstr(tasks[n].appClass, pixTag[i].match))
		{
			tasks[n].pix = LoadLSImage(pixTag[i].pix, NULL);
			if (tasks[n].pix)
			{
				if (tasks[n].icon)
					DestroyIcon(tasks[n].icon);
				tasks[n].icon = NULL;
				tasks[n].iconOrg = NULL;
				return(TRUE);
			}
		}
	}
	return(FALSE);
}

void HideMinAppBar(HWND hWnd)
{
	if (IsIconic(hWnd)){
		RECT r;
		GetWindowRect(hWnd, &r);
		MoveWindow(hWnd, g_nScreenCX*5+r.left, g_nScreenCY*5+r.top, r.right-r.left, r.bottom-r.top, TRUE);
	}
	return;
}

void FreeList(void)
{
	int n;
	for (n=0;n<numTasks;n++)
		DeleteTask(n);
	if (tasks != NULL){
		free(tasks);
		tasks = NULL;
	}
	numTasks = 0;
}

void PackList(void)
{
	int a,b,c,d,e,n;
	e=-1;
	a=b=c=d=n=0;

	if (!numTasks)
		return;
	while ( c<numTasks ){
		for ( a=c ; a<numTasks && IsValidWindow(tasks[a].appHandle) ; a++ )
			++n;
		if (a==numTasks)
			return;
		if (e==-1 && (!ts.AutoArrange || ts.NoMove))
			e=n;
		for ( b=a ; b<numTasks && !IsValidWindow(tasks[b].appHandle) ; b++ ){
			if (ts.AutoArrange && !ts.NoMove && !tasks[b].IsMoved && e==-1)
				e=n;
			DeleteTask(b);
		}
		if (b==numTasks){
			break;
		}

		d=1;
		for ( c=b+1 ; c<numTasks && IsValidWindow(tasks[c].appHandle) ; c++ )
			++d;
		memmove(&tasks[n], &tasks[b], d*sizeof(TaskType));
		n+=d;
	}
	if (!n){
		if (tasks != NULL){
			free(tasks);
			tasks = NULL;
			numTasks = 0;
		}
	}else{
		TaskType* tmpTasks = tasks;
		tasks = (TaskType *)realloc(tasks, (n)*sizeof(TaskType));
		if (tasks == NULL){
			free(tmpTasks);
			tmpTasks = NULL;
			numTasks = 0;
		}else{
			numTasks=n;
			if (e!=-1)
				ReArrangeTasks(e, FALSE);
		}
	}
	return;
}

void PaintTask(HDC hdcbuf, int i)
{
	int posX, posXpix, posXtmp, posY, posYpix, posYtmp, titleFontSize, titleWidth, titleHeight, titleX, titleY;
	BOOL activeTask = ts.HighLightSelected && tasks[i].IsActive;
	BOOL minTask = ts.HighLightMinimized && tasks[i].IsIconic;
	BOOL minTitles = ts.TitleMinimized && tasks[i].IsIconic;
	BOOL selTitles = ts.TitleSelected && tasks[i].IsActive;
	BOOL normTitles = ts.Titles && !(tasks[i].IsActive || tasks[i].IsIconic);
	BOOL bUnderline, bNoEllipsis, bItalic;
	int fnWeight;
	UINT uFormat;
	char titleFont[MAXLEN];
	COLORREF bgColor, darkColor, lightColor, titleBgColor, titleDarkColor, titleFontColor, titleLightColor, clrHue;
	UCHAR hueIntensity, saturation;
	BITMAP bmInfo;

	HDC src = CreateCompatibleDC(hdcbuf);

	if (activeTask)
	{
		bgColor = ts.SelBgColor;
		lightColor = ts.SelLightColor;
		darkColor = ts.SelDarkColor;
		titleBgColor = ts.TitleSelBgColor;
		titleDarkColor = ts.TitleSelDarkColor;
		titleFontColor = ts.TitleSelFontColor;
		titleLightColor = ts.TitleSelLightColor;
		strcpy(titleFont, ts.TitleSelFont);
		titleFontSize = ts.TitleSelFontSize;
		titleHeight = ts.TitleSelHeight;
		titleWidth = ts.TitleSelWidth;
		titleX = ts.TitleSelX;
		titleY = ts.TitleSelY;
		bNoEllipsis = ts.TitleSelNoEllipsis;
		bUnderline = ts.TitleSelUnderline;
		bItalic = ts.TitleSelItalicize;
		fnWeight = ts.TitleSelBold ? 700:400;
		uFormat = ts.TitleSelAlignment;
		clrHue = ts.SelHueColor;
		hueIntensity = ts.SelHueIntensity;
		saturation = ts.SelHueSaturation;
		if (selTitles){
			posX = ts.TitleSelIconX;
			posY = ts.TitleSelIconY;
			posXpix = ts.TitleSelPixX;
			posYpix = ts.TitleSelPixY;
		}else{
			posX = ts.SelIconX;
			posY = ts.SelIconY;
			posXpix = ts.SelPixX;
			posYpix = ts.SelPixY;
		}
	}
	else if (minTask)
	{
		bgColor = ts.MinBgColor;
		lightColor = ts.MinLightColor;
		darkColor = ts.MinDarkColor;
		titleBgColor = ts.TitleMinBgColor;
		titleDarkColor = ts.TitleMinDarkColor;
		titleFontColor = ts.TitleMinFontColor;
		titleLightColor = ts.TitleMinLightColor;
		strcpy(titleFont, ts.TitleMinFont);
		titleFontSize = ts.TitleMinFontSize;
		titleHeight = ts.TitleMinHeight;
		titleWidth = ts.TitleMinWidth;
		titleX = ts.TitleMinX;
		titleY = ts.TitleMinY;
		bNoEllipsis = ts.TitleMinNoEllipsis;
		bUnderline = ts.TitleMinUnderline;
		bItalic = ts.TitleMinItalicize;
		fnWeight = ts.TitleMinBold ? 700:400;
		uFormat = ts.TitleMinAlignment;
		clrHue = ts.MinHueColor;
		hueIntensity = ts.MinHueIntensity;
		saturation = ts.MinHueSaturation;
		if (minTitles){
			posX = ts.TitleMinIconX;
			posY = ts.TitleMinIconY;
			posXpix = ts.TitleMinPixX;
			posYpix = ts.TitleMinPixY;
		}else{
			posX = ts.MinIconX;
			posY = ts.MinIconY;
			posXpix = ts.MinPixX;
			posYpix = ts.MinPixY;
		}
	}
	else
	{
		bgColor = ts.BgColor;
		lightColor = ts.LightColor;
		darkColor = ts.DarkColor;
		titleBgColor = ts.TitleBgColor;
		titleDarkColor = ts.TitleDarkColor;
		titleFontColor = ts.TitleFontColor;
		titleLightColor = ts.TitleLightColor;
		strcpy(titleFont, ts.TitleFont);
		titleFontSize = ts.TitleFontSize;
		titleHeight = ts.TitleHeight;
		titleWidth = ts.TitleWidth;
		titleX = ts.TitleX;
		titleY = ts.TitleY;
		bNoEllipsis = ts.TitleNoEllipsis;
		bUnderline = ts.TitleUnderline;
		bItalic = ts.TitleItalicize;
		fnWeight = ts.TitleBold ? 700:400;
		uFormat = ts.TitleAlignment;
		clrHue = ts.HueColor;
		hueIntensity = ts.HueIntensity;
		saturation = ts.HueSaturation;
		if (normTitles || minTitles || selTitles){
			posX = ts.TitleIconX;
			posY = ts.TitleIconY;
			posXpix = ts.TitlePixX;
			posYpix = ts.TitlePixY;
		}else{
			posX = ts.IconX;
			posY = ts.IconY;
			posXpix = ts.PixX;
			posYpix = ts.PixY;
		}
	}

	if(!bNoEllipsis)
	{
		uFormat |= DT_END_ELLIPSIS;
	}

	{ // fill complete area with background color
		RECT r;
		HBRUSH bg, oldBg;
		GetClientRect(tasks[i].hWnd, &r);
		bg = CreateSolidBrush(bgColor);
		oldBg = (HBRUSH) SelectObject(hdcbuf, bg);
		FillRect(hdcbuf, &r, bg);
		SelectObject(hdcbuf, oldBg);
		DeleteObject(bg);
		bg = oldBg = NULL;
	}

	if ((ts.BgImage || (ts.SelBgImage && activeTask) || (ts.MinBgImage && minTask)) && !(g_bSelBgImgNone && activeTask) && !(g_bMinBgImgNone && minTask))
	{/*Paint the background image. Believe me, the above if conditions are all necessary. Odd, but necessary :)*/
		HBITMAP hOldBitmap;
		if (ts.MinBgImage && minTask)
		{
			GetObject(ts.MinBgImage, sizeof(bmInfo), &bmInfo);
			hOldBitmap = (HBITMAP) SelectObject(src, ts.MinBgImage); //dde
		}
		else if (ts.SelBgImage && activeTask)
		{
			GetObject(ts.SelBgImage, sizeof(bmInfo), &bmInfo);
			hOldBitmap = (HBITMAP) SelectObject(src, ts.SelBgImage); //dde
		}
		else
		{
			GetObject(ts.BgImage, sizeof(bmInfo), &bmInfo);
			hOldBitmap = (HBITMAP) SelectObject(src, ts.BgImage); //dde
		}
		posXtmp = ts.Width/2 - bmInfo.bmWidth/2;   /*Center in Tile*/
		posYtmp = ts.Height/2 - bmInfo.bmHeight/2;

		TransparentBltLS(hdcbuf, posXtmp, posYtmp, bmInfo.bmWidth, bmInfo.bmHeight, src, 0, 0, RGB(255, 0, 255));
		SelectObject(src, hOldBitmap); //dde
	}
	if (tasks[i].pix)
	{
		HBITMAP hOldPix;
		GetObject(tasks[i].pix, sizeof(bmInfo), &bmInfo);
		hOldPix = (HBITMAP) SelectObject(src, tasks[i].pix); //dde

		TransparentBltLS(hdcbuf, posXpix, posYpix, bmInfo.bmWidth, bmInfo.bmHeight, src, 0, 0, RGB(255,0,255));
		SelectObject(src, hOldPix); //dde
	}
	else if (tasks[i].icon && !ts.NoIcons)
	{
		if(!ts.bHueIcons)
		{
			DrawIconEx(hdcbuf, posX, posY, tasks[i].icon, ts.IconSize, ts.IconSize, 0, NULL, DI_NORMAL);
		}
		else
		{	/* MrJukes Icon Hueing code */
    		int y = 0;
			HBITMAP hbmpIcon = CreateCompatibleBitmap(hdcbuf, ts.IconSize*2, ts.IconSize);
			HBITMAP hbmpOldIcon = (HBITMAP)SelectObject(src, hbmpIcon);

			DrawIconEx(src, 0, 0, tasks[i].icon, ts.IconSize, ts.IconSize, 0, NULL, DI_NORMAL);
			DrawIconEx(src, ts.IconSize, 0, tasks[i].icon, ts.IconSize, ts.IconSize, 0, NULL, DI_MASK);

			while (y < ts.IconSize)
			{
				int x = 0;
				while (x < ts.IconSize)
				{
					// loop through all transparent pixels...
					while (x < ts.IconSize)
					{
						// if the mask-pixel is white, then break
						if ( !GetPixel(src, x+ts.IconSize, y) )
						{
							COLORREF cl = GetPixel(src, x, y);
							BYTE r = GetRValue(cl);
							BYTE g = GetGValue(cl);
							BYTE b = GetBValue(cl);

							// saturnation effect
							if (saturation != 255)
							{
								BYTE gray = (BYTE)(r*0.3086+g*0.6094+b*0.0820);

								r = (BYTE)((r*saturation+gray*(255-saturation)+255)>>8);
								g = (BYTE)((g*saturation+gray*(255-saturation)+255)>>8);
								b = (BYTE)((b*saturation+gray*(255-saturation)+255)>>8);
							}

							// icon hue effect
							if (hueIntensity)
							{
								// the B & R values of the hue is swapped here, can somebody tell me why it only works that way?
								r = (BYTE)((r*(255-hueIntensity)+GetBValue(clrHue)*hueIntensity+255)>>8);
								g = (BYTE)((g*(255-hueIntensity)+GetGValue(clrHue)*hueIntensity+255)>>8);
								b = (BYTE)((b*(255-hueIntensity)+GetRValue(clrHue)*hueIntensity+255)>>8);
							}

							//SetPixel directly to hdcbuf
							//that saves us from the nasty Mask stuff and we don't have to do the BitBLT -blkhawk
							SetPixel(hdcbuf, posX+x, posY+y, RGB(r, g, b));
						}
						x++;
					}
				}
				y++;
			}

			SelectObject(src, hbmpOldIcon);
			DeleteObject(hbmpIcon);
		}
	}
	if (normTitles || minTitles || selTitles)
	{/*Paint the title boxes - bg/border/text*/
		RECT r;
		GetClientRect(tasks[i].hWnd, &r);
		r.top = titleY;
		r.left = titleX;
		r.bottom = titleHeight + titleY;
		r.right = titleWidth + titleX;

		if (titleBgColor != 0x00FF00FF){
			HBRUSH titleBg, oldTitleBg;
			titleBg = CreateSolidBrush(titleBgColor);
			oldTitleBg = (HBRUSH) SelectObject(hdcbuf, titleBg);
			FillRect(hdcbuf, &r, titleBg);
			SelectObject(hdcbuf, oldTitleBg);
			DeleteObject(titleBg);
		}
		if (titleLightColor != 0x00FF00FF)
		{/*Light Color Bevel (left/top)*/
			HPEN pen, oldpen;
			pen = CreatePen(PS_SOLID, 1, titleLightColor);
			oldpen = (HPEN) SelectObject(hdcbuf, pen);
			MoveToEx(hdcbuf, r.left, r.bottom - 1, NULL);
			LineTo(hdcbuf, r.left, r.top);
			LineTo(hdcbuf, r.right - 1, r.top);
			SelectObject(hdcbuf, oldpen);
			DeleteObject(pen);
		}
		if (titleDarkColor != 0x00FF00FF)
		{/*Dark Color Bevel (bottom/right)*/
			HPEN pen, oldpen;
			pen = CreatePen(PS_SOLID, 1, titleDarkColor);
			oldpen = (HPEN) SelectObject(hdcbuf, pen);
			MoveToEx(hdcbuf, r.right - 1, r.top, NULL);
			LineTo(hdcbuf, r.right - 1, r.bottom - 1);
			LineTo(hdcbuf, r.left, r.bottom - 1);
			SelectObject(hdcbuf, oldpen);
			DeleteObject(pen);
		}
		if (titleFontColor != 0x00FF00FF)
		{
			HFONT Font, oldFont;
			int oldBkMode;
			int len = strlen(tasks[i].appTitle);
			int lfHeight;

			if(ts.TitleOldFontSize)
			{
				lfHeight = titleFontSize;
			}
			else
			{
				lfHeight = -MulDiv(titleFontSize, GetDeviceCaps(hdcbuf, LOGPIXELSY), 72);
			}

			r.top += 1;
			r.bottom -= 1;
			r.left += 2;
			r.right -= 2;
			Font = CreateFont(lfHeight, 0, 0, 0, fnWeight, bItalic, bUnderline, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, PROOF_QUALITY, DEFAULT_PITCH|FF_DONTCARE, titleFont);
			oldFont = (HFONT) SelectObject(hdcbuf, Font);
			oldBkMode = SetBkMode(hdcbuf, TRANSPARENT);
			SetTextColor(hdcbuf, titleFontColor);
			DrawText(hdcbuf, tasks[i].appTitle, len, &r, uFormat);
			SetBkMode(hdcbuf, oldBkMode);
			SelectObject(hdcbuf, oldFont);
			DeleteObject(Font);
		}
	}
	{/*Main task border*/
		RECT r;
		GetClientRect(tasks[i].hWnd, &r);
		if (lightColor != 0x00FF00FF)
		{/*Light Color Bevel (left/top)*/
			HPEN pen, oldpen;
			pen = CreatePen(PS_SOLID, 1, lightColor);
			oldpen = (HPEN) SelectObject(hdcbuf, pen);
			MoveToEx(hdcbuf, r.left, r.bottom - 1, NULL);
			LineTo(hdcbuf, r.left, r.top);
			LineTo(hdcbuf, r.right - 1, r.top);
			SelectObject(hdcbuf, oldpen);
			DeleteObject(pen);
		}
		if (darkColor != 0x00FF00FF)
		{/*Dark Color Bevel (bottom/right)*/
			HPEN pen, oldpen;
			pen = CreatePen(PS_SOLID, 1, darkColor);
			oldpen = (HPEN) SelectObject(hdcbuf, pen);
			MoveToEx(hdcbuf, r.right - 1, r.top, NULL);
			LineTo(hdcbuf, r.right - 1, r.bottom - 1);
			LineTo(hdcbuf, r.left, r.bottom - 1);
			SelectObject(hdcbuf, oldpen);
			DeleteObject(pen);
		}
	}

	DeleteDC(src);
	return;
}

BOOL StripWS(char * buffer)
{
	UINT length = (NULL != buffer) ? strlen(buffer):0;

	if(0 != length)
	{
		char * tmpBuf = buffer;

		while(0 != length && isspace(*tmpBuf))
		{
			++tmpBuf;
			--length;
		}

		if(0 == length)
		{
			*buffer = 0;
		}
		else
		{
			while(0 != length && isspace(tmpBuf[length-1]))
			{
				tmpBuf[--length] = 0;
			}

			if(tmpBuf != buffer)
			{
				strcpy(buffer, tmpBuf);
			}
		}
	}

	return(0 != length);
}


void ReadTasksClass(void)
{
	FILE * f;
	char * token[3];
	char buffer[4096];
	char token1[MAXLEN];
	char token2[MAXLEN];
	char token3[MAXLEN];

	numClass = 0;
	f = LCOpen(NULL);
	if (!f)
		return;

	token[0] = token1;
	token[1] = token2;
	token[2] = token3;

	while (LCReadNextConfig (f, "*TasksClass", buffer, sizeof(buffer)))
	{
		int count;
		count = LCTokenize (buffer, token, 3, NULL);
		if (count >= 3)
		{
			if (!classTag)
				classTag = (ClassList *)malloc(sizeof(ClassList));
			else
				classTag = (ClassList *)realloc(classTag, (numClass+1)*sizeof(ClassList));
			classTag[numClass].match = new char[strlen(token[1])+1];
			classTag[numClass].name = new char[strlen(token[2])+1];
			strcpy(classTag[numClass].match, token[1]);
			strcpy(classTag[numClass].name, token[2]);
			numClass++;
		}
	}

	LCClose(f);

	return;
}

void ReadTasksIcon(void)
{
	FILE * f;
	char * token[4];
	char buffer[4096];
	char token1[MAXLEN];
	char token2[MAXLEN];
	char token3[MAXLEN];
	char token4[MAXLEN];

	numIcon = 0;
	f = LCOpen(NULL);
	if (!f)
		return;

	token[0] = token1;
	token[1] = token2;
	token[2] = token3;
	token[3] = token4;

	while (LCReadNextConfig (f, "*TasksIcon", buffer, sizeof(buffer)))
	{
		int count;
		count = LCTokenize (buffer, token, 4, NULL);
		if (count >= 4)
		{
			if (!iconTag)
				iconTag = (IconList *)malloc(sizeof(IconList));
			else
				iconTag = (IconList *)realloc(iconTag, (numIcon+1)*sizeof(IconList));
			iconTag[numIcon].match = new char[strlen(token[1])+1];
			iconTag[numIcon].name = new char[strlen(token[2])+1];
			strcpy(iconTag[numIcon].match, token[1]);
			strcpy(iconTag[numIcon].name, token[2]);
			iconTag[numIcon].icon = atoi(token[3]);
			numIcon++;
		}
	}

	LCClose(f);

	return;
}

void FreeTasksAdd( void )
{
	PCLASSTITLEITEM pNext;

	while(NULL != g_pAddList)
	{
		pNext = g_pAddList->pNext;

		free(g_pAddList);

		g_pAddList = pNext;
	}

	return;
}

void ReadTasksAdd( void )
{
	FILE * f;

	f = LCOpen(NULL);

	if(NULL != f)
	{
		PCLASSTITLEITEM pItem;
		char * tokens[3];
		char buffer[4096];
		char szTitle[256];
		char szClass[256];
		int nCount;

		tokens[0] = szClass;
		tokens[1] = szClass;
		tokens[2] = szTitle;

		while(LCReadNextConfig(f, "*TasksAdd", buffer, sizeof(buffer)))
		{
			nCount = LCTokenize(buffer, tokens, 3, NULL);

			if(nCount >= 2)
			{
				pItem = (PCLASSTITLEITEM)malloc(sizeof(CLASSTITLEITEM));

				strncpy(pItem->szClass, szClass, 256);
				pItem->szClass[255] = 0;

				if(nCount > 2)
				{
					strncpy(pItem->szTitle, szTitle, 256);
					pItem->szTitle[255] = 0;
				}
				else
				{
					strcpy(pItem->szTitle, "*");
				}

				pItem->pNext = g_pAddList;
				g_pAddList = pItem;
			}
		}

		LCClose(f);
	}

	return;
}

void FreeTasksIgnore( void )
{
	PCLASSTITLEITEM pNext;

	while(NULL != g_pIgnoreList)
	{
		pNext = g_pIgnoreList->pNext;

		free(g_pIgnoreList);

		g_pIgnoreList = pNext;
	}

	return;
}

void ReadTasksIgnore( void )
{
	FILE * f;

	f = LCOpen(NULL);

	if(NULL != f)
	{
		PCLASSTITLEITEM pItem;
		char * tokens[3];
		char buffer[4096];
		char szTitle[256];
		char szClass[256];
		int nCount;

		tokens[0] = szClass;
		tokens[1] = szClass;
		tokens[2] = szTitle;

		while(LCReadNextConfig(f, "*TasksIgnore", buffer, sizeof(buffer)))
		{
			nCount = LCTokenize(buffer, tokens, 3, NULL);

			if(nCount >= 2)
			{
				pItem = (PCLASSTITLEITEM)malloc(sizeof(CLASSTITLEITEM));

				strncpy(pItem->szClass, szClass, 256);
				pItem->szClass[255] = 0;

				if(nCount > 2)
				{
					strncpy(pItem->szTitle, szTitle, 256);
					pItem->szTitle[255] = 0;
				}
				else
				{
					strcpy(pItem->szTitle, "*");
				}

				pItem->pNext = g_pIgnoreList;
				g_pIgnoreList = pItem;
			}
		}

		LCClose(f);
	}

	return;
}

void ReadTasksPix(void)
{
	FILE * f;
	char * token[3];
	char buffer[4096];
	char token1[MAXLEN];
	char token2[MAXLEN];
	char token3[MAXLEN];

	numPix = 0;
	f = LCOpen(NULL);
	if (!f)
		return;

	token[0] = token1;
	token[1] = token2;
	token[2] = token3;

	while (LCReadNextConfig (f, "*TasksPix", buffer, sizeof(buffer)))
	{
		int count;
		count = LCTokenize (buffer, token, 3, NULL);
		if (count >= 3)
		{
			if (!pixTag)
				pixTag = (PixList *)malloc(sizeof(PixList));
			else
				pixTag = (PixList *)realloc(pixTag, (numPix+1)*sizeof(PixList));
			pixTag[numPix].match = new char[strlen(token[1])+1];
			pixTag[numPix].pix = new char[strlen(token[2])+1];
			strcpy(pixTag[numPix].match, token[1]);
			strcpy(pixTag[numPix].pix, token[2]);
			numPix++;
		}
	}

	LCClose(f);

	return;
}

void ReadTasksWrapCmd(void)
{
	FILE * f;
	char * token[3];
	char buffer[4096];
	char token1[MAXLEN];
	char token2[MAXLEN];
	char token3[MAXLEN];

	numWrapCmd = 0;
	f = LCOpen(NULL);
	if (!f)
		return;

	token[0] = token1;
	token[1] = token2;
	token[2] = token3;

	while (LCReadNextConfig (f, "*TasksWrapCmd", buffer, sizeof(buffer)))
	{
		int count;
		count = LCTokenize (buffer, token, 3, NULL);
		if (count >= 3)
		{
			if (!wrapCmd)
				wrapCmd = (WrapCmdList *)malloc(sizeof(WrapCmdList));
			else
				wrapCmd = (WrapCmdList *)realloc(wrapCmd, (numWrapCmd+1)*sizeof(WrapCmdList));
			wrapCmd[numWrapCmd].index = atoi(token[1]);
			wrapCmd[numWrapCmd].cmd = new char[strlen(token[2])+1];
			strcpy(wrapCmd[numWrapCmd].cmd, token[2]);
			numWrapCmd++;
		}
	}

	LCClose(f);

	return;
}

// function called by qsort to sort tasks based on the primary
// key of the class name and the secondary key the title
int SortTasksByClassTitle(const void *i0, const void *i1)
{
  TaskType *a = (TaskType*) i0;
  TaskType *b = (TaskType*) i1;
  int cv;

  cv = strcmp(a->appClass, b->appClass);

  if (cv)
    return cv;

  return strcmp(a->appTitle, b->appTitle);
}

void ReArrangeTasks(int i, BOOL all)
{
	HDWP hDwp;
	int j=i;

	if(!ts.NoMove && WM_LBUTTONDOWN == g_uButtonDownMsg)
	{
		ReleaseCapture();
		SwitchToWnd(g_hCurTask);
	}
	
	if (ts.AutoArrange && !ts.NoMove && !all && i>0)
		j = GetUnMovedNrTasks(i);

	if (ts.Sort && (i == 0))
		qsort(tasks, numTasks, sizeof(TaskType), SortTasksByClassTitle);

	hDwp = BeginDeferWindowPos(numTasks - i);

	for ( ;i<numTasks;i++){
		if (all || !tasks[i].IsMoved){
			TaskPosition(i, j);
			DeferWindowPos(hDwp, tasks[i].hWnd, 0, tasks[i].x, tasks[i].y, 0, 0, SWP_NOSIZE|SWP_NOZORDER|SWP_NOACTIVATE|SWP_NOOWNERZORDER );
			tasks[i].IsMoved = FALSE;
			if (!ts.StartHidden)/*Have to force a complete redraw here...*/
				InvalidateRect(tasks[i].hWnd, NULL, TRUE);
			++j;
		}
	}

	EndDeferWindowPos(hDwp);

	return;
}

void RemoveHints(HWND hWnd)
{/*from the original ls code (shortcuts)*/
	TOOLINFO ti;/*tool information*/
	RECT r={0,0,0,0};
	ti.cbSize = sizeof(TOOLINFO);
	ti.uFlags = 0;
	ti.hwnd = hWnd;
	ti.hinst = g_hDllInst;
	ti.uId = 0;
	ti.lpszText = NULL;
	ti.rect = r;
	SendMessage(g_hHintWnd, TTM_DELTOOL, 0, (LPARAM) (LPTOOLINFO) &ti);
	return;
}

void TaskPosition(int i, int tmpNumTasks)
{
	int wrapLine = 0, resetLine = 0, tWrapCount = ts.WrapCount;
	if (ts.WrapCount == -1){ //auto wrap
		switch (ts.Direction)
		{
		case 1:/* Up */
			tWrapCount = ts.Y / ts.Height;
			break;
		case 2:/* Right */
			tWrapCount = (g_nDockCX - ts.X) / ts.Width;
			break;
		case 3:/* Down */
			tWrapCount = (g_nDockCY - ts.Y) / ts.Height;
			break;
		case 4:/* Left */
			tWrapCount = ts.X / ts.Width;
			break;
		}
		if (tWrapCount < 1)
			tWrapCount = 1;
		g_bTaskWrap = TRUE;
	}

	if (g_bTaskWrap)
	{
		wrapLine = tmpNumTasks / tWrapCount;
		resetLine = tmpNumTasks - tWrapCount * wrapLine;
	}

	if (ts.Direction == 1) /*up*/
	{
		if (g_bTaskWrap)
		{
			tasks[i].y = ts.Y - ts.Height - resetLine * (ts.Height + ts.SpacingY);
			if (ts.WrapDirection == 4) /*left*/
			{
				tasks[i].x = ts.X - ts.Width - wrapLine * (ts.Width + ts.SpacingX);
			}
			else /*defaults to right, even if user inputs invalid up or down setting*/
			{
				tasks[i].x = ts.X + wrapLine * (ts.Width + ts.SpacingX);
			}
		}
		else
		{
			tasks[i].y = ts.Y - ts.Height - tmpNumTasks * (ts.Height + ts.SpacingY);
			tasks[i].x = ts.X;
		}
	}
	else if (ts.Direction == 2) /*right*/
	{
		if (g_bTaskWrap)
		{
			tasks[i].x = ts.X + resetLine * (ts.Width + ts.SpacingX);
			if (ts.WrapDirection == 1) /*up*/
			{
				tasks[i].y = ts.Y - ts.Height - wrapLine * (ts.Height + ts.SpacingY);
			}
			else /*defaults to down, even if user inputs invalid left or right setting*/
			{
				tasks[i].y = ts.Y + wrapLine * (ts.Height + ts.SpacingY);
			}
		}
		else
		{
			tasks[i].x = ts.X + tmpNumTasks * (ts.Width + ts.SpacingX);
			tasks[i].y = ts.Y;
		}
	}
	else if (ts.Direction == 3) /*down*/
	{
		if (g_bTaskWrap)
		{
			tasks[i].y = ts.Y + resetLine * (ts.Height + ts.SpacingY);
			if (ts.WrapDirection == 4) /*left*/
			{
				tasks[i].x = ts.X - ts.Width - wrapLine * (ts.Width + ts.SpacingX);
			}
			else /*defaults to right, even if user inputs invalid up or down setting*/
			{
				tasks[i].x = ts.X + wrapLine * (ts.Width + ts.SpacingX);
			}
		}
		else
		{
			tasks[i].y = ts.Y + tmpNumTasks * (ts.Height + ts.SpacingY);
			tasks[i].x = ts.X;
		}
	}
	else if (ts.Direction == 4) /*left*/
	{
		if (g_bTaskWrap)
		{
			tasks[i].x = ts.X - ts.Width - resetLine * (ts.Width + ts.SpacingX);
			if (ts.WrapDirection == 1) /*up*/
			{
				tasks[i].y = ts.Y - ts.Height - wrapLine * (ts.Height + ts.SpacingY);
			}
			else /*defaults to down, even if user inputs invalid left or right setting*/
			{
				tasks[i].y = ts.Y + wrapLine * (ts.Height + ts.SpacingY);
			}
		}
		else
		{
			tasks[i].x = ts.X - ts.Width - tmpNumTasks * (ts.Width + ts.SpacingX);
			tasks[i].y = ts.Y;
		}
	}
	if (tasks[i].x < g_rAllTasks.left) g_rAllTasks.left = tasks[i].x;
	if (tasks[i].x + ts.Width > g_rAllTasks.right) g_rAllTasks.right = tasks[i].x + ts.Width;
	if (tasks[i].y < g_rAllTasks.top) g_rAllTasks.top = tasks[i].y;
	if (tasks[i].y + ts.Height > g_rAllTasks.bottom) g_rAllTasks.bottom = tasks[i].y + ts.Height;
	return;
}

void UpdateHints(HWND hWnd, char * txt)
{
	RECT r;
	GetClientRect(hWnd, &r);
	TOOLINFO ti;
	ti.cbSize = sizeof(TOOLINFO);
	ti.uFlags = TTF_SUBCLASS;
	ti.hwnd = hWnd;
	ti.hinst = g_hDllInst;
	ti.uId = 0;
	ti.lpszText = txt;
	ti.rect = r;
	SendMessage(g_hHintWnd, TTM_UPDATETIPTEXT, 0, (LPARAM) (LPTOOLINFO) &ti);
	return;
}

/*From here down are the !bang commands*/
void TasksGather(HWND caller, const char * args)
{
	if(g_bTasksDisabled) return;

	ts.X = bkUpX;
	ts.Y = bkUpY;

	if(0 > ts.X || (0 == ts.X && (4 == ts.Direction || (4 == ts.WrapDirection && g_bTaskWrap))))
		ts.X += g_nDockCX;
	if(0 > ts.Y || (0 == ts.Y && (1 == ts.Direction || (1 == ts.WrapDirection && g_bTaskWrap))))
		ts.Y += g_nDockCY;

	if(IsDockWindowValid())
	{
		ReArrangeTasks(0, TRUE);
	}
	return;
		UNREFERENCED_PARAMETER(caller);
		UNREFERENCED_PARAMETER(args);
}

void TasksHide(HWND caller, const char * args)
{
	if(g_bTasksDisabled) return;

	if(IsDockWindowValid())
	{
		int i;
		HDWP hDwp = BeginDeferWindowPos(numTasks);

		for(i = 0; i < numTasks; i++)
		{
			DeferWindowPos(
				 hDwp
				,tasks[i].hWnd
				,0
				,0, 0
				,0, 0
				,SWP_HIDEWINDOW|SWP_NOSIZE|SWP_NOMOVE|SWP_NOZORDER|SWP_NOACTIVATE|SWP_NOOWNERZORDER
			);
		}

		if(!EndDeferWindowPos(hDwp))
		{
			for(i = 0; i < numTasks; i++)
			{
				ShowWindow(tasks[i].hWnd, SW_HIDE);
			}
		}
	}

	ts.StartHidden = TRUE;

	return;
		UNREFERENCED_PARAMETER(caller);
		UNREFERENCED_PARAMETER(args);
}

void TasksMove(HWND caller, const char * args)
{
	if(g_bTasksDisabled) return;
	if(!IsDockWindowValid()) return;

	if (args != NULL && *args != 0){
		char * orgArgs = new char[strlen(args)+1];
		char * tmpArgs = orgArgs;
		strcpy(tmpArgs, args);
		if (StripWS(tmpArgs)){
			tmpArgs = strtok(tmpArgs, "\'\"\t ,");
				if (tmpArgs != NULL )
					ts.X = atoi(tmpArgs);
				if (ts.X < 0)
					ts.X += g_nDockCX;
			tmpArgs = strtok(NULL, "\'\"\t ,");
				if (tmpArgs != NULL )
					ts.Y = atoi(tmpArgs);
				if (ts.Y < 0)
					ts.Y += g_nDockCY;
		}
		delete [] orgArgs;
		orgArgs = tmpArgs = NULL;
		ReArrangeTasks(0, TRUE);
	}else{
		BOOL wasHidden = ts.StartHidden;
		POINT ps;
		GetCursorPos(&ps);
		ts.X = ps.x;
		ts.Y = ps.y;
		if ((ts.Direction == 4 || (g_bTaskWrap && ts.WrapDirection == 4))) ts.X += 1;
		if ((ts.Direction == 1 || (g_bTaskWrap && ts.WrapDirection == 1))) ts.Y += 1;
		g_rAllTasks.left = g_rAllTasks.right = g_rAllTasks.top = g_rAllTasks.bottom = 0;
		if (!wasHidden)
			TasksHide(NULL, NULL);
		ReArrangeTasks(0, TRUE);
		if (g_rAllTasks.right > g_nDockCX){
			if (ts.Direction == 4 || (g_bTaskWrap && ts.WrapDirection == 4))
				ts.X = g_nDockCX;
			else
				ts.X -= g_rAllTasks.right - g_nDockCX;
		}
		if (g_rAllTasks.bottom > g_nDockCY){
			if (ts.Direction == 1 || (g_bTaskWrap && ts.WrapDirection == 1))
				ts.Y = g_nDockCY;
			else
				ts.Y -= g_rAllTasks.bottom - g_nDockCY;
		}
		if (g_rAllTasks.left < 0){
			if (ts.Direction == 4 || (g_bTaskWrap && ts.WrapDirection == 4))
				ts.X -= g_rAllTasks.left;
			else
				ts.X = 0;
		}
		if (g_rAllTasks.top < 0){
			if (ts.Direction == 1 || (g_bTaskWrap && ts.WrapDirection == 1))
				ts.Y -= g_rAllTasks.top;
			else
				ts.Y = 0;
		}
		g_rAllTasks.left = g_rAllTasks.right = g_rAllTasks.top = g_rAllTasks.bottom = 0;
		ReArrangeTasks(0, TRUE);
		if (!wasHidden)
			TasksShow(NULL, NULL);
	}
	return;
	UNREFERENCED_PARAMETER(caller);
}

void TasksShow(HWND caller, const char * args)
{
	if(g_bTasksDisabled) return;
	if(IsDockWindowValid())
	{
		int i;
		HDWP hDwp = BeginDeferWindowPos(numTasks);

		for(i = 0; i < numTasks; i++)
		{
			DeferWindowPos(
				 hDwp
				,tasks[i].hWnd
				,0
				,0, 0
				,0, 0
				,SWP_SHOWWINDOW|SWP_NOSIZE|SWP_NOMOVE|SWP_NOZORDER|SWP_NOACTIVATE|SWP_NOOWNERZORDER
			);
		}

		if(!EndDeferWindowPos(hDwp))
		{
			for(i = 0; i < numTasks; i++)
			{
				ShowWindow(tasks[i].hWnd, SW_SHOWNOACTIVATE);
			}
		}
	}

	ts.StartHidden = FALSE;

	return;
	UNREFERENCED_PARAMETER(caller);
	UNREFERENCED_PARAMETER(args);
}

void TasksSwitch(HWND caller, const char * args)
{
	if(g_bTasksDisabled) return;
	if(!IsDockWindowValid()) return;
	if(0 == numTasks || NULL == args || 0 == *args) return;

	BOOL bNext = FALSE;
	int n;

	if (!_strcmpi(args, "next"))
		bNext = TRUE;
	else if (!_strcmpi(args, "prev"))
		bNext = FALSE;
	else
		return;

	n = GetTaskByAppWnd(g_hCurTask);

	if(-1 == n)
	{
		n = GetTaskByAppWnd(g_hLockCurTask);
	}

	if (bNext){
		if (n == -1 || ++n >= numTasks)
			n=0;
	}else{
		if (n == -1 || --n < 0)
			n = numTasks-1;
	}

	SwitchToTasksWnd(n);

	return;
	UNREFERENCED_PARAMETER(caller);
}

void TasksToggle(HWND caller, const char * args)
{
	if(g_bTasksDisabled) return;
	if(IsDockWindowValid())
	{
		int i;
		DWORD dwFlags = SWP_NOSIZE|SWP_NOMOVE|SWP_NOZORDER|SWP_NOACTIVATE|SWP_NOOWNERZORDER;
		HDWP hDwp = BeginDeferWindowPos(numTasks);

		dwFlags |= ts.StartHidden ? SWP_SHOWWINDOW : SWP_HIDEWINDOW;

		for(i = 0; i < numTasks; i++)
		{
			DeferWindowPos(
				 hDwp
				,tasks[i].hWnd
				,0
				,0, 0
				,0, 0
				,dwFlags
			);
		}

		if(!EndDeferWindowPos(hDwp))
		{
			int nShowCmd = ts.StartHidden ? SW_SHOWNOACTIVATE : SW_HIDE;

			for(i = 0; i < numTasks; i++)
			{
				ShowWindow(tasks[i].hWnd, nShowCmd);
			}
		}
	}

	ts.StartHidden = !ts.StartHidden;

	return;
	UNREFERENCED_PARAMETER(caller);
	UNREFERENCED_PARAMETER(args);
}

void TasksDisplay(HWND caller, const char * args)
{
	if(g_bTasksDisabled) return;
	int nMask = MASK_NONE;

	if (args != NULL && *args != 0 && strlen(args)){
		char * orgArgs = new char[strlen(args)+1];
		char * tmpArgs = orgArgs;
		strcpy(tmpArgs, args);
		if (StripWS(tmpArgs)){
			_strlwr(tmpArgs); // convert to lower case, since there is no 'strstr' case insensitive routine.
			if (strstr(tmpArgs, "all"))
				nMask = MASK_ALL;
			else{
				if (strstr(tmpArgs, "normal"))
					nMask |= MASK_NORMAL;
				if (strstr(tmpArgs, "minimized"))
					nMask |= MASK_MINIMIZED;
				if (strstr(tmpArgs, "selected"))
					nMask |= MASK_SELECTED;
			}
			ts.Display = (nMask == MASK_NONE) ? MASK_ALL:nMask;
		}else
			ts.Display = bkDisp;
		delete [] orgArgs;
		tmpArgs = orgArgs = NULL;
	}else
		ts.Display = bkDisp;

	/* Make sure the display is updated. (LM_WINDOWACTIVATED is an arbitrary choice) */
	PostMessage(g_hMainWnd, LM_WINDOWACTIVATED, 0, 0);

	return;
	UNREFERENCED_PARAMETER(caller);
}

void TasksDisable(HWND caller, const char * args)
{
	g_bTasksDisabled = TRUE;

	if(IsDockWindowValid())
	{
		FreeList();
		g_hCurTask = g_hLockCurTask = g_hOldCurTask = g_hFlashingTask = NULL;
	}

	return;
	UNREFERENCED_PARAMETER(caller);
	UNREFERENCED_PARAMETER(args);
}

void TasksEnable(HWND caller, const char * args)
{
	if(g_bTasksDisabled)
	{
		IsDockWindowValid();

		g_bTasksDisabled = FALSE;
		g_hCurTask = GetForegroundWindow();
		EnumWindows(EnumWindowsProc, NULL);
		UpdateTasks();
	}

	return;
	UNREFERENCED_PARAMETER(caller);
	UNREFERENCED_PARAMETER(args);
}

void TasksBoxHook(HWND caller, const char * args)
{
	if(NULL != args && 0 != *args)
	{
		char * handle = strrchr(args,' ');

		if(NULL != handle)
		{
			HWND hWnd = (HWND)atoi(handle+1);

			if(IsWindow(hWnd) && hWnd != ts.DockWindow)
			{
				RECT r;
				BOOL bWasHidden = ts.StartHidden;

				GetWindowRect(hWnd, &r);
				g_nDockCX = r.right - r.left;
				g_nDockCY = r.bottom - r.top;

				ts.DockWindow = hWnd;

				if(!g_bTasksDisabled)
				{
					if(!bWasHidden) TasksHide(NULL, NULL);

					for(int i = 0; i < numTasks; i++)
					{
						SetWindowLong(tasks[i].hWnd, GWL_STYLE, (GetWindowLong(tasks[i].hWnd, GWL_STYLE) &~ WS_POPUP)|WS_CHILD|WS_CLIPSIBLINGS);
						SetParent(tasks[i].hWnd, hWnd);
					}

					TasksGather(NULL, NULL);

					if(!bWasHidden) TasksShow(NULL, NULL);
				}
			}
		}
	}

	return;
	UNREFERENCED_PARAMETER(caller);
}

void TasksDockWindow(HWND caller, const char * args)
{
	if(NULL != args && 0 != *args)
	{
		char * tmpArgs = new char[strlen(args)+1];

		if(StripWS(strcpy(tmpArgs, args)))
		{
			HWND hWnd = NULL;

			if(0 != _strcmpi(tmpArgs, ".none"))
			{
				char * ptr1;
				char * ptr2;

				ptr1 = strtok(tmpArgs, ";\"\'");
				ptr2 = strtok(NULL, ";\"\'");
				StripWS(ptr1);
				StripWS(ptr2);

				if(NULL != ptr1 && 0 != *ptr1)
				{
					hWnd = FindWindow(ptr1, ptr2);
				}
				else
				{
					// Don't change the dock window if the new one can't be found
					hWnd = ts.DockWindow;
				}
			}

			if(hWnd != ts.DockWindow)
			{
				BOOL bWasHidden = ts.StartHidden;

				ts.DockWindow = hWnd;

				if(!g_bTasksDisabled)
				{
					if(!bWasHidden) TasksHide(NULL, NULL);

					for(int i=0;i<numTasks;i++)
					{
						SetWindowLong(tasks[i].hWnd, GWL_STYLE, (GetWindowLong(tasks[i].hWnd, GWL_STYLE) &~ WS_POPUP)|WS_CHILD|WS_CLIPSIBLINGS);
						SetParent(tasks[i].hWnd, hWnd);

						if(NULL == hWnd)
						{
							SetWindowLong(tasks[i].hWnd, GWL_STYLE, (GetWindowLong(tasks[i].hWnd, GWL_STYLE) &~ (WS_CHILD|WS_CLIPSIBLINGS))|WS_POPUP);
						}
					}

					TasksGather(NULL, NULL);

					if(!bWasHidden) TasksShow(NULL, NULL);
				}
			}
		}

		delete [] tmpArgs;
	}

	return;
	UNREFERENCED_PARAMETER(caller);
}

void TaskszOrder(HWND caller, const char * args)
{
	if(g_bTasksDisabled) return;

	BOOL bValid = IsDockWindowValid();

	if (args != NULL && *args != 0 && strlen(args)){
		char * orgArgs = new char[strlen(args)+1];
		char * tmpArgs = orgArgs;
		strcpy(tmpArgs, args);
		if (StripWS(tmpArgs)){
			if (_strcmpi(tmpArgs, "ontop") == 0){
				ts.zOrder = 2;
				if(bValid)
					for (int i=0;i<numTasks;i++)
						SetWindowPos(tasks[i].hWnd, HWND_TOPMOST,0,0,0,0,SWP_NOACTIVATE|SWP_NOMOVE|SWP_NOSIZE|SWP_NOSENDCHANGING|SWP_NOOWNERZORDER);
			}
			else if (_strcmpi(tmpArgs, "floating") == 0){
				ts.zOrder = 1;
				if(bValid)
					for (int i=0;i<numTasks;i++)
						SetWindowPos(tasks[i].hWnd, HWND_NOTOPMOST,0,0,0,0,SWP_NOACTIVATE|SWP_NOMOVE|SWP_NOSIZE|SWP_NOSENDCHANGING|SWP_NOOWNERZORDER);
			}
		}
		delete [] orgArgs;
		tmpArgs = orgArgs = NULL;
	}
	return;
	UNREFERENCED_PARAMETER(caller);
}

void TasksMinimize(HWND caller, const char * args)
{
	if(g_bTasksDisabled) return;
	if(IsDockWindowValid())
		for (int i=0;i<numTasks;i++)
			if(!tasks[i].IsIconic)
				SendMessage(tasks[i].appHandle, WM_SYSCOMMAND, (WPARAM)SC_MINIMIZE, 0);
	return;
		UNREFERENCED_PARAMETER(caller);
		UNREFERENCED_PARAMETER(args);
}

void TasksMaximize(HWND caller, const char * args)
{
	if(g_bTasksDisabled) return;
	if(IsDockWindowValid())
		for (int i=0;i<numTasks;i++)
			SendMessage(tasks[i].appHandle, WM_SYSCOMMAND, (WPARAM)SC_MAXIMIZE, 0);
	return;
		UNREFERENCED_PARAMETER(caller);
		UNREFERENCED_PARAMETER(args);
}

void TasksRestore(HWND caller, const char * args)
{
	if(g_bTasksDisabled) return;
	if(IsDockWindowValid())
		for (int i=0;i<numTasks;i++)
			SendMessage(tasks[i].appHandle, WM_SYSCOMMAND, (WPARAM)SC_RESTORE, 0);
	return;
		UNREFERENCED_PARAMETER(caller);
		UNREFERENCED_PARAMETER(args);
}

/* EOF */


