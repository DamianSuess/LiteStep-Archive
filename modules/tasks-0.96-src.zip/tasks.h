/*------------------------------------------------------------------------------
	This Litestep module is a Task Manager implementation.

	Copyright (C) 1999-2004 Chris Rempel

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
------------------------------------------------------------------------------*/

#ifndef __ACTIVETASKS_H_
#define __ACTIVETASKS_H_

typedef void (WINAPI *FUNC_VOID__HWND_BOOL)(HWND, BOOL);

#define TMR_UPDATE 1

#define MASK_NONE        (0x00)
#define MASK_NORMAL      (0x01)
#define MASK_MINIMIZED   (0x02)
#define MASK_SELECTED    (0x04)
#define MASK_FLASHING    (0x08)
#define MASK_VWM         (0x10)
#define MASK_ALL         (0xFF)

const int MAXLEN = 1024;

//#define USE_HOVER

struct TaskType
{
	char * appTitle;
	char * appClass;
	long x, y;
	HBITMAP pix;
	HICON icon;
	HICON iconOrg;
	HWND hWnd;
	HWND appHandle;
	BOOL IsActive;
	BOOL IsIconic;
	BOOL IsMoved;
	BOOL IsFlashing;

#ifdef USE_HOVER
	BOOL IsMouseOver;
	BOOL IsHovering;
	POINT HoverPoint;
#endif
};

/* this guarantees that all the bits that need all the actions are kept in sync */ 
#define TASKS_ON_COMMAND_LIST(MACRO)                            \
	/* left */                                                  \
	MACRO(OnLButtonClick,  "TasksOnLButtonClick", NULL)         \
	MACRO(OnLButtonDown,   "TasksOnLButtonDown",  NULL)         \
	MACRO(OnLButtonUp,     "TasksOnLButtonUp",    NULL)         \
	/* right */                                                 \
	MACRO(OnRButtonClick,  "TasksOnRButtonClick", ".SYSPOPUP")  \
	MACRO(OnRButtonDown,   "TasksOnRButtonDown",  NULL)         \
	MACRO(OnRButtonUp,     "TasksOnRButtonUp",    NULL)         \
	/* middle */                                                \
	MACRO(OnMButtonClick,  "TasksOnMButtonClick", "!POPUP")     \
	MACRO(OnMButtonDown,   "TasksOnMButtonDown",  NULL)         \
	MACRO(OnMButtonUp,     "TasksOnMButtonUp",    NULL)         \
	/* other mouse events */                                    \
	MACRO(OnMouseOver,     "TasksOnMouseOver",    NULL)         \
	MACRO(OnMouseOut,      "TasksOnMouseOut",     NULL)         \
	MACRO(OnHover,         "TasksOnHover",        NULL)         \
	MACRO(OnUnhover,       "TasksOnUnhover",      NULL)         \
	/* number of tasks */                                       \
	MACRO(OnAdd,           "TasksOnAdd",          NULL)         \
	MACRO(OnDel,           "TasksOnDel",          NULL)         \
	/* useful in conjuction with the *TasksWrapCmd values */    \
	MACRO(EmptyCmd,        "TasksEmptyCmd",       NULL)         \
	/* monkey */                                                \
	MACRO(OnInit,          "TasksOnInit",         NULL)         \
	MACRO(OnQuit,          "TasksOnQuit",         NULL)         

struct TasksSettings
{
	//Main Task Settings
	int Direction, Display, DragDistance, MaxTiles, SetTimer, SpacingX, SpacingY, Transparency, WrapCount, WrapDirection, zOrder;
	int Height, Width, X, Y;
	int IconSize, IconX, IconY, MinIconX, MinIconY, SelIconX, SelIconY;
	int PixX, PixY, MinPixX, MinPixY, SelPixX, SelPixY;

	BOOL StartDisabled;
	BOOL AutoArrange, HideMinAppBar, MoveAll, NoMinimizeOnClick, NoMove, Sort, StartHidden, UseSystemHook, UseVWMSwitching, UseVWMDisplay;
	BOOL HighLightMinimized, HighLightSelected, NoHints, NoIcons, UseWindowsSettings;

	COLORREF BgColor, DarkColor, LightColor, MinBgColor, MinDarkColor, MinLightColor, SelBgColor, SelDarkColor, SelLightColor;

	HBITMAP BgImage, MinBgImage, SelBgImage;

#define DEFINE_ON_ACTION(MEMBER, STRING, DEFAULT)   LPSTR MEMBER;
	TASKS_ON_COMMAND_LIST(DEFINE_ON_ACTION)
#undef DEFINE_ON_ACTION

	HWND DockWindow;

	//Title Task Settings
	int TitleHeight, TitleWidth, TitleMinHeight, TitleMinWidth, TitleSelHeight, TitleSelWidth;
	int TitleX, TitleY, TitleMinX, TitleMinY, TitleSelX, TitleSelY;
	int TitleIconX, TitleIconY, TitleMinIconX, TitleMinIconY, TitleSelIconX, TitleSelIconY;
	int TitlePixX, TitlePixY, TitleMinPixX, TitleMinPixY, TitleSelPixX, TitleSelPixY;
	int TitleFontSize, TitleMinFontSize, TitleSelFontSize;

	BOOL TitleOldFontSize;
	BOOL Titles, TitleItalicize, TitleNoEllipsis, TitleUnderline, TitleBold;
	BOOL TitleMinimized, TitleMinItalicize, TitleMinNoEllipsis, TitleMinUnderline, TitleMinBold;
	BOOL TitleSelected, TitleSelItalicize, TitleSelNoEllipsis, TitleSelUnderline, TitleSelBold;

	UINT TitleAlignment, TitleMinAlignment, TitleSelAlignment;

	LPSTR TitleFont, TitleMinFont, TitleSelFont;

	COLORREF TitleBgColor, TitleDarkColor, TitleFontColor, TitleLightColor, TitleMinBgColor, TitleMinDarkColor, TitleMinFontColor, TitleMinLightColor, TitleSelBgColor, TitleSelDarkColor, TitleSelFontColor, TitleSelLightColor;

	// Hueable tasks
	BOOL bHueIcons;
	COLORREF HueColor, MinHueColor, SelHueColor;
	UCHAR HueIntensity, MinHueIntensity, SelHueIntensity;
	UCHAR HueSaturation, MinHueSaturation, SelHueSaturation;
};

struct ClassList
{
	char * match; // string to look for in class name or title
	char * name; // substitute class name
};

struct IconList
{
	char * match; // string to look for in titlebar, or class name
	char * name; // path to icon
	int icon; // icon # to load when name is found
};

typedef struct _CLASSTITLEITEM
{
	char szClass[256];
	char szTitle[256];
	//
	struct _CLASSTITLEITEM *pNext;
	//
} CLASSTITLEITEM, *PCLASSTITLEITEM;

struct PixList
{
	char * match; // string to look for in titlebar, or class name
	char * pix; // path to pix to load
};

struct WrapCmdList
{
	int index;
	char * cmd;
};

#ifdef __cplusplus
	extern "C" {
#endif
	__declspec( dllexport ) int initModuleEx( HWND, HINSTANCE, LPCTSTR);
	__declspec( dllexport ) void quitModule( HINSTANCE );
#ifdef __cplusplus
	}
#endif


#endif /*__ACTIVETASKS_H_*/

